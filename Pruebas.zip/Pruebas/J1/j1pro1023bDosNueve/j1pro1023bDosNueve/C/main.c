#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,h;
    a=7;
    b=6;
    printf("Calculando area del trianguulo =)\n");
    h=((a*b)*0.5);
    printf("a=%d\n",a);
    printf("b=%d\n",b);
    printf("h=%d\n",h);
    return 0;
}
