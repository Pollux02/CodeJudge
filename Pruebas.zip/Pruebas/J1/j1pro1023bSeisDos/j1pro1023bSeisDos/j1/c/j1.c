#include <stdio.h>
#include <stdlib.h>

int main()
{
printf("Area del triangulo con valores definidos:D\n\n");
    printf("***************************************************************************************\n\n");

    int b = 5;
    int h = 8;
    int a = (b * h)/2;

        printf("Valor de b: %d\n", b);
        printf("Valor de h: %d\n\n", h);
        printf("Area del triangulo:\n");
        printf("Valor de a: %d\n\n", a);

    printf("***************************************************************************************\n\n");
return 0;
}
