#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, h;
    b = 56;
    h = 38;
    a = b*h/2;
    printf("El area del triangulo con base de %dcm y %dcm de altura es: %dcm", b, h,a);
    return 0;
}
