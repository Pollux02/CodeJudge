#include <stdio.h>
#include <stdlib.h>

int main()
{
    //EJERCICIO 1 PROGRAMACION ESTRUCTURADA. CALCULAR EL AREA DE UN TRIANGULO.
    int a,b,h;
    h=20;
    b=10;
    a= (b*h)/2;
    printf ("El area de el triangulo es : %i cm \n", a);

    printf ("Los valores de las variables que utilice son los siguientes: \n");
    printf ("h = 20 cm (altura)\n");
    printf ("b = 10 cm (base)\n");

    return 0;
}
