/*implemente un programa que calcule el �rea de un triangulo
usando variables int nombradas "a", "b" y "h".
No es necesario solicitar datos al usuario. */
#include<stdio.h>

int main(){
	int a, b, h;
	b=3;
	h=6;
	
	printf("Calcular el area de un triangulo.\n");
	printf("Base = %d\n",b);
	printf("Altura = %d\n",h);
	
	a = (b * h) / 2;
	
	printf("El area del triangulo es: %d\n",a);
	
	return 0;
}
