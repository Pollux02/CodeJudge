#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,h;
    b=12;
    h=10;
    a=(b*h)/2;
    printf("El area de un triangulo es  : %d\n", a);
    printf("La base de un triangulo es  : %d\n", b);
    printf("La altura de un triangulo es: %d\n\n", h);

    return 0;
}
