#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,h;
    b= 12;
    h= 15;
    a= b*h/2;

    printf("la base de nuestro triangulo es de: %d\n",b);
    printf("la altura de nuestro triangulo es de: %d\n",h);
    printf("el area de nuestro triangulo es de: %d\n",a);

    return 0;
}
