#include <stdio.h>
#include <stdlib.h>

int main()
{
    int b,h,a;
    b=10;
    h=5;
    a=b*h/2;
    printf("Altura:%d \n",h);
    printf("Base:%d \n",b);
    printf("El area es :%d \n",a);
    return 0;
}
