#include <stdio.h>
#include <stdlib.h>

int main()
{

   int a,b,h;
   b=6;
   a=12;
   h=a*b/2;
   printf("Base de triangulo: %d\n",b);
   printf("Altura de triangulo: %d\n\n",a);
   printf("Area de triangulo: %d\n",h);
    return 0;
}
