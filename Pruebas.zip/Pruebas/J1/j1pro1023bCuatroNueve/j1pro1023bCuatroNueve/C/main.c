#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,h;
    a= 16;
    b= 4;
    h= (a*b)/2;
    printf("el area del triangulo es: %d\n",h);
    return 0;
}
