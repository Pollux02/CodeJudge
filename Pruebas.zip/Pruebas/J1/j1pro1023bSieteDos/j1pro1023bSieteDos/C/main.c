#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Area de un triangulo sin la pedida de datos de entrada

    int a, b, h; // El area la base y la altura.


    b = 5; //Inicializo la variable a 5
    h = 2; //Inicializo la variable a 2

    a = (b*h)/2;

    printf("Area del triangulo: %d", a);



    return 0;
}
