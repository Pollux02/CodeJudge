#include <stdio.h>


int main() {
    int a,b,h;
    h=10;
    b=13;

    a=(b*h)/2;

    printf("EL area del triangulo es:%d\n",a);

    return 0;
}