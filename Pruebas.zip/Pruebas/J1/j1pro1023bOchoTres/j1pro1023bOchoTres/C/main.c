#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,h;
    b=10;
    h=10;
    a=b*h/2;
    printf("El area del triangulo es:%d\n",a);
    return 0;
}
