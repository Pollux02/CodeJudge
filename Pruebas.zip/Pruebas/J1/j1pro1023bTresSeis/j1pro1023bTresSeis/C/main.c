#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,h;
    b=10;
    h=15;
    a=b*h/2;
    printf("base: %d\n",b);
    printf("altura: %d\n",h);
    printf("El area del triangulo es: %d\n",a);
    return 0;
}
