#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,h;
    b=24;
    h=12;
    a=b*h/2;
    printf("Datos del triangulo:\n");
    printf("Base: %d\n",b);
    printf("Altura: %d\n",h);
    printf("Area: %d\n",a);
    return 0;
}
