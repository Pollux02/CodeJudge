#include <stdio.h>
#include <stdlib.h>

int main()
{
    //AREA
    int a;
    //BASE
    int b=7;
    //ALTURA
    int h=2;
    //OPERACION
    a=(b*h)/2;
    //IMPRESION
    printf("El resultado del area es: %d", a);
    return 0;
}
