#include <stdio.h>
#include <stdlib.h>

int main()
{
    int b,h,a;
    b=15;
    h=4;
    a= (b*h)/2;
    printf("base del triangulo: %d\n",b);
    printf("altura del triangulo: %d\n\n",h);
    printf("Area del triangulo: %d",a);
    return 0;
}
