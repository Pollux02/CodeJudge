#include <stdio.h>
#include <stdlib.h>

int main()
{
    int b;
    int h;
    int a;
    b = 12;
    h = 8;
    a = b * h / 2;
    printf("Area de un triangulo\n");
    printf("b = %d\n", b);
    printf("h = %d\n", h);
    printf("a = %d * %d / 2 = %d\n", b, h, a);
    return 0;
}
