#include <stdio.h>
#include <stdlib.h>
//Area de un triangulo
int main()
{
    printf("Area de un triangulo:\n\n\n");
    int a=0,b,h;
    b=10;
    h=5;
    a=(b*h)/2;
    printf("El valor de a es=%d\n\n",a);
    printf("El valor de b es=%d\n\n",b);
    printf("El valor de h es=%d\n\n",h);
    return 0;
}
