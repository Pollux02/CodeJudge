#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,h;
    b=5;
    h=6;
    a=b*h;
    a=a/2;
    printf("areal del triangulo: %d",a);
    return 0;
}
