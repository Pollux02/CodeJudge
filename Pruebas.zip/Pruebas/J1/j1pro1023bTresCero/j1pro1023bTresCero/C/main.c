#include <stdio.h>
#include <stdlib.h>

int main()
{
    int b,h,a;
    b=10;
    h=5;
    a=b*h/2;
    printf("La base del triangulo es: %d\n",b);
    printf("La altura del triangulo es: %d\n",h);
    printf("El area total del triangulo es: %d\n",a);

    return 0;
}
