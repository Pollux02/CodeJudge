//SieteSiete
#include<stdio.h>

int main(){
	int a,b,h;
    b=10;
    h=15;
    a =(b*h)/2;
	printf("base %i\n",b);
    printf("altura %i\n", h);
    printf("area %i\n", a );
	return 0;
}