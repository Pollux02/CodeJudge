//Ejercicio=20
//NickName=SieteDos
//Tiempo=01:45
#include <stdio.h>
#include <locale.h>

#define PRIMAVERA_PRIMER_MES 3
#define PRIMAVERA_ULTIMO_MES 6
#define PRIMAVERA_PRIMER_DIA 21
#define PRIMAVERA_ULTIMO_DIA 20

#define VERANO_PRIMER_MES 6
#define VERANO_ULTIMO_MES 9
#define VERANO_PRIMER_DIA 21
#define VERANO_ULTIMO_DIA 22

#define OTONIO_PRIMER_MES 9
#define OTONIO_ULTIMO_MES 12
#define OTONIO_PRIMER_DIA 23
#define OTONIO_ULTIMO_DIA 21


#define INVIERNO_PRIMER_MES 12
#define INVIERNO_ULTIMO_MES 3
#define INVIERNO_PRIMER_DIA 21
#define INVIERNO_ULTIMO_DIA 20

#define CANTIDAD_DE_MESES 12
#define CANTIDAD_DE_DIAS_EN_FEBRERO 28

#define C_0 0
#define C_1 1


#define MES_DE_FEBRERO 2
#define CANTIDAD_DE_DIAS_EN_EL_MES 31


//Enero 1, Febrero 2, Marzo 3, Abril 4, Mayo 5, Junio 6, Julio 7,
//Aug 8, septiembre 9, octubre 10, Nov 11, Diciembre 12


int main()
{

    const char* MESES[CANTIDAD_DE_MESES] = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio","Julio",
    "Agosto","Septiembre","Octubre", "Noviembre","Diciembre"};

    short int mesAnio, diaAnio;

    //Primavera 21 de marzo - 20 de junio

    //Verano 21 junio - 23 septiembre

    //Otonio 23 de septiembre - 21 diciembre

    //Invierno 21 de diciembre - 20 de marzo

    setlocale(LC_ALL, "spanish");


    printf("Digite un mes del año  : ");
    scanf("%hi", &mesAnio);
    printf("Digite un día del mes  : ");
    scanf("%hi", &diaAnio);


    //Comprobacion de datos

        if (mesAnio > CANTIDAD_DE_MESES || mesAnio <= C_0)
        {

            printf("Error: El mes que proporciono no existe!");
            return 0;
        }

        else if (mesAnio == MES_DE_FEBRERO && ((diaAnio > CANTIDAD_DE_DIAS_EN_FEBRERO) || (diaAnio <= C_0)))
        {
            printf("Error: el día que proporciono no concuerda con un día del mes");
            return 0;
        }

        else if ( diaAnio > CANTIDAD_DE_DIAS_EN_EL_MES || diaAnio <= C_0)
        {
            printf("Error: el día que proporciono no concuerda con un dia del mes");
            return 0;

        }



    /// Estacion Primavera

    if  (mesAnio > PRIMAVERA_PRIMER_MES && mesAnio < PRIMAVERA_ULTIMO_MES)
    {
        printf("Es Primavera y el mes es %s", MESES[mesAnio-C_1]);
    }


    else if (mesAnio == PRIMAVERA_PRIMER_MES && diaAnio >= PRIMAVERA_PRIMER_DIA)
    {
        printf("Es Primavera y el mes es %s", MESES[mesAnio-C_1]);
    }

    else if (mesAnio == PRIMAVERA_ULTIMO_MES && diaAnio <= PRIMAVERA_ULTIMO_DIA)
    {

        printf("Es Primavera y el mes es %s", MESES[mesAnio-C_1]);
    }


    /// Estacion Verano



    else if (mesAnio > VERANO_PRIMER_MES && mesAnio < VERANO_ULTIMO_MES)
    {
        printf("Es Verano y el mes es %s", MESES[mesAnio-C_1]);
    }



    else if (mesAnio == VERANO_PRIMER_MES && diaAnio >= VERANO_PRIMER_DIA)
    {
        printf("Es Verano y el mes es %s", MESES[mesAnio-C_1]);

    }

    else if (mesAnio == VERANO_ULTIMO_MES && diaAnio <= VERANO_ULTIMO_DIA)
    {

        printf("Es Verano y el mes es %s", MESES[mesAnio-C_1]);
    }



    /// Estacion Otoño


    else if (mesAnio > OTONIO_PRIMER_MES && mesAnio < OTONIO_ULTIMO_MES)
    {
    printf("Es Otoño y el mes es %s", MESES[mesAnio-C_1]);
    }

    else if (mesAnio == OTONIO_PRIMER_MES && diaAnio >= OTONIO_PRIMER_DIA)
    {
        printf("Es Otoño y el mes es %s", MESES[mesAnio-C_1]);
    }

    else if (mesAnio == OTONIO_ULTIMO_MES && diaAnio <= OTONIO_ULTIMO_DIA)
    {

    printf("Es Otoño y el mes es %s", MESES[mesAnio-C_1]);


    }



    /// Estacion Invierno


    else if (mesAnio < INVIERNO_PRIMER_MES && mesAnio < INVIERNO_ULTIMO_MES)
    {
        printf("Es Invierno y el mes es %s", MESES[mesAnio-C_1]);

    }

    else if (mesAnio == INVIERNO_PRIMER_MES && diaAnio >= INVIERNO_PRIMER_DIA)
    {
        printf("Es Invierno y el mes es %s", MESES[mesAnio-C_1]);

    }

    else if (mesAnio == INVIERNO_ULTIMO_MES && diaAnio <= INVIERNO_ULTIMO_DIA)
    {
        printf("Es Invierno y el mes es %s", MESES[mesAnio-C_1]);
    }


    return 0;
}
