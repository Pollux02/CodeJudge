#include<iostream>

using namespace std;

int main(){
    float f,c;
    cout<<"Digite la temperatura en grados Celsius: ";cin>>c;
    f=1.8*c+32;
    cout<<c<<"° Celsius en Fahrenheit son: "<<f<<"°\n";
    return 0;
}