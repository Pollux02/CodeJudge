#include <iostream>

using namespace std;

int main()
{
    cout <<"Conversion de grados Celsius a Fahrenheit :D\n\n"<< endl;
    cout <<"***************************************************************************************"<< endl;
    int C;

        cout <<"Ingrese los Celsius que desea convertir a Fahrenheit: ";
        cin >> C;

    float F=1.8*C+32;

    cout <<"\nEl valor que ingreso fue " << C << " Celsius\n"<< endl;
        cout <<"\nLa equivalencia de " << C << " Celsius a Fahrenheit es " << F << "F \n "<<endl;

    cout <<"\n***************************************************************************************"<< endl;
    return 0;
}
