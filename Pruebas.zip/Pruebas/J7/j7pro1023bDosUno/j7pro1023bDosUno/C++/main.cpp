#include <iostream>

using namespace std;

int main()
{
    float celsius, formula;
    cout << "Bienvenido a conversor de grados celcius a Grados Fahrenheit"<< endl;
    cout << "Ingrese los grados celcius que desea convertir:";
    cin >> celsius;
    formula= 1.8*celsius+32;
    cout <<celsius<< " grados Centigrados convertidos a Fahrenheit dan: " <<formula<< endl;

    return 0;
}
