#include <iostream>

using namespace std;

int main()
{
    float F,C;
    cout << "Ingrese los grados en C a convertir a F: ";
    cin >> C;
    F= 1.8*C+32;
    cout << "Los grados Celsius ingresados son:" << C << endl << endl;
    cout << "Los grados Fahrenheit convertidos son: " << F << endl;
    return 0;
}
