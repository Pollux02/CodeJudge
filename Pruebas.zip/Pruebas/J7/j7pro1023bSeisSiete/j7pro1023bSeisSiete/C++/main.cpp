#include <iostream>

using namespace std;
const float C_18 = 1.8;
const int C_32 = 32;

int main()
{
    int celsius;
    float fahrenheit;

    cout << "CONVERSION DE GRADOS CELSIUS A FAHRENHEIT" << endl;
    cout << "Dame el valor numerico de los grados celsius sin escribir el sistema de medida:" << endl;
    cin >> celsius;
    fahrenheit = C_18*celsius+C_32;
    cout << "El valor de " << celsius << " C a Farenheit es: "<< fahrenheit << " F" << endl;

    return 0;
}
