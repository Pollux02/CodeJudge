#include <iostream>

using namespace std;

int main()
{
    float  gradosCelsius, gradosFahrenheit;
    cout << "Convertir de grados Celsius a Fahrenheit." << endl;

    cout << "Ingresa los grados Celsius: ";
    cin >>gradosCelsius;

    gradosFahrenheit = 1.8 * gradosCelsius + 32;

    cout<<"\n"<<gradosCelsius<<" grados Celsius son "<<gradosFahrenheit<<" grados Fahrenheit"<<endl;

    return 0;
}
