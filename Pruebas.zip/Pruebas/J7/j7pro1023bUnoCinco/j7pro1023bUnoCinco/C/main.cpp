#include <iostream>

using namespace std;

int main()
{
    cout << "De celcius a fahrenheit" << endl;
    float c,f;
    cin >> c;
    cout << "El valor de celcius es :"<<c <<endl;

    f=1.8*c+32;
    cout << "Los fahrenheit son:"<<f <<endl;

    return 0;
}
