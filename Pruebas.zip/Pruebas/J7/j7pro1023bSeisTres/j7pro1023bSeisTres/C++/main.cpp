#include <iostream>

using namespace std;

int main()
{
    float celsius,fahrenheit;
    cout << "Converir grados Celsius a Fahrenheit" << endl;
    cout << "Ingrese la cantidad de grados Celsius: ";
    cin >> celsius;
    fahrenheit = 1.8*celsius+32;
    cout << "Grados celsius: ";
    cout << celsius <<endl;
    cout << "Tus grados Fahrenheit son: ";
    cout << fahrenheit << endl;
    return 0;
}
