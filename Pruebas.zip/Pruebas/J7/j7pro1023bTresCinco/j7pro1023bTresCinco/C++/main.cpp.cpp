#include <iostream>

using namespace std;

int main()
{
    float c,f;
    cout << "Conversion de Celsius a fahrenheit" << endl;
    cout << "Ingresa los grados C a convertir: ";
    cin >> c;

    f= 1.8*c+32;

    cout <<endl <<"Grados Celsius: " << c <<endl;
    cout << "Grados convertidos a fahrenheit: " << f <<endl;

    return 0;
}
