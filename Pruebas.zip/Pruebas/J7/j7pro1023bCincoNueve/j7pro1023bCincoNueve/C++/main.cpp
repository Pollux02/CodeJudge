#include <iostream>

using namespace std;

int main()

{   cout << "Conversion de grados Celsius a Fahrenheit" << endl << endl;
    float celsius, fahrenheit;
    cout << "Ingrese la temperatura en grados Celsius: " ;
    cin >> celsius;
    fahrenheit  = 1.8 * celsius + 32;
    cout <<celsius << " grados Celsius equivalen a " << fahrenheit << " grados Fahrenheit " << endl;

    return 0;
}
