#include <iostream>

using namespace std;

int main()
{
    float celsius, farenheit;
    cout << "Conversion de grados Celsius a Farenheit" << endl << endl;
    cout << "Ingrese el valor en Celsius que desea convertir: ";
    cin >> celsius;

    farenheit= 1.8*celsius+32;

    cout << "El resultado de su conversion es: " << farenheit << endl;

    return 0;
}
