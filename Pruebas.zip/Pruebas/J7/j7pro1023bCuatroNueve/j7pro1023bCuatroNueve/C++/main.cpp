#include <iostream>

using namespace std;

int main()
{
     float gradosCelsius,gradosFahrenheit;
     cout << "Dame la cantidad de grados celsius a convertir: ";
     cin >> gradosCelsius;
     cout << "  " << endl;
     gradosFahrenheit = 1.8*gradosCelsius+32;
     cout << "La convercion a grados Fahrenheit es: " << gradosFahrenheit;
    return 0;
}
