#include <iostream>

using namespace std;

int main()
{
    float cel;

    cout<< "Conversion de grados Celsius a Fahrenheit"<< endl << endl;
    cout << "Por favor, ingrese los grados a convertir:";
    cin >> cel;
    cout << endl;

    cout << cel << " grados Celsius = " << 1.8*cel+32 << " grados Fahrenheit"<<endl;
    return 0;
}
