#include <iostream>

using namespace std;

int main()
{
    float C, F;
    cout << "Grados Celsius a Farenheit\n" << endl;
    cout << "Dame el valor de Celsius a convertir: ";
    cin >> C;
    F = 1.8 * C + 32;
    cout << "\nCelsius = " << C << endl;
    cout << "Valor de Celcius a Farenheit =  " << F << endl;
    return 0;
}
