#include <iostream>

using namespace std;

int main()
{
    float C, F;
    cout << "Inserte los grados Celcius: ";
    scanf("%f", &C);
    F=1.8*C+32;
    cout << endl << "Tus grados Celcius son: " << C << endl << "Tu conversion de Celcius a Farenheit son igual a: " << F << endl;


    return 0;
}
