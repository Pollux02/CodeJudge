#include <iostream>

using namespace std;
int main()
{
    float gradosCelsius;

    cout << "#########################################" << endl;
    cout << "CONVERTIDOR DE GRADOS CELSIUS A FARENHEIT" << endl;
    cout << "#########################################" << endl;
    cout << "Ingrese los grados Celsius que desee convertir a Farenheit\n";
    cin >> gradosCelsius;

    cout << gradosCelsius << " grados Celsius"
    << " son iguales a " << (1.8 * gradosCelsius + 32) << " grados Farenheit";





    return 0;
}
