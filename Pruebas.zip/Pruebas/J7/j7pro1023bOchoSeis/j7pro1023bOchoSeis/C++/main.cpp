#include <iostream>

using namespace std;

int main()
{
    float  celcius, fahrenheit;

    cout << "Ingrese los grados Celsius para convertir a Fahrenheit: " << endl;
    cin >> celcius;

    fahrenheit = (1.8 * celcius) + 32;

    cout << "\nLos grados celcius son: " << celcius << "\n";
    cout << "Los grados farenheit son: " << fahrenheit << "\n";

    return 0;
}
