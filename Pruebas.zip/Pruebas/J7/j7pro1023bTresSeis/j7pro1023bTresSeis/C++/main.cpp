#include <iostream>

using namespace std;

int main()
{
    float celcius, fahrenheit;
    cout << "Conversion de grados Celsius a Fahrenheit" << endl;

    cout << "Ingrese el valor de Celsius: ";
    cin >> celcius;

    fahrenheit= 1.8*celcius+32;

    cout << "Celsius: " << celcius << endl;
    cout << "Fahrenheit: " << fahrenheit << endl;

    return 0;
}
