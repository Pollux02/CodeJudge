#include <iostream>

using namespace std;

int main()
{
    cout << "Programa dise�ado para la combercion de grados" << endl<<endl<<endl;
    float gradosCelsius,gradosFahrenheit;
    cout <<"Dame los grados celsiuls:";
    cin >>gradosCelsius;
    gradosFahrenheit=1.8*gradosCelsius;
    cout <<endl<<endl<<"Los grados celsius en fahrenheit son :"<<gradosFahrenheit+32;
    cout <<endl<<endl;
    return 0;
}
