
//SieteSiete

#include<iostream>

using namespace std;

int main(){
    float fahrenheit, celsius;
    cout<<"Escribe la cantidad en celsius a transformar"<<endl;
    cin>>celsius;
    
    fahrenheit= 1.8*celsius+32;
    
    cout<<celsius<<" grados celcius es igual a "<<fahrenheit<<" grados fahrenheit";
    
}