#include <iostream>
using namespace std;

int main()
{

    float celsius, fahrenheit;

    cout << "Ingrese la temperatura en grados Celsius: ";
    cin >> celsius;

    fahrenheit = 1.8 * celsius + 32;

    cout << "Temperatura en grados Fahrenheit: " << fahrenheit << " �F" << endl;

    return 0;
}
