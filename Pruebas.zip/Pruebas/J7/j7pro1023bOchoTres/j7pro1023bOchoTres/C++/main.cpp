#include <iostream>

using namespace std;

int main()
{
    float celsius,fahrenheit;
    cout<<"Conversion de grados a Fahrenheit"<<endl<<endl;
    cout << "Ingresa los grados Celsius:";
    cin>>celsius;
    fahrenheit=(1.8*celsius)+32;
    cout<<"El valor de "<<celsius<<" Celsius en Fahrenheit es:"<<fahrenheit<<endl;
    return 0;
}
