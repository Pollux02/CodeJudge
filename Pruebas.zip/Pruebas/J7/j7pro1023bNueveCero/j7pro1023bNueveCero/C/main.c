#inlcude<iostream>
using namespace std;
int main(){
    int c,f;
    cout<<"grados celsius: "<<endl;
    cin>>c;
    f=1.8*c*32;
    cout<<"grados Celsius: "<<c<<" => Farenheit: "<<f<<endl;
    return 0;
}
