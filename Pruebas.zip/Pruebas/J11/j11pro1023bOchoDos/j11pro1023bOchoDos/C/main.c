#include<stdio.h>

int main(){

    int a,b,c,aux;

    a=10;
    b=12;
    c=13;

    printf("EL valor inicial de a=%d\n",a);
    printf("EL valor inicial de b=%d\n",b);
    printf("EL valor inicial de c=%d\n",c);

    aux=b;
    b=a;
    a=c;
    c=aux;
    printf("\n");
    printf("EL valor final de a=%d\n",a);
    printf("EL valor final de b=%d\n",b);
    printf("EL valor final de c=%d\n",c);


    return 0;
}