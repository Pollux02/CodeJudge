#include <stdio.h>
#include <stdlib.h>

int main()
{

    int a,b,c;
    a = 80;
    b = 500;
    c = 0;

    printf("Valor de 'a' antes del intercambio : %d\n", a);
    printf("Valor de 'b' antes del intercambio : %d\n", b);
    printf("Valor de 'c' antes del intercambio : %d\n\n", c);

    //Intercambio 1

    a = a + c;
    c = a - c;
    a = a - c;

    //Intercambio 2

    b = b + c;
    c = b - c;
    b = b - c;



    printf("Valor de 'a' despues del intercambio : %d (valor c)\n", a);
    printf("Valor de 'b' despues del intercambio : %d (Valor a)\n", b);
    printf("Valor de 'c' despues del intercambio : %d (Valor b)\n", c);



    return 0;
}
