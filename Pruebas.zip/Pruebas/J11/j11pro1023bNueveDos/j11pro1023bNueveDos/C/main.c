#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, auxiliar;

    a = 10;
    b = 15;
    c = 20;

    printf("Valor inicial de a es %d\n", a);
    printf("Valor inicial de b es %d\n", b);
    printf("Valor inicial de c es %d\n", c);

    auxiliar = b;
    b = a;
    a = c;
    c = auxiliar;

    printf("\nValor final de a es %d\n", a);
    printf("Valor final de b es %d\n", b);
    printf("Valor final de c es %d\n", c);

    return 0;
}
