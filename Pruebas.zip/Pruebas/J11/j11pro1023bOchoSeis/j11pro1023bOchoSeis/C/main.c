#include<stdio.h>

int main(){
	int a=3, b=6, c=9, d=0;
	
	printf("El valor de a es: %d\n", a);
	printf("El valor de b es: %d\n", b);
	printf("El valor de c es: %d\n", c);
	
	d = a;
	a = c;
	c = b;
	b = d;
	
	printf("\nEl nuevo valor de a es: %d\n", a);
	printf("El nuevo valor de b es: %d\n", b);
	printf("El nuevo valor de c es: %d\n", c);
	
	return 0;
}
