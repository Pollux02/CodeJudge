a = 3
b = 6
c = 9
d = 0

print("El valor de a es: {}".format(a))
print("El valor de b es: {}".format(b))
print("El valor de c es: {}".format(c))

a, c, b, d = c, b, a, d

print("\nEl valor de a es: {}".format(a))
print("El valor de b es: {}".format(b))
print("El valor de c es: {}".format(c))
