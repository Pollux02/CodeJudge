#include<iostream>

using namespace std;

int main(){
	int a=3, b=6, c=9, d=0;
	
	cout << "El valor de a es: " << a << endl;
	cout << "El valor de b es: " << b << endl;
	cout << "El valor de c es: " << c << endl;
	
	d = a;
	a = c;
	c = b;
	b = d;
	
	cout << "\nEl valor de a es: " << a << endl;
	cout << "El valor de b es: " << b << endl;
	cout << "El valor de c es: " << c << endl;
	
	
	return 0;
}
