#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c;
    printf("Dame el valor para a:");
    scanf("%d",&a);
    printf("Dame el valor para b:");
    scanf("%d",&b);
    printf("Dame el valor para c:");
    scanf("%d",&c);

    printf("\n\nLos valores originales de a, b y c son\n");
    printf("a: %d",a);
    printf("\nb: %d",b);
    printf("\nc: %d",c);

    int X;
    X=a;
    a=c;
    c=b;
    b=X;
    printf("\n\nSi a tomara el valor de c, c el de b y b el de a, quedaria:\n");
    printf("\na: %d",a);
    printf("\nb: %d",b);
    printf("\nc: %d",c);

    return 0;
}
