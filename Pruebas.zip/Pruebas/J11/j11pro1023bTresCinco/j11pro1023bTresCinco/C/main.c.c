#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,va;

    a=15;
    b=20;
    c=25;

    printf("valor inicial de a: %d\n",a);
    printf("valor inicial de b: %d\n",b);
    printf("valor inicial de c: %d\n\n",c);

    va=a;
    a=b;
    b=c;
    c=va;

    printf("valor de a: %d\n",a);
    printf("valor de b: %d\n",b);
    printf("valor de c: %d\n",c);


    return 0;
}
