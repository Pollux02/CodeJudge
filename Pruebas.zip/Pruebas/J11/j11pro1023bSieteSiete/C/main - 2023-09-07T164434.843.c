//SieteSiete
#include <stdio.h>
#define UNO 1
#define DOS 2
#define TRES 3
int main()
{
    int a=UNO,b=DOS,c=TRES, aux;
    printf("El valor de a es %i\n", a);
    printf("El valor de b es %i\n",b);
    printf("El valor de c es %i\n", c);
    aux = a;
    a = c;
    c =b;
    b = aux;
    //312
    printf("El valor de a es %i\n", a);
    printf("El valor de b es %i\n",b);
    printf("El valor de c es %i", c);    
    return 0;
}
