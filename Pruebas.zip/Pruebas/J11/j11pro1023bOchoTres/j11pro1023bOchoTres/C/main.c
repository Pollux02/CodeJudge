#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
#define clear "cls"
#elif defined(unix)||defined(_unix)||defined(unix)||defined(APPLE)||defined(MACH_)
#define clear "clear"
#else
#error "SO no soportado para limpiar pantalla"
#endif

int main()
{
    system(clear);
    int a,b,c,x;
    printf("INTERCAMBIO DE VALORES:\n\n");
    printf("Ingresa el valor de la variable a:");
    scanf("%d",&a);
    printf("Ingresa el valor de la variable b:");
    scanf("%d",&b);
    printf("Ingresa el valor de la variable c:");
    scanf("%d",&c);

    system(clear);
    printf("Valores iniciales:\n");
    printf("a=%d",a);
    printf("\nb=%d",b);
    printf("\nc=%d",c);

    x=a;
    a=c;
    c=b;
    b=x;

    printf("\n\nLos nuevos valores son:\n");
    printf("a=%d",a);
    printf("\nb=%d",b);
    printf("\nc=%d",c);


    return 0;
}
