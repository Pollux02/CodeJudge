#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, d;
    printf("*** INTERCAMBIO DE VALORES ***\n\n");
    printf("Ingrese el valor para a: ");
    scanf("%d", &a);
    printf("Ingrese el valor para b: ");
    scanf("%d", &b);
    printf("Ingrese el valor para c: ");
    scanf("%d", &c);
    printf("\n\nValores Originales\n\n");
    printf("Valor de a es = %d\n",a);
    printf("Valor de b es = %d\n",b);
    printf("Valor de c es = %d\n\n",c);
    d = a;
    a = c;
    c = b;
    b = d;
    printf("Valores despues del intercambio\n\n");
    printf("Valor de a es = %d\n",a);
    printf("Valor de b es = %d\n",b);
    printf("Valor de c es = %d\n\n",c);
    return 0;
}
