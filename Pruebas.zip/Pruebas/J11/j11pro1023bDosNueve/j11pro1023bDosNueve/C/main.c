#include <stdio.h>
#include <stdlib.h>


int main() {
    int a, b, c, temp;

    a = 10;
    b = 20;
    c = 30;

    printf("Valores originales:\n");
    printf("Valor de a es %d\n", a);
    printf("Valor de b es %d\n", b);
    printf("Valor de c es %d\n", c);

    temp = c;
    c = a;
    a = b;
    b = temp;

    printf("\nValores despu�s del intercambio:\n");
    printf("Valor de a es %d\n", a);
    printf("Valor de b es %d\n", b);
    printf("Valor de c es %d\n", c);

    return 0;
}
