#include <stdio.h>
#include <stdlib.h>

int main(){
    int a,b,c,x;
    printf("indica a: ");
    scanf("%d",&a);
    printf("indica b: ");
    scanf("%d",&b);
    printf("indica c: ");
    scanf("%d",&c);

    printf("Valor de a es %d\n",a);
    printf("valor de b es %d\n",b);
    printf("Valor de c es %d\n\n",c);

    x=c;

    c=b;
    b=a;
    a=x;

    printf("Valor de a es %d\n",a);
    printf("valor de b es %d\n",b);
    printf("Valor de c es %d\n",c);

}
