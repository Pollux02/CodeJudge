#include <stdio.h>
#include <stdlib.h>

int main(){
    int a, b, c, aux;
    printf("---Intercambio de valores---\n\n");
    a = 879;
    b = 456;
    c = 561;
    printf("Valor de a: %d\n", a);
    printf("Valor de b: %d\n", b);
    printf("Valor de c: %d\n", c);

    printf("\nVariables intercambiadas:\n");
    aux = a;
    a = c;
    c = b;
    b = aux;
    printf("Nuevo valor de a: %d\n", a);
    printf("Nuevo valor de b: %d\n", b);
    printf("Nuevo valor de c: %d\n", c);
    return 0;
}
