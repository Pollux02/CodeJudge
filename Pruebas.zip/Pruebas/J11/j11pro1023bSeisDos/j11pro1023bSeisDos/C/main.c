#include <stdio.h>
#include <stdlib.h>


int main()
{
    int a = 10;
    int b = 20;
    int c = 30;
    int temp;
    
	printf("Intercambio de valores :D\n\n");
    printf("*******************************************************************************\n\n");

    printf("Valores originales:\n");
    printf("Valor de a es %d\n", a);
    printf("Valor de b es %d\n", b);
    printf("Valor de c es %d\n", c);

    temp = c;
    c = a;
    a = b;
    b = temp;

    printf("\nValores intercambiados:\n");
    printf("Valor de a es %d\n", a);
    printf("Valor de b es %d\n", b);
    printf("Valor de c es %d\n", c);

    printf("*******************************************************************************\n\n");
return 0;
}
