#include <stdio.h>
#include <stdlib.h>
int main() {
    int x;
    int a = 10; 
    int b = 20; 
    int c = 30; 

    printf("Valor original de a es %d\n", a);
    printf("Valor original de b es %d\n", b);
    printf("Valor original de c es %d\n", c);

  

    x = a;
    a = c;
    c = b;
    b = x;

    printf("Después del intercambio:\n");
    printf("Valor de a es %d\n", a);
    printf("Valor de b es %d\n", b);
    printf("Valor de c es %d\n", c);

    return 0;
}
 
