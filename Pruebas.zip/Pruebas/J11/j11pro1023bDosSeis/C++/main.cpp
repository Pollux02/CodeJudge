#include <iostream>

using namespace std;

int main()
{   int a,b,c,temporal;
    cout << "Inserte el valor de a :" << endl;
    cin >> a;
    cout << "Inserte el valor de b: " << endl;
    cin >> b;
    cout << "Inserte el valor de c: " << endl;
    cin >> c;
    cout << endl << endl <<  "El valor de a es: " << a << endl << endl;
    cout << "El valor de b es: " << b << endl << endl;
    cout << "El valor de c es: " << c << endl << endl << endl << endl;
    temporal=a;
    a=c;
    c=b;
    b=temporal;
    cout << "El valor de a despues del intercambio es: " << a << endl << endl;
    cout << "El valor de b despues del intercambio es: " << b << endl << endl;
    cout << "El valor de c despues del intercambio es: " << c << endl << endl;

    return 0;
}
