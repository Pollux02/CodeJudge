#include <stdio.h>
#include <stdlib.h>

int main()
{   int a,b,c, temporal;
    printf("Inserte los valores de a: ");
    scanf("%d", &a);
    printf("Inserte los valores de b: ");
    scanf("%d", &b);
    printf("Inserte los valores de c: ");
    scanf("%d", &c);
    printf("\n\nEl valor de a es: %d\n\n", a);
    printf("El valor de b es: %d\n\n", b);
    printf("El valor de c es: %d\n\n", c);
    temporal=a;
    a=c;
    c=b;
    b=temporal;
    printf("\n\nEl valor de a despues del intercambio es: %d\n\n", a);
    printf("El valor de b despues del intercambio es: %d\n\n", b);
    printf("El valor de c despues del intercambio es: %d\n\n", c);
    return 0;
}
