#include <iostream>

using namespace std;

#define CLEAR "cls"
int main()
{
     int a,b,c;
    cout <<"Dame el valor de a:" << endl;
    cin >> a;
    cout <<"Dame el valor de b:" << endl;
    cin >> b;
    cout <<"Dame el valor de c:" << endl;
    cin >> c;

    system(CLEAR);
    cout << "Valor de a es " << a << endl;
    cout << "Valor de b es " << b << endl;
    cout << "Valor de c es " << c << endl << endl << endl;

    int aux = c;
    c = a;
    a = b;
    b = aux;

    cout << "Despues del intercambio:" << endl << endl;
    cout << "Valor de a es " << a << endl;
    cout << "Valor de b es " << b << endl;
    cout << "Valor de c es " << c << endl;

    return 0;
}
