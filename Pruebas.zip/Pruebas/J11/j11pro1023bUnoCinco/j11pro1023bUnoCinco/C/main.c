#include <stdio.h>
#include <stdlib.h>
#define CLEAR "cls"
int main()
{
    int a,b,c;
    printf("Dame el valor de a:\n");
    scanf("%d",&a);
    printf("Dame el valor de b:\n");
    scanf("%d",&b);
    printf("Dame el valor de c:\n");
    scanf(" %d",&c);
    system(CLEAR);
    printf("Valor de a es %d\n", a);
    printf("Valor de b es %d\n", b);
    printf("Valor de c es %d\n\n\n", c);

    int aux = c;
    c = a;
    a = b;
    b = aux;

    printf("Despues del intercambio:\n\n");
    printf("Valor de a es %d\n", a);
    printf("Valor de b es %d\n", b);
    printf("Valor de c es %d\n", c);
    return 0;
}
