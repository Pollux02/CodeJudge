#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,cambio;
    printf("Escriba el valor de a: ");
    scanf("%d", &a);
    printf("Escriba el valor de b: ");
    scanf("%d", &b);
    printf("Escriba el valor de c: ");
    scanf("%d", &c);

    printf("\n\nEl valor principal de a es: %d", a);
    printf("\nEl valor principal de b es: %d", b);
    printf("\nEl valor principal de c es: %d", c);

    cambio=a;
    a=c;
    c=b;
    b=cambio;

    printf("\n\nEl valor cambiado de a es: %d", a);
    printf("\nEl valor cambiado de b es: %d", b);
    printf("\nEl valor cambiado de c es: %d", c);

    return 0;
}
