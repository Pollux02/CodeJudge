#include <iostream>

using namespace std;
#define CLEAR cls
int main()
{
    int a,b,c,b1;
    cout << "---INTERCAMBIO DE VARIABLES---" << endl << endl;
    cout << "Ingresa el valor de a: ";
    cin >> a;
    cout << "Ingresa el valor de b: ";
    cin >> b;
    cout << "Ingresa el valor de c: ";
    cin >> c;

    system("cls");

    cout << "---INTERCAMBIO DE VARIABLES---" << endl << endl;
    cout << "El valor original de a es: " << a << endl;
    cout << "El valor original de b es: " << b << endl;
    cout << "El valor original de c es: " << c << endl << endl;

    b1=b;
    b=a;
    a=c;
    c=b1;

    cout << "El nuevo valor de a es: " << a << endl;
    cout << "El nuevo valor de b es: " << b << endl;
    cout << "El nuevo valor de c es: " << c << endl;


    return 0;
}
