#include <stdio.h>
#include <stdlib.h>
#define CLEAR cls

int main()
{
    int a,b,c,b1;
    printf("---INTERCAMBIO DE VARIABLES---\n\n");
    printf("Ingrese el valor de a: ");
    scanf("%d",&a);
    printf("Ingrese el valor de b: ");
    scanf("%d",&b);
    printf("Ingrese el valor de c: ");
    scanf("%d",&c);

    system("cls");

    printf("---INTERCAMBIO DE VARIABLES---\n\n");
    printf("El valor original de a es %d\n",a);
    printf("El valor original de b es %d\n",b);
    printf("El valor original de c es %d\n\n",c);

    b1=b;
    b=a;
    a=c;
    c=b1;

    printf("El nuevo valor de a es: %d\n",a);
    printf("El nuevo valor de b es: %d\n",b);
    printf("El nuevo valor de c es: %d\n",c);
    return 0;
}
