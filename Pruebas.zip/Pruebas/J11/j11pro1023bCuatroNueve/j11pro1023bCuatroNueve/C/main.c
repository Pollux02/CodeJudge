#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,x;
    printf("Intercambio de valores\n\n");
    a=10;
    b=20;
    c=30;
    printf("El valor original de a es: %d\n", a);
    printf("El valor original de b es: %d\n", b);
    printf("El valor original de c es: %d\n", c);
    printf("\nIntercambio de valores\n");
    x=a;
    a=c;
    c=b;
    b=x;
    printf("El valor de a es: %d\n", a);
    printf("El valor de b es: %d\n", b);
    printf("El valor de c es: %d\n", c);
    return 0;
}
