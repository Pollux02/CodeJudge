#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c;
    a=45;
    b=40;
    c=35;
    printf("************************************************\n");
    printf("Valor original\n");
    printf("El valor de a es: %d\n",a);
    printf("El valor de b es: %d\n",b);
    printf("El valor de c es: %d\n",c);
    printf("************************************************\n");

    a=452;
    b=494;
    c=472;

    printf("************************************************\n");
    printf("Valor intercambiado\n");
    printf("El valor de a es: %d\n",a);
    printf("El valor de b es: %d\n",b);
    printf("El valor de c es: %d\n",c);
    printf("************************************************\n");
    return 0;
}
