#include <iostream>
#define ENDL "\n"
using namespace std;

int main(){
    int a, b, c, x;

    a = 1;
    b = 2;
    c = 3;

    cout << "*** VALOR ORIGINAL ***" << endl;
    cout << "Valor de a: " << a << endl;
    cout << "Valor de b: " << b << endl;
    cout << "Valor de c: " << c << ENDL <<endl;

    x = a;
    a = c;
    c = b;
    b = x;

    cout << "*** VALOR DESPUES DEL INTERCAMBIO***" << endl;
    cout << "Valor de a: " << a << endl;
    cout << "Valor de b: " << b << endl;
    cout << "Valor de c: " << c <<endl;

    return 0;
}
