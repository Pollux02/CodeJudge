#include <stdio.h>
#include <stdlib.h>

int main() {
        int a, b, c, x;

    a = 1;
    b = 2;
    c = 3;
    printf("\n***Valores Originales***\n");
    printf("Valor de a: %d\n", a);
    printf("Valor de b: %d\n", b);
    printf("Valor de c: %d\n", c);

    x = a;
    a = c;
    c = b;
    b = x;

    printf("\n***Valores Cambiados***\n");
    printf("Valor de a: %d\n", a);
    printf("Valor de b: %d\n", b);
    printf("Valor de c: %d\n", c);
    return 0;
}

