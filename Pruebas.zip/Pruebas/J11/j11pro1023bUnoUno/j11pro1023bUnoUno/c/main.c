#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Programa de intercambio de bariables:n\n");
    int variableA,variableB,variableC,variableI;
    printf("Dame la variable a:");
    scanf("%d",&variableA);
    printf("Dame la variable b:");
    scanf("%d",&variableB);
    printf("Dame la variable c:");
    scanf("%d",&variableC);
    printf("\n\n\n Variables originales:\n");
    printf("\n variable a:%d",variableA);
    printf("\n variable b:%d",variableB);
    printf("\n variable c:%d",variableC);
    printf("\n\n Variables intercambiadas:\n\n");
    variableI=variableA;
    variableA=variableB;
    variableB=variableC;
    variableC=variableI;
    printf(" valor de a = %d",variableA);
    printf("\n valor de b = %d",variableB);
    printf("\n valor de c = %d",variableC);
    return 0;
}
