/* CuatroNueve, j13pro1023b, Tiempo=01:25 */
#include <stdio.h>
#include <stdlib.h>
#define NUMEROS_ENTEROS 10
#define VALOR_MAXIMO 100
#define VALOR_MINIMO 1
int main()
{   int numeros[NUMEROS_ENTEROS],valoresMultiplicados,valores,factor;

    printf("Dijite el valor #1 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[0]=valores;
    printf("Dijite el valor #2 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[1]=valores;
     printf("Dijite el valor #3 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[2]=valores;
     printf("Dijite el valor #4 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[3]=valores;
     printf("Dijite el valor #5 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[4]=valores;
     printf("Dijite el valor #6 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[5]=valores;
     printf("Dijite el valor #7 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[6]=valores;
     printf("Dijite el valor #8 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[7]=valores;
     printf("Dijite el valor #9 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[8]=valores;
     printf("Dijite el valor #10 (un valor entre %d y %d): ",VALOR_MINIMO
           ,VALOR_MAXIMO);
    scanf("%d",&valores);
    numeros[9]=valores;
    printf("Dijite el factor multiplicador: ");
    scanf("%d",&factor);

    valoresMultiplicados=numeros[0]*factor;
    printf("\nEl resultado del valor #1 es: %d",valoresMultiplicados);
     valoresMultiplicados=numeros[1]*factor;
    printf("\nEl resultado del valor #2 es: %d",valoresMultiplicados);
    valoresMultiplicados=numeros[2]*factor;
    printf("\nEl resultado del valor #3 es: %d",valoresMultiplicados);
    valoresMultiplicados=numeros[3]*factor;
    printf("\nEl resultado del valor #4 es: %d",valoresMultiplicados);
    valoresMultiplicados=numeros[4]*factor;
    printf("\nEl resultado del valor #5 es: %d",valoresMultiplicados);
    valoresMultiplicados=numeros[5]*factor;
    printf("\nEl resultado del valor #6 es: %d",valoresMultiplicados);
    valoresMultiplicados=numeros[6]*factor;
    printf("\nEl resultado del valor #7 es: %d",valoresMultiplicados);
    valoresMultiplicados=numeros[7]*factor;
    printf("\nEl resultado del valor #8 es: %d",valoresMultiplicados);
    valoresMultiplicados=numeros[8]*factor;
    printf("\nEl resultado del valor #9 es: %d",valoresMultiplicados);
    valoresMultiplicados=numeros[9]*factor;
    printf("\nEl resultado del valor #10 es: %d",valoresMultiplicados);
    return 0;
}
