/* CincoNueve, j13pro1023b, Tiempo = 02:36*/
#include <stdio.h>
#include <stdlib.h>

#define CANTIDAD_NUMERO 10
#define RESULTADO_NUMERO 10
int main()
{
    int numeros[CANTIDAD_NUMERO], numero, factor, resultados[RESULTADO_NUMERO];
    printf("*** ARREGLO DE ENTEROS ***\n\n");
    printf("Introduzca un numero para multiplicar los elementos del arreglo: ");
    scanf("%d", &factor);
    printf("Introduzca un valor entero para #1: ");
    scanf("%d",&numero);
    numeros[0] = numero;
    printf("Introduzca un valor entero para #2: ");
    scanf("%d",&numero);
    numeros[1] = numero;
    printf("Introduzca un valor entero para #3: ");
    scanf("%d",&numero);
    numeros[2] = numero;
    printf("Introduzca un valor entero para #4: ");
    scanf("%d",&numero);
    numeros[3] = numero;
    printf("Introduzca un valor entero para #5: ");
    scanf("%d",&numero);
    numeros[4] = numero;
    printf("Introduzca un valor entero para #6: ");
    scanf("%d",&numero);
    numeros[5] = numero;
    printf("Introduzca un valor entero para #7: ");
    scanf("%d",&numero);
    numeros[6] = numero;
    printf("Introduzca un valor entero para #8: ");
    scanf("%d",&numero);
    numeros[7] = numero;
    printf("Introduzca un valor entero para #9: ");
    scanf("%d",&numero);
    numeros[8] = numero;
    printf("Introduzca un valor entero para #10: ");
    scanf("%d",&numero);
    numeros[9] = numero;
    resultados[0]=numeros[0]*factor;
    resultados[1]=numeros[1]*factor;
    resultados[2]=numeros[2]*factor;
    resultados[3]=numeros[3]*factor;
    resultados[4]=numeros[4]*factor;
    resultados[5]=numeros[5]*factor;
    resultados[6]=numeros[6]*factor;
    resultados[7]=numeros[7]*factor;
    resultados[8]=numeros[8]*factor;
    resultados[9]=numeros[9]*factor;
    printf("\n\n*** MULTIPLICADOR ***\n\n");
    printf("El factor es =  %d\n", factor);
    printf("Numeros capturados:\n");
    printf("Numero #1  = %d\n"  ,numeros[0]);
    printf("Numero #2  = %d\n"  ,numeros[1]);
    printf("Numero #3  = %d\n"  ,numeros[2]);
    printf("Numero #4  = %d\n"  ,numeros[3]);
    printf("Numero #5  = %d\n"  ,numeros[4]);
    printf("Numero #6  = %d\n"  ,numeros[5]);
    printf("Numero #7  = %d\n"  ,numeros[6]);
    printf("Numero #8  = %d\n"  ,numeros[7]);
    printf("Numero #9  = %d\n"  ,numeros[8]);
    printf("Numero #10 = %d\n\n",numeros[0]);
    printf("*** RESULTANTE DEL MULTIPLICADOR *** \n");
    printf("%d * %d = %d\n",numeros[0],factor,resultados[0] );
    printf("%d * %d = %d\n",numeros[1],factor,resultados[1] );
    printf("%d * %d = %d\n",numeros[2],factor,resultados[2] );
    printf("%d * %d = %d\n",numeros[3],factor,resultados[3] );
    printf("%d * %d = %d\n",numeros[4],factor,resultados[4] );
    printf("%d * %d = %d\n",numeros[5],factor,resultados[5] );
    printf("%d * %d = %d\n",numeros[6],factor,resultados[6] );
    printf("%d * %d = %d\n",numeros[7],factor,resultados[7] );
    printf("%d * %d = %d\n",numeros[8],factor,resultados[8] );
    printf("%d * %d = %d\n",numeros[9],factor,resultados[9] );
    return 0;
}
