//Nickname=              NueveTres
//N�mero=                j13
//Nombre actividad=      Multiplicador de arreglos
//Tiempo=                1:10

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int enteros[10], multiplicador, resultados[10];
    printf("**********Multiplicador de numeros**********\n\n");
    printf("Ingrese 10 numeros para el arreglo:\n");
    printf("\n1-  Numero: ");
    scanf("%d", &enteros[0]);
    fflush(stdin);
    printf("2-  Numero: ");
    scanf("%d", &enteros[1]);
    fflush(stdin);
    printf("3-  Numero: ");
    scanf("%d", &enteros[2]);
    fflush(stdin);
    printf("4-  Numero: ");
    scanf("%d", &enteros[3]);
    fflush(stdin);
    printf("5-  Numero: ");
    scanf("%d", &enteros[4]);
    fflush(stdin);
    printf("6-  Numero: ");
    scanf("%d", &enteros[5]);
    fflush(stdin);
    printf("7-  Numero: ");
    scanf("%d", &enteros[6]);
    fflush(stdin);
    printf("8-  Numero: ");
    scanf("%d", &enteros[7]);
    fflush(stdin);
    printf("9-  Numero: ");
    scanf("%d", &enteros[8]);
    fflush(stdin);
    printf("10- Numero: ");
    scanf("%d", &enteros[9]);
    fflush(stdin);
    printf("\nAhora ingrese el numero que va a multiplicar a los anteriores: ");
    scanf("%d", &multiplicador);
    printf("\n");

    resultados[0]=multiplicador*enteros[0];
    resultados[1]=multiplicador*enteros[1];
    resultados[2]=multiplicador*enteros[2];
    resultados[3]=multiplicador*enteros[3];
    resultados[4]=multiplicador*enteros[4];
    resultados[5]=multiplicador*enteros[5];
    resultados[6]=multiplicador*enteros[6];
    resultados[7]=multiplicador*enteros[7];
    resultados[8]=multiplicador*enteros[8];
    resultados[9]=multiplicador*enteros[9];


    printf("1-  Resultado %d  x  %d: %d\n",enteros[0], multiplicador, resultados[0]);
    printf("2-  Resultado %d  x  %d: %d\n",enteros[1], multiplicador, resultados[1]);
    printf("3-  Resultado %d  x  %d: %d\n",enteros[2], multiplicador, resultados[2]);
    printf("4-  Resultado %d  x  %d: %d\n",enteros[3], multiplicador, resultados[3]);
    printf("5-  Resultado %d  x  %d: %d\n",enteros[4], multiplicador, resultados[4]);
    printf("6-  Resultado %d  x  %d: %d\n",enteros[5], multiplicador, resultados[5]);
    printf("7-  Resultado %d  x  %d: %d\n",enteros[6], multiplicador, resultados[6]);
    printf("8-  Resultado %d  x  %d: %d\n",enteros[7], multiplicador, resultados[7]);
    printf("9-  Resultado %d  x  %d: %d\n",enteros[8], multiplicador, resultados[8]);
    printf("10- Resultado %d  x  %d: %d\n",enteros[9], multiplicador, resultados[9]);

    return 0;
}
