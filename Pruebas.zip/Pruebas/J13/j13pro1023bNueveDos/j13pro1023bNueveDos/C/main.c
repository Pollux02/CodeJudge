#include <stdio.h>
#include <stdlib.h>

#define CELDAS 10

int main()
{
    int arregloPrincipal[CELDAS];
    int arregloResultante[CELDAS];
    int factor;

    printf("Ingrese 10 valores para las celdas:\n ");
    scanf("%d", &arregloPrincipal[0]);
    scanf("%d", &arregloPrincipal[1]);
    scanf("%d", &arregloPrincipal[2]);
    scanf("%d", &arregloPrincipal[3]);
    scanf("%d", &arregloPrincipal[4]);
    scanf("%d", &arregloPrincipal[5]);
    scanf("%d", &arregloPrincipal[6]);
    scanf("%d", &arregloPrincipal[7]);
    scanf("%d", &arregloPrincipal[8]);
    scanf("%d", &arregloPrincipal[9]);

    printf("\nIngrese el factor para multiplicar: ");
    scanf("%d", &factor);

    arregloResultante[0] = arregloPrincipal[0] * factor;
    arregloResultante[1] = arregloPrincipal[1] * factor;
    arregloResultante[2] = arregloPrincipal[2] * factor;
    arregloResultante[3] = arregloPrincipal[3] * factor;
    arregloResultante[4] = arregloPrincipal[4] * factor;
    arregloResultante[5] = arregloPrincipal[5] * factor;
    arregloResultante[6] = arregloPrincipal[6] * factor;
    arregloResultante[7] = arregloPrincipal[7] * factor;
    arregloResultante[8] = arregloPrincipal[8] * factor;
    arregloResultante[9] = arregloPrincipal[9] * factor;

    printf("\nVector resultante:\n");
    printf("%d\n", arregloResultante[0]);
    printf("%d\n", arregloResultante[1]);
    printf("%d\n", arregloResultante[2]);
    printf("%d\n", arregloResultante[3]);
    printf("%d\n", arregloResultante[4]);
    printf("%d\n", arregloResultante[5]);
    printf("%d\n", arregloResultante[6]);
    printf("%d\n", arregloResultante[7]);
    printf("%d\n", arregloResultante[8]);
    printf("%d\n", arregloResultante[9]);


    return 0;
}
