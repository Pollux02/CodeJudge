#include <stdio.h>
#include <stdlib.h>
#define CLEAR ("cls")

//DosSeis
//Ejercicio 13
//Tiempo =

int main()
{   int dato1, dato2, dato3, dato4, dato5, dato6, dato7, dato8, dato9, dato10, multiplicador;
    int r1,r2,r3,r4,r5,r6,r7,r8,r9,r10;
    printf("Inserte el valor #1: ");
    scanf("%d", &dato1);
    printf("Inserte el valor #2: ");
    scanf("%d", &dato2);
    printf("Inserte el valor #3: ");
    scanf("%d", &dato3);
    printf("Inserte el valor #4: ");
    scanf("%d", &dato4);
    printf("Inserte el valor #5: ");
    scanf("%d", &dato5);
    printf("Inserte el valor #6: ");
    scanf("%d", &dato6);
    printf("Inserte el valor #7: ");
    scanf("%d", &dato7);
    printf("Inserte el valor #8: ");
    scanf("%d", &dato8);
    printf("Inserte el valor #9: ");
    scanf("%d", &dato9);
    printf("Inserte el valor #10: ");
    scanf("%d", &dato10);
    printf("\n\n1Presiona entrar para continuar: ");
    getchar();
    system("cls");
    printf("Sus valores son...\n\n");
    printf("El primer valor es   : %d\n", dato1);
    printf("El segundo valor es  : %d\n", dato2);
    printf("El tercer valor es   : %d\n", dato3);
    printf("El cuarto valor es   : %d\n", dato4);
    printf("El quinto valor es   : %d\n", dato5);
    printf("El sexto valor es    : %d\n", dato6);
    printf("El septimo valor es  : %d\n", dato7);
    printf("El octavo valor es   : %d\n", dato8);
    printf("El noveno valor es   : %d\n", dato9);
    printf("El decimo valor es   : %d\n", dato10);
    printf("\n\n1Presiona entrar para continuar: ");
    getchar();
    system("cls");
    printf("Escriba un multiplicador: ");
    scanf("%d", &multiplicador);
    r1=dato1*multiplicador;
    r2=dato2*multiplicador;
    r3=dato3*multiplicador;
    r4=dato4*multiplicador;
    r5=dato5*multiplicador;
    r6=dato6*multiplicador;
    r7=dato7*multiplicador;
    r8=dato8*multiplicador;
    r9=dato9*multiplicador;
    r10=dato10*multiplicador;
    printf("\nPrimer valor despues de multiplicar  : %d",r1);
    printf("\nSegundo valor despues de multiplicar : %d",r2);
    printf("\nTercer valor despues de multiplicar  : %d",r3);
    printf("\nCuarto valor despues de multiplicar  : %d",r4);
    printf("\nQuinto valor despues de multiplicar  : %d",r5);
    printf("\nSexto valor despues de multiplicar   : %d",r6);
    printf("\nSeptimo valor despues de multiplicar : %d",r7);
    printf("\nOctavo valor despues de multiplicar  : %d",r8);
    printf("\nNoveno valor despues de multiplicar  : %d",r9);
    printf("\nDecimo valor despues de multiplicar  : %d\n\n",r10);

    return 0;
}
