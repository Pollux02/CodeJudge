//Titulo = Ejercicio 13
//NickName: SieteDos
//Tiempo = 00:15
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arregloEnteros[10], arregloResultado[10];
    int multiplicador;

    printf("Ingrese valor #1 : \n");
    scanf("%d", &arregloEnteros[0]);
    printf("Ingrese valor #2 : \n");
    scanf("%d", &arregloEnteros[1]);
    printf("Ingrese valor #3 : \n");
    scanf("%d", &arregloEnteros[2]);
    printf("Ingrese valor #4 : \n");
    scanf("%d", &arregloEnteros[3]);
    printf("Ingrese valor #5 : \n");
    scanf("%d", &arregloEnteros[4]);
    printf("Ingrese valor #6 : \n");
    scanf("%d", &arregloEnteros[5]);
    printf("Ingrese valor #7 : \n");
    scanf("%d", &arregloEnteros[6]);
    printf("Ingrese valor #8 : \n");
    scanf("%d", &arregloEnteros[7]);
    printf("Ingrese valor #9 : \n");
    scanf("%d", &arregloEnteros[8]);
    printf("Ingrese valor #10 : \n");
    scanf("%d", &arregloEnteros[9]);
    printf("Ingrese un multiplicador : ");
    scanf("%d", &multiplicador);

    arregloResultado[0] = arregloEnteros[0] * multiplicador;
    arregloResultado[1] = arregloEnteros[1] * multiplicador;
    arregloResultado[2] = arregloEnteros[2] * multiplicador;
    arregloResultado[3] = arregloEnteros[3] * multiplicador;
    arregloResultado[4] = arregloEnteros[4] * multiplicador;
    arregloResultado[5] = arregloEnteros[5] * multiplicador;
    arregloResultado[6] = arregloEnteros[6] * multiplicador;
    arregloResultado[7] = arregloEnteros[7] * multiplicador;
    arregloResultado[8] = arregloEnteros[8] * multiplicador;
    arregloResultado[9] = arregloEnteros[9] * multiplicador;



    printf("%d * %d   = %d\n", arregloEnteros[0],multiplicador,arregloResultado[0]);
    printf("%d * %d   = %d\n", arregloEnteros[1],multiplicador,arregloResultado[1]);
    printf("%d * %d   = %d\n", arregloEnteros[2],multiplicador,arregloResultado[2]);
    printf("%d * %d   = %d\n", arregloEnteros[3],multiplicador,arregloResultado[3]);
    printf("%d * %d   = %d\n", arregloEnteros[4],multiplicador,arregloResultado[4]);
    printf("%d * %d   = %d\n", arregloEnteros[5],multiplicador,arregloResultado[5]);
    printf("%d * %d   = %d\n", arregloEnteros[6],multiplicador,arregloResultado[6]);
    printf("%d * %d   = %d\n", arregloEnteros[7],multiplicador,arregloResultado[7]);
    printf("%d * %d   = %d\n", arregloEnteros[8],multiplicador,arregloResultado[8]);
    printf("%d * %d   = %d\n", arregloEnteros[9],multiplicador,arregloResultado[9]);




    return 0;
}
