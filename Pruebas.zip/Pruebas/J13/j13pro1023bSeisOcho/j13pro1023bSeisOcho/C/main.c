/*Autor: SeisOcho
Ejercicio 13: arreglo de valores * factor
Tiempo de elaboraci�n = 00:20
*/
#include <stdio.h>

#define MAXIMO_VALORES 10
#define INICIO 1
int main (){
    int valores[MAXIMO_VALORES], resultados[MAXIMO_VALORES], factor, contador;
    contador = INICIO;

    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el valor %d: ", contador);
    scanf("%d", &valores[contador - INICIO]);
    contador ++;
    printf("Ingrese el factor a multiplicar: ");
    scanf("%d", &factor);

    contador = INICIO;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];
    contador ++;
    resultados[contador-INICIO] = factor * valores[contador-INICIO];

    printf("\nLos resultados son:\n");
    contador = INICIO;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);
    contador ++;
    printf("Valor %d * factor (%d) = %d\n", contador, factor, resultados[contador-INICIO]);


    return 0;

}
