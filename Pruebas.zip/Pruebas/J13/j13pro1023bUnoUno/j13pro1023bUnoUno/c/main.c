#include <stdio.h>
#include <stdlib.h>

#define MULTIPLICADOR 10

//UnoUno
//tiempo 00/20
int main()
{

    printf("Multiplicador de 10 numeros\n\n\n");
    int numeros[10]={1,2,3,4,5,6,7,8,9,10},resultado[10];
    resultado[0]=numeros[0]*MULTIPLICADOR;
    resultado[1]=numeros[1]*MULTIPLICADOR;
    resultado[2]=numeros[2]*MULTIPLICADOR;
    resultado[3]=numeros[3]*MULTIPLICADOR;
    resultado[4]=numeros[4]*MULTIPLICADOR;
    resultado[5]=numeros[5]*MULTIPLICADOR;
    resultado[6]=numeros[6]*MULTIPLICADOR;
    resultado[7]=numeros[7]*MULTIPLICADOR;
    resultado[8]=numeros[8]*MULTIPLICADOR;
    resultado[9]=numeros[9]*MULTIPLICADOR;

    printf ("Valores multiplicados:\n\n");
    printf ("%d * %d = %d\n",numeros[0],MULTIPLICADOR,resultado[0]);
    printf ("%d * %d = %d\n",numeros[1],MULTIPLICADOR,resultado[1]);
    printf ("%d * %d = %d\n",numeros[2],MULTIPLICADOR,resultado[2]);
    printf ("%d * %d = %d\n",numeros[3],MULTIPLICADOR,resultado[3]);
    printf ("%d * %d = %d\n",numeros[4],MULTIPLICADOR,resultado[4]);
    printf ("%d * %d = %d\n",numeros[5],MULTIPLICADOR,resultado[5]);
    printf ("%d * %d = %d\n",numeros[6],MULTIPLICADOR,resultado[6]);
    printf ("%d * %d = %d\n",numeros[7],MULTIPLICADOR,resultado[7]);
    printf ("%d * %d = %d\n",numeros[8],MULTIPLICADOR,resultado[8]);
    printf ("%d * %d = %d\n",numeros[9],MULTIPLICADOR,resultado[9]);

    return 0;
}
