/*
NickName=CuatroCero
Practica=j13
Tiempo=00:18
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int arreglo1[10];
    int arreglo2[10];
    int factor;

    printf("Ingrese 10 valores enteros para el primer arreglo:\n");
    scanf("%d %d %d %d %d %d %d %d %d %d",
          &arreglo1[0], &arreglo1[1], &arreglo1[2], &arreglo1[3], &arreglo1[4],
          &arreglo1[5], &arreglo1[6], &arreglo1[7], &arreglo1[8], &arreglo1[9]);

    printf("Ingrese el factor de multiplicación: ");
    scanf("%d", &factor);

    arreglo2[0] = arreglo1[0] * factor;
    arreglo2[1] = arreglo1[1] * factor;
    arreglo2[2] = arreglo1[2] * factor;
    arreglo2[3] = arreglo1[3] * factor;
    arreglo2[4] = arreglo1[4] * factor;
    arreglo2[5] = arreglo1[5] * factor;
    arreglo2[6] = arreglo1[6] * factor;
    arreglo2[7] = arreglo1[7] * factor;
    arreglo2[8] = arreglo1[8] * factor;
    arreglo2[9] = arreglo1[9] * factor;

    printf("Vector resultante:\n");
    printf("%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n",
           arreglo2[0], arreglo2[1], arreglo2[2], arreglo2[3], arreglo2[4],
           arreglo2[5], arreglo2[6], arreglo2[7], arreglo2[8], arreglo2[9]);

    return 0;
}
