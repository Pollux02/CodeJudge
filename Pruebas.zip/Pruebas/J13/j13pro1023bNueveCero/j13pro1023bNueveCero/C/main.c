#include <stdio.h>
#include <stdlib.h>

#define TAMANO_ARREGLO 10
//define limpieza de pantalla
#ifdef _WIN32
#define CLEAR "cls"
#elif defined(unix)||defined(_unix_)||defined(_unix)||defined(_APPLE_)||defined(_MACH_)
#define CLEAR "clear"
#error "SO no soportado para limpiear pantalla"
#endif // _WIND32

int main(){
    int NumeroIngresado,NumerosMultiplicados[TAMANO_ARREGLO],multiplo,resultados[TAMANO_ARREGLO];
    //ingresa datos y los guarda en el arreglo NumerosMultiplos
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[0]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[1]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[2]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[3]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[4]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[5]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[6]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[7]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[8]=NumeroIngresado;
    printf("teclea un numero entero: ");
    scanf("%d",&NumeroIngresado);
    NumerosMultiplicados[9]=NumeroIngresado;
    printf("indique un factor multiplicador:");
    scanf("%d",&multiplo);

    //operaciones
    resultados[0] = NumerosMultiplicados[0] * multiplo;
    resultados[1] = NumerosMultiplicados[1] * multiplo;
    resultados[2] = NumerosMultiplicados[2] * multiplo;
    resultados[3] = NumerosMultiplicados[3] * multiplo;
    resultados[4] = NumerosMultiplicados[4] * multiplo;
    resultados[5] = NumerosMultiplicados[5] * multiplo;
    resultados[6] = NumerosMultiplicados[6] * multiplo;
    resultados[7] = NumerosMultiplicados[7] * multiplo;
    resultados[8] = NumerosMultiplicados[8] * multiplo;
    resultados[9] = NumerosMultiplicados[9] * multiplo;

    //impresion de los resultados
    system(CLEAR);
    printf("***** RESULTADOS *****\n");
    printf("%d * %d = %d\n",NumerosMultiplicados[0],multiplo,resultados[0]);
    printf("%d * %d = %d\n",NumerosMultiplicados[1],multiplo,resultados[1]);
    printf("%d * %d = %d\n",NumerosMultiplicados[2],multiplo,resultados[2]);
    printf("%d * %d = %d\n",NumerosMultiplicados[3],multiplo,resultados[3]);
    printf("%d * %d = %d\n",NumerosMultiplicados[4],multiplo,resultados[4]);
    printf("%d * %d = %d\n",NumerosMultiplicados[5],multiplo,resultados[5]);
    printf("%d * %d = %d\n",NumerosMultiplicados[6],multiplo,resultados[6]);
    printf("%d * %d = %d\n",NumerosMultiplicados[7],multiplo,resultados[7]);
    printf("%d * %d = %d\n",NumerosMultiplicados[8],multiplo,resultados[8]);
    printf("%d * %d = %d\n",NumerosMultiplicados[9],multiplo,resultados[9]);
    return 0;
}
