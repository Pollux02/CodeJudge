#include <stdio.h>
#include <stdlib.h>

//OchoTres
//Time=33:04
//j13pro1023b

#define NUMEROS 10
#define NUMEROS_MULTIPLICADOS 10


int main()
{
    int numero[NUMEROS],factor,numeroMultiplicado[NUMEROS_MULTIPLICADOS];
    printf("Ingresa el valor de 10 numeros\n\n");
    printf("Valor del primer numero:");
    scanf("%d",&numero[0]);
    printf("Valor del segundo numero:");
    scanf("%d",&numero[1]);
    printf("Valor del tercer numero:");
    scanf("%d",&numero[2]);
    printf("Valor del cuarto numero:");
    scanf("%d",&numero[3]);
    printf("Valor del quinto numero:");
    scanf("%d",&numero[4]);
    printf("Valor del sexto numero:");
    scanf("%d",&numero[5]);
    printf("Valor del septimo numero:");
    scanf("%d",&numero[6]);
    printf("Valor del octavo numero:");
    scanf("%d",&numero[7]);
    printf("Valor del noveno numero:");
    scanf("%d",&numero[8]);
    printf("Valor del decimo numero:");
    scanf("%d",&numero[9]);

    printf("\n\nIngresa el numero por el que deseas multiplicar los valores anteriores:");
    scanf("%d",&factor);

    numeroMultiplicado[0]=factor*numero[0];
    numeroMultiplicado[1]=factor*numero[1];
    numeroMultiplicado[2]=factor*numero[2];
    numeroMultiplicado[3]=factor*numero[3];
    numeroMultiplicado[4]=factor*numero[4];
    numeroMultiplicado[5]=factor*numero[5];
    numeroMultiplicado[6]=factor*numero[6];
    numeroMultiplicado[7]=factor*numero[7];
    numeroMultiplicado[8]=factor*numero[8];
    numeroMultiplicado[9]=factor*numero[9];

    printf("\n\nLos valores resultantes son:\n");


    printf("%d\n",numeroMultiplicado[0]);
    printf("%d\n",numeroMultiplicado[1]);
    printf("%d\n",numeroMultiplicado[2]);
    printf("%d\n",numeroMultiplicado[3]);
    printf("%d\n",numeroMultiplicado[4]);
    printf("%d\n",numeroMultiplicado[5]);
    printf("%d\n",numeroMultiplicado[6]);
    printf("%d\n",numeroMultiplicado[7]);
    printf("%d\n",numeroMultiplicado[8]);
    printf("%d\n",numeroMultiplicado[9]);
    return 0;
}
