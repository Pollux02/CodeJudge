/*
Autor: SeisTres
Ejercicios: j13pro
Tiempo=00:45
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
   
    int arreglo[10];
    int resultado[10];
    int factor;

    printf("Ingrese 10 valores enteros para el arreglo:\n");
    scanf("%d", &arreglo[0]);
    scanf("%d", &arreglo[1]);
    scanf("%d", &arreglo[2]);
    scanf("%d", &arreglo[3]);
    scanf("%d", &arreglo[4]);
    scanf("%d", &arreglo[5]);
    scanf("%d", &arreglo[6]);
    scanf("%d", &arreglo[7]);
    scanf("%d", &arreglo[8]);
    scanf("%d", &arreglo[9]);
    
    printf("Ingrese el factor de multiplicación: ");
    scanf("%d", &factor);


    resultado[0] = arreglo[0] * factor;
    resultado[1] = arreglo[1] * factor;
    resultado[2] = arreglo[2] * factor;
    resultado[3] = arreglo[3] * factor;
    resultado[4] = arreglo[4] * factor;
    resultado[5] = arreglo[5] * factor;
    resultado[6] = arreglo[6] * factor;
    resultado[7] = arreglo[7] * factor;
    resultado[8] = arreglo[8] * factor;
    resultado[9] = arreglo[9] * factor;


    printf("El vector resultante es:\n");
    printf("%d\n", resultado[0]);
    printf("%d\n", resultado[1]);
    printf("%d\n", resultado[2]);
    printf("%d\n", resultado[3]);
    printf("%d\n", resultado[4]);
    printf("%d\n", resultado[5]);
    printf("%d\n", resultado[6]);
    printf("%d\n", resultado[7]);
    printf("%d\n", resultado[8]);
    printf("%d\n", resultado[9]);
    
    return 0;
}
