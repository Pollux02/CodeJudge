// SeisDos // j13pro2023b //Time 2:30

#include <stdio.h>

#define CELDA 10

int main() {
    int arreglo1[CELDA];
    int arreglo2[CELDA];
    int factor;

    printf("Ingrese 10 valores enteros para el primer arreglo: \n");

    scanf("%d", &arreglo1[0]);
    scanf("%d", &arreglo1[1]);
    scanf("%d", &arreglo1[2]);
    scanf("%d", &arreglo1[3]);
    scanf("%d", &arreglo1[4]);
    scanf("%d", &arreglo1[5]);
    scanf("%d", &arreglo1[6]);
    scanf("%d", &arreglo1[7]);
    scanf("%d", &arreglo1[8]);
    scanf("%d", &arreglo1[9]);

    printf("Ingrese el factor de multiplicacion: ");
    scanf("%d", &factor);

    arreglo2[0] = arreglo1[0] * factor;
    arreglo2[1] = arreglo1[1] * factor;
    arreglo2[2] = arreglo1[2] * factor;
    arreglo2[3] = arreglo1[3] * factor;
    arreglo2[4] = arreglo1[4] * factor;
    arreglo2[5] = arreglo1[5] * factor;
    arreglo2[6] = arreglo1[6] * factor;
    arreglo2[7] = arreglo1[7] * factor;
    arreglo2[8] = arreglo1[8] * factor;
    arreglo2[9] = arreglo1[9] * factor;

    printf("Arreglo resultante:\n");
    printf("%d\n", arreglo2[0]);
    printf("%d\n", arreglo2[1]);
    printf("%d\n", arreglo2[2]);
    printf("%d\n", arreglo2[3]);
    printf("%d\n", arreglo2[4]);
    printf("%d\n", arreglo2[5]);
    printf("%d\n", arreglo2[6]);
    printf("%d\n", arreglo2[7]);
    printf("%d\n", arreglo2[8]);
    printf("%d\n", arreglo2[9]);

    return 0;
}
