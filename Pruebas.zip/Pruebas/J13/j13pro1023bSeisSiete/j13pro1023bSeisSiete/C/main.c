#include <stdio.h>
#include <stdlib.h>
/*nickname: SeisSiete
  EJERCICIO 13
  TIEMPO = 00:30
*/
int main()
{
    int valoresDados [10],factor, productoValorFactor [10];
    printf("Dame el valor de la celda 1:");
    scanf ("%i", &valoresDados [0]);
    printf("Dame el valor de la celda 2:");
    scanf ("%i", &valoresDados [1]);
    printf("Dame el valor de la celda 3:");
    scanf ("%i", &valoresDados [2]);
    printf("Dame el valor de la celda 4:");
    scanf ("%i", &valoresDados [3]);
    printf("Dame el valor de la celda 5:");
    scanf ("%i", &valoresDados [4]);
    printf("Dame el valor de la celda 6:");
    scanf ("%i", &valoresDados [5]);
    printf("Dame el valor de la celda 7:");
    scanf ("%i", &valoresDados [6]);
    printf("Dame el valor de la celda 8:");
    scanf ("%i", &valoresDados [7]);
    printf("Dame el valor de la celda 9:");
    scanf ("%i", &valoresDados [8]);
    printf("Dame el valor de la celda 10:");
    scanf ("%i", &valoresDados [9]);
    printf("\n\n Dame el valor del factor o multiplicador :\n");
    scanf ("%i", &factor);

    productoValorFactor [0]= valoresDados [0] * factor;
    productoValorFactor [1]= valoresDados [1] * factor;
    productoValorFactor [2]= valoresDados [2] * factor;
    productoValorFactor [3]= valoresDados [3] * factor;
    productoValorFactor [4]= valoresDados [4] * factor;
    productoValorFactor [5]= valoresDados [5] * factor;
    productoValorFactor [6]= valoresDados [6] * factor;
    productoValorFactor [7]= valoresDados [7] * factor;
    productoValorFactor [8]= valoresDados [8] * factor;
    productoValorFactor [9]= valoresDados [9] * factor;

    printf ("El valor de la celda 1 es: %i\n", productoValorFactor [0]);
    printf ("El valor de la celda 2 es: %i\n", productoValorFactor [1]);
    printf ("El valor de la celda 3 es: %i\n", productoValorFactor [2]);
    printf ("El valor de la celda 4 es: %i\n", productoValorFactor [3]);
    printf ("El valor de la celda 5 es: %i\n", productoValorFactor [4]);
    printf ("El valor de la celda 6 es: %i\n", productoValorFactor [5]);
    printf ("El valor de la celda 7 es: %i\n", productoValorFactor [6]);
    printf ("El valor de la celda 8 es: %i\n", productoValorFactor [7]);
    printf ("El valor de la celda 9 es: %i\n", productoValorFactor [8]);
    printf ("El valor de la celda 10 es: %i\n", productoValorFactor [9]);

    return 0;
}
