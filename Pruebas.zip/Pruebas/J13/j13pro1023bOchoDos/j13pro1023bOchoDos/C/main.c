#include <stdio.h>

int main() {
    int arregloOriginal[10];
    int arregloResultado[10];
    int factor;

    printf("Ingrese 10 valores para el arreglo:\n");
    scanf("%d", &arregloOriginal[0]);
    scanf("%d", &arregloOriginal[1]);
    scanf("%d", &arregloOriginal[2]);
    scanf("%d", &arregloOriginal[3]);
    scanf("%d", &arregloOriginal[4]);
    scanf("%d", &arregloOriginal[5]);
    scanf("%d", &arregloOriginal[6]);
    scanf("%d", &arregloOriginal[7]);
    scanf("%d", &arregloOriginal[8]);
    scanf("%d", &arregloOriginal[9]);

    printf("Ingrese el factor de multiplicación: ");
    scanf("%d", &factor);

    arregloResultado[0] = arregloOriginal[0] * factor;
    arregloResultado[1] = arregloOriginal[1] * factor;
    arregloResultado[2] = arregloOriginal[2] * factor;
    arregloResultado[3] = arregloOriginal[3] * factor;
    arregloResultado[4] = arregloOriginal[4] * factor;
    arregloResultado[5] = arregloOriginal[5] * factor;
    arregloResultado[6] = arregloOriginal[6] * factor;
    arregloResultado[7] = arregloOriginal[7] * factor;
    arregloResultado[8] = arregloOriginal[8] * factor;
    arregloResultado[9] = arregloOriginal[9] * factor;

    printf("Vector resultante:\n");
    printf("%d\n", arregloResultado[0]);
    printf("%d\n", arregloResultado[1]);
    printf("%d\n", arregloResultado[2]);
    printf("%d\n", arregloResultado[3]);
    printf("%d\n", arregloResultado[4]);
    printf("%d\n", arregloResultado[5]);
    printf("%d\n", arregloResultado[6]);
    printf("%d\n", arregloResultado[7]);
    printf("%d\n", arregloResultado[8]);
    printf("%d\n", arregloResultado[9]);

    return 0;
}
