//TresCero
//j13 EJERCICIOS PRO
//Tiempo = 00:55
#include <stdio.h>
#include <stdlib.h>

#define CLEAR cls
#define CANTIDAD_VALORES 10


int main(){
    int valorUsuario,valoresUsuario[CANTIDAD_VALORES],factor,resultados[CANTIDAD_VALORES];
    printf("Calculo de valores multiplicados\n\n");

    printf("Ingrese el valor 1: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[0]=valorUsuario;
    printf("Ingrese el valor 2: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[1]=valorUsuario;
    printf("Ingrese el valor 3: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[2]=valorUsuario;
    printf("Ingrese el valor 4: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[3]=valorUsuario;
    printf("Ingrese el valor 5: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[4]=valorUsuario;
    printf("Ingrese el valor 6: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[5]=valorUsuario;
    printf("Ingrese el valor 7: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[6]=valorUsuario;
    printf("Ingrese el valor 8: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[7]=valorUsuario;
    printf("Ingrese el valor 9: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[8]=valorUsuario;
    printf("Ingrese el valor 10: ");
    scanf("%d",&valorUsuario);
    valoresUsuario[9]=valorUsuario;
    printf("\nIngrese el factor por el que desea multiplicar todos sus valores: ");
    scanf("%d",&factor);

    getchar();
    printf("\nPresione enter para continuar...");
    getchar();

    resultados[0]=valoresUsuario[0]*factor;
    resultados[1]=valoresUsuario[1]*factor;
    resultados[2]=valoresUsuario[2]*factor;
    resultados[3]=valoresUsuario[3]*factor;
    resultados[4]=valoresUsuario[4]*factor;
    resultados[5]=valoresUsuario[5]*factor;
    resultados[6]=valoresUsuario[6]*factor;
    resultados[7]=valoresUsuario[7]*factor;
    resultados[8]=valoresUsuario[8]*factor;
    resultados[9]=valoresUsuario[9]*factor;

    system("cls");

    printf("Calculo de valores multiplicados\n\n");
    printf("Tus valores son: \n");
    printf("El valor #1 es: %d\n",valoresUsuario[0]);
    printf("El valor #2 es: %d\n",valoresUsuario[1]);
    printf("El valor #3 es: %d\n",valoresUsuario[2]);
    printf("El valor #4 es: %d\n",valoresUsuario[3]);
    printf("El valor #5 es: %d\n",valoresUsuario[4]);
    printf("El valor #6 es: %d\n",valoresUsuario[5]);
    printf("El valor #7 es: %d\n",valoresUsuario[6]);
    printf("El valor #8 es: %d\n",valoresUsuario[7]);
    printf("El valor #9 es: %d\n",valoresUsuario[8]);
    printf("El valor #10 es: %d\n",valoresUsuario[9]);

    printf("\nLos resultados de multiplicar por %d: ",factor);
    printf("\nValor #1: %d\n",resultados[0]);
    printf("Valor #2: %d\n",resultados[1]);
    printf("Valor #3: %d\n",resultados[2]);
    printf("Valor #4: %d\n",resultados[3]);
    printf("Valor #5: %d\n",resultados[4]);
    printf("Valor #6: %d\n",resultados[5]);
    printf("Valor #7: %d\n",resultados[6]);
    printf("Valor #8: %d\n",resultados[7]);
    printf("Valor #9: %d\n",resultados[8]);
    printf("Valor #10: %d\n",resultados[9]);
    return 0;
}
