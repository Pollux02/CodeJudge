#include <stdio.h>
#include <stdlib.h>

#define CANTIDAD_KIDS 10
#define EXTRA 10
int main()
{
    int kid[CANTIDAD_KIDS],dulces_del_kid,dulces_extra[EXTRA];

    printf("Dime cuantos dulces tiene el ni�o #1: ");
    scanf("%d",&dulces_del_kid);
    kid[0]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #2: ");
    scanf("%d",&dulces_del_kid);
    kid[1]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #3: ");
    scanf("%d",&dulces_del_kid);
    kid[2]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #4: ");
    scanf("%d",&dulces_del_kid);
    kid[3]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #5: ");
    scanf("%d",&dulces_del_kid);
    kid[4]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #6: ");
    scanf("%d",&dulces_del_kid);
    kid[5]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #7: ");
    scanf("%d",&dulces_del_kid);
    kid[6]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #8: ");
    scanf("%d",&dulces_del_kid);
    kid[7]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #9: ");
    scanf("%d",&dulces_del_kid);
    kid[8]=dulces_del_kid;

    printf("Dime cuantos dulces tiene el ni�o #10: ");
    scanf("%d",&dulces_del_kid);
    kid[9]=dulces_del_kid;

    printf("\nCantidad de dulces del ni�o #1: %d\n",kid[0]);
    printf("Cantidad de dulces del ni�o #2: %d\n",kid[1]);
    printf("Cantidad de dulces del ni�o #3: %d\n",kid[2]);
    printf("Cantidad de dulces del ni�o #4: %d\n",kid[3]);
    printf("Cantidad de dulces del ni�o #5: %d\n",kid[4]);
    printf("Cantidad de dulces del ni�o #6: %d\n",kid[5]);
    printf("Cantidad de dulces del ni�o #7: %d\n",kid[6]);
    printf("Cantidad de dulces del ni�o #8: %d\n",kid[7]);
    printf("Cantidad de dulces del ni�o #9: %d\n",kid[8]);
    printf("Cantidad de dulces del ni�o #10: %d\n",kid[9]);

    printf("\nDime cauntas veces multiplicaremos los dulces de los ni�os: ");
    scanf("%d",&dulces_del_kid);

    dulces_extra[0]=dulces_del_kid*kid[0];
    dulces_extra[1]=dulces_del_kid*kid[1];
    dulces_extra[2]=dulces_del_kid*kid[2];
    dulces_extra[3]=dulces_del_kid*kid[3];
    dulces_extra[4]=dulces_del_kid*kid[4];
    dulces_extra[5]=dulces_del_kid*kid[5];
    dulces_extra[6]=dulces_del_kid*kid[6];
    dulces_extra[7]=dulces_del_kid*kid[7];
    dulces_extra[8]=dulces_del_kid*kid[8];
    dulces_extra[9]=dulces_del_kid*kid[9];

    printf("\nCantidad de dulces despues de multiplicarlos: \n");
    printf("Cantidad de dulces del ni�o #1: %d\n",dulces_extra[0]);
    printf("Cantidad de dulces del ni�o #2: %d\n",dulces_extra[1]);
    printf("Cantidad de dulces del ni�o #3: %d\n",dulces_extra[2]);
    printf("Cantidad de dulces del ni�o #4: %d\n",dulces_extra[3]);
    printf("Cantidad de dulces del ni�o #5: %d\n",dulces_extra[4]);
    printf("Cantidad de dulces del ni�o #6: %d\n",dulces_extra[5]);
    printf("Cantidad de dulces del ni�o #7: %d\n",dulces_extra[6]);
    printf("Cantidad de dulces del ni�o #8: %d\n",dulces_extra[7]);
    printf("Cantidad de dulces del ni�o #9: %d\n",dulces_extra[8]);
    printf("Cantidad de dulces del ni�o #10: %d\n",dulces_extra[9]);

    return 0;
}
