// OchoSeis Ejercicio 13; "Tiempo=00:42"

#include<stdio.h>

#define TAMANIO_ARREGLO 9

int main(){
	int arregloUno[TAMANIO_ARREGLO], arregloDos[TAMANIO_ARREGLO], entero, multiplicador;
	
	printf("Ingrese el valor del entero numero 1: ");
	scanf("%d",&entero);
	arregloUno[0]=entero;
	printf("Ingrese el valor del entero numero 2: ");
	scanf("%d",&entero);
	arregloUno[1]=entero;
	printf("Ingrese el valor del entero numero 3: ");
	scanf("%d",&entero);
	arregloUno[2]=entero;
	printf("Ingrese el valor del entero numero 4: ");
	scanf("%d",&entero);
	arregloUno[3]=entero;
	printf("Ingrese el valor del entero numero 5: ");
	scanf("%d",&entero);
	arregloUno[4]=entero;
	printf("Ingrese el valor del entero numero 6: ");
	scanf("%d",&entero);
	arregloUno[5]=entero;
	printf("Ingrese el valor del entero numero 7: ");
	scanf("%d",&entero);
	arregloUno[6]=entero;
	printf("Ingrese el valor del entero numero 8: ");
	scanf("%d",&entero);
	arregloUno[7]=entero;
	printf("Ingrese el valor del entero numero 9: ");
	scanf("%d",&entero);
	arregloUno[8]=entero;
	printf("Ingrese el valor del entero numero 10: ");
	scanf("%d",&entero);
	arregloUno[9]=entero;
	
	printf("\nIngrese el valor del multiplicador: ");
	scanf("%d",&multiplicador);
	
	arregloDos[0] = arregloUno[0] * multiplicador;
	arregloDos[1] = arregloUno[1] * multiplicador;
	arregloDos[2] = arregloUno[2] * multiplicador;
	arregloDos[3] = arregloUno[3] * multiplicador;
	arregloDos[4] = arregloUno[4] * multiplicador;
	arregloDos[5] = arregloUno[5] * multiplicador;
	arregloDos[6] = arregloUno[6] * multiplicador;
	arregloDos[7] = arregloUno[7] * multiplicador;
	arregloDos[8] = arregloUno[8] * multiplicador;
	arregloDos[9] = arregloUno[9] * multiplicador;
	
	printf("\nEl producto del entero 1 es: %d\n", arregloDos[0]);
	printf("El producto del entero 1 es: %d\n", arregloDos[1]);
	printf("El producto del entero 1 es: %d\n", arregloDos[2]);
	printf("El producto del entero 1 es: %d\n", arregloDos[3]);
	printf("El producto del entero 1 es: %d\n", arregloDos[4]);
	printf("El producto del entero 1 es: %d\n", arregloDos[5]);
	printf("El producto del entero 1 es: %d\n", arregloDos[6]);
	printf("El producto del entero 1 es: %d\n", arregloDos[7]);
	printf("El producto del entero 1 es: %d\n", arregloDos[8]);
	printf("El producto del entero 1 es: %d\n", arregloDos[9]);
	
	return 0;
}
