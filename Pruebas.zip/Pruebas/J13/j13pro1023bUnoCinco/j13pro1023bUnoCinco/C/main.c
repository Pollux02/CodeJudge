#include <stdio.h>
#include <stdlib.h>
#define VALORES 10
int main()
{
    int arreglo1[VALORES],arregloFinal[VALORES];
    int factor;
    printf("Dame 10 valores para un arreglo\n\n");
    scanf("%d", &arreglo1[0]);
    scanf("%d", &arreglo1[1]);
    scanf("%d", &arreglo1[2]);
    scanf("%d", &arreglo1[3]);
    scanf("%d", &arreglo1[4]);
    scanf("%d", &arreglo1[5]);
    scanf("%d", &arreglo1[6]);
    scanf("%d", &arreglo1[7]);
    scanf("%d", &arreglo1[8]);
    scanf("%d", &arreglo1[9]);

    printf("Ingrese el factor de multiplicacion:\n\n ");
    scanf("%d",&factor);

    arregloFinal[0] = arreglo1[0] * factor;
    arregloFinal[1] = arreglo1[1] * factor;
    arregloFinal[2] = arreglo1[2] * factor;
    arregloFinal[3] = arreglo1[3] * factor;
    arregloFinal[4] = arreglo1[4] * factor;
    arregloFinal[5] = arreglo1[5] * factor;
    arregloFinal[6] = arreglo1[6] * factor;
    arregloFinal[7] = arreglo1[7] * factor;
    arregloFinal[8] = arreglo1[8] * factor;
    arregloFinal[9] = arreglo1[9] * factor;

     printf("Vector resultante:\n\n");
    printf("%d\n", arregloFinal[0]);
    printf("%d\n", arregloFinal[1]);
    printf("%d\n", arregloFinal[2]);
    printf("%d\n", arregloFinal[3]);
    printf("%d\n", arregloFinal[4]);
    printf("%d\n", arregloFinal[5]);
    printf("%d\n", arregloFinal[6]);
    printf("%d\n", arregloFinal[7]);
    printf("%d\n", arregloFinal[8]);
    printf("%d\n", arregloFinal[9]);
    printf("\n");
    return 0;
}
