//TRESCINCO
//EJERCICIO 13
//00:25

#include <stdio.h>
#include <stdlib.h>
#define Numeros_Maximos 10
#define resultados_M 10
#define CLEAR "cls"

int main()
{
    int valores[Numeros_Maximos],resultado[resultados_M],valor,multiplicador;

    printf("ingrese el primer valor: ");
    scanf("%d",&valor);
    valores[0]=valor;

    printf("ingrese el segundo valor: ");
    scanf("%d",&valor);
    valores[1]=valor;

    printf("ingrese el tercer valor: ");
    scanf("%d",&valor);
    valores[2]=valor;

    printf("ingrese el cuarto valor: ");
    scanf("%d",&valor);
    valores[3]=valor;

    printf("ingrese el quinto valor: ");
    scanf("%d",&valor);
    valores[4]=valor;

    printf("ingrese el sexto valor: ");
    scanf("%d",&valor);
    valores[5]=valor;

    printf("ingrese el septimo valor: ");
    scanf("%d",&valor);
    valores[6]=valor;

    printf("ingrese el octavo valor: ");
    scanf("%d",&valor);
    valores[7]=valor;

    printf("ingrese el noveno valor: ");
    scanf("%d",&valor);
    valores[8]=valor;

    printf("ingrese el decimo valor: ");
    scanf("%d",&valor);
    valores[9]=valor;

    system(CLEAR);
    printf("=====================\n");
    printf("valores:\n");
    printf("=====================\n");
    printf("\nvalor 1:  %d\n",valores[0]);
    printf("valor 2:  %d\n",valores[1]);
    printf("valor 3:  %d\n",valores[2]);
    printf("valor 4:  %d\n",valores[3]);
    printf("valor 5:  %d\n",valores[4]);
    printf("valor 6:  %d\n",valores[5]);
    printf("valor 7:  %d\n",valores[6]);
    printf("valor 8:  %d\n",valores[7]);
    printf("valor 9:  %d\n",valores[8]);
    printf("valor 10: %d\n",valores[9]);

    printf("\ningrese un multiplicador: ");
    scanf("%d",&multiplicador);

    getchar();
    printf("\npresione enter para continuar... ");
    getchar();

    system(CLEAR);
    resultado[0]= valores[0]*multiplicador;
    resultado[1]= valores[1]*multiplicador;
    resultado[2]= valores[2]*multiplicador;
    resultado[3]= valores[3]*multiplicador;
    resultado[4]= valores[4]*multiplicador;
    resultado[5]= valores[5]*multiplicador;
    resultado[6]= valores[6]*multiplicador;
    resultado[7]= valores[7]*multiplicador;
    resultado[8]= valores[8]*multiplicador;
    resultado[9]= valores[9]*multiplicador;

    printf("==================================\n");
    printf("\nResultados por multiplicacion\n");
    printf("\n=================================\n");
    printf("\n*Multiplicador*: %d",multiplicador);
    printf("\n\nvalor 1  : %d   resultado 1 :  %d",valores[0],resultado[0]);
    printf("\nvalor 2  : %d    resultado 2 :  %d",valores[1],resultado[1]);
    printf("\nvalor 3  : %d    resultado 3 :  %d",valores[2],resultado[2]);
    printf("\nvalor 4  : %d    resultado 4 :  %d",valores[3],resultado[3]);
    printf("\nvalor 5  : %d    resultado 5 :  %d",valores[4],resultado[4]);
    printf("\nvalor 6  : %d    resultado 6 :  %d",valores[5],resultado[5]);
    printf("\nvalor 7  : %d    resultado 7 :  %d",valores[6],resultado[6]);
    printf("\nvalor 8  : %d    resultado 8 :  %d",valores[7],resultado[7]);
    printf("\nvalor 9  : %d    resultado 9 :  %d",valores[8],resultado[8]);
    printf("\nvalor 10 : %d    resultado 10:  %d\n",valores[9],resultado[9]);

    return 0;
}
