#include <stdio.h>
#include <stdlib.h>


int main()
{
    int multiplo, arregloEnteros[10],arregloResultado[10];


    printf("Calculando 10 arreglos =)\n");
    printf("Dame 10 valores a calcular: \n");
    scanf("%d", &arregloEnteros[0]);
    scanf("%d", &arregloEnteros[1]);
    scanf("%d", &arregloEnteros[2]);
    scanf("%d", &arregloEnteros[3]);
    scanf("%d", &arregloEnteros[4]);
    scanf("%d", &arregloEnteros[5]);
    scanf("%d", &arregloEnteros[6]);
    scanf("%d", &arregloEnteros[7]);
    scanf("%d", &arregloEnteros[8]);
    scanf("%d", &arregloEnteros[9]);

    printf("Ingrese el factor de multiplicacion: \n");
    scanf("%d", &multiplo);


    arregloResultado[0] = arregloEnteros[0] * multiplo;
    arregloResultado[1] = arregloEnteros[1] * multiplo;
    arregloResultado[2] = arregloEnteros[2] * multiplo;
    arregloResultado[3] = arregloEnteros[3] * multiplo;
    arregloResultado[4] = arregloEnteros[4] * multiplo;
    arregloResultado[5] = arregloEnteros[5] * multiplo;
    arregloResultado[6] = arregloEnteros[6] * multiplo;
    arregloResultado[7] = arregloEnteros[7] * multiplo;
    arregloResultado[8] = arregloEnteros[8] * multiplo;
    arregloResultado[9] = arregloEnteros[9] * multiplo;

    printf("Vector resultante:\n");
    printf("%d\n", arregloResultado[0]);
    printf("%d\n", arregloResultado[1]);
    printf("%d\n", arregloResultado[2]);
    printf("%d\n", arregloResultado[3]);
    printf("%d\n", arregloResultado[4]);
    printf("%d\n", arregloResultado[5]);
    printf("%d\n", arregloResultado[6]);
    printf("%d\n", arregloResultado[7]);
    printf("%d\n", arregloResultado[8]);
    printf("%d\n", arregloResultado[9]);


    return 0;
}
