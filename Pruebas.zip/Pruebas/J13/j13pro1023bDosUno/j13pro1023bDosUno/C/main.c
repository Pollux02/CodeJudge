#include <stdio.h>
#include <stdlib.h>

#define MAXIMO_VALORES 10
#define OPERACIONES 10

int main()
{
    int valores[MAXIMO_VALORES], valor, multiplicador, operacion[OPERACIONES];

    printf("Bienvenido a Multiplicador!\n");

    printf("Dime el primer valor a multiplicar: ");
    scanf("%d",&valor);
    valores[0]=valor;

    printf("\nDime el segundo valor a multiplicar: ");
    scanf("%d",&valor);
    valores[1]=valor;

    printf("\nDime el tercer valor a multiplicar: ");
    scanf("%d",&valor);
    valores[2]=valor;

    printf("\nDime el cuarto valor a multiplicar: ");
    scanf("%d",&valor);
    valores[3]=valor;

    printf("\nDime el quinto valor a multiplicar: ");
    scanf("%d",&valor);
    valores[4]=valor;

    printf("\nDime el sexto valor a multiplicar: ");
    scanf("%d",&valor);
    valores[5]=valor;

    printf("\nDime el septimo valor a multiplicar: ");
    scanf("%d",&valor);
    valores[6]=valor;

    printf("\nDime el octavo valor a multiplicar: ");
    scanf("%d",&valor);
    valores[7]=valor;

    printf("\nDime el noveno valor a multiplicar: ");
    scanf("%d",&valor);
    valores[8]=valor;

    printf("\nDime el decimo valor a multiplicar: ");
    scanf("%d",&valor);
    valores[9]=valor;

    printf("\nDame el valor multiplicador: ");
    scanf("%d",&multiplicador);

    operacion[0]=valores[0]*multiplicador;
    operacion[1]=valores[1]*multiplicador;
    operacion[2]=valores[2]*multiplicador;
    operacion[3]=valores[3]*multiplicador;
    operacion[4]=valores[4]*multiplicador;
    operacion[5]=valores[5]*multiplicador;
    operacion[6]=valores[6]*multiplicador;
    operacion[7]=valores[7]*multiplicador;
    operacion[8]=valores[8]*multiplicador;
    operacion[9]=valores[9]*multiplicador;

    printf("\n%d * %d= %d",valores[0], multiplicador,operacion[0]);
    printf("\n%d * %d= %d",valores[1], multiplicador,operacion[1]);
    printf("\n%d * %d= %d",valores[2], multiplicador,operacion[2]);
    printf("\n%d * %d= %d",valores[3], multiplicador,operacion[3]);
    printf("\n%d * %d= %d",valores[4], multiplicador,operacion[4]);
    printf("\n%d * %d= %d",valores[5], multiplicador,operacion[5]);
    printf("\n%d * %d= %d",valores[6], multiplicador,operacion[6]);
    printf("\n%d * %d= %d",valores[7], multiplicador,operacion[7]);
    printf("\n%d * %d= %d",valores[8], multiplicador,operacion[8]);
    printf("\n%d * %d= %d",valores[9], multiplicador,operacion[9]);
    return 0;
}
