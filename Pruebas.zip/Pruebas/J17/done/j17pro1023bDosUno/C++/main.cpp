//DosUno, j17pro1023b, "Tiempo=00:40"

#include <iostream>

using namespace std;

#define DESCUENTO .80
#define MINIMO_COMPRA 50

int main()
{
    int montoCompra;
    cout << "TIENDA ARTICULOS DE PRIMERA NECESIDAD" << endl;
    cout << "Monto de compra: $";
    cin >>montoCompra;

    if (montoCompra>=MINIMO_COMPRA)
    {
        montoCompra=montoCompra*DESCUENTO;
    }

    cout << "usted debe pagar: $" <<montoCompra;

    return 0;
}
