#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416
int main()
{
    float areaCirculo, radio;
    printf("�Cual es el valor del radio? \n");
    scanf("%f", &radio);
    areaCirculo=(radio*radio)*PI;
    printf("Los datos recaudados son:\nareaCirculo: %f\nradio: %f\nPI: %f", areaCirculo, radio, PI);
    return 0;
}
