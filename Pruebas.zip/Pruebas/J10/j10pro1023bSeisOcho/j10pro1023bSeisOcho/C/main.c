#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416
int main(){
    float areaCirculo, radio;
    printf("Area de un circulo\n\n");
    printf("Por favor, ingrese el radio: ");
    scanf("%f", &radio);
    areaCirculo = PI * (radio*radio);
    printf("Area del circulo: %.2f\n", areaCirculo);
    return 0;
}
