#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416

int main()
{
    float areaCirculo,radio;
    printf("Dame el valor de la variable radio: ");
    scanf("%f", &radio);;

    printf("Calculando el area de un ciculo =)\n");
    areaCirculo=PI*radio*radio;

    printf("El valor de 'pi' es: %.5f\n", PI);
    printf("El valor del radio 'r' es: %.2f\n", radio);
    printf("El �rea del c�rculo es: %.4f\n", areaCirculo);

    return 0;
}



