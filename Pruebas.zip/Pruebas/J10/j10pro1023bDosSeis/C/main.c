#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416

int main()
{
    float areaCirculo,radio;
    printf("Ingrese el valor del radio: ");
    scanf("%f",&radio);
    areaCirculo=PI*radio*radio;
    printf("\n\nEl area de tu circulo es de: %f\n",areaCirculo);
    printf("El valor del radio es de: %f\n", radio);
    printf("El valor de pi es de: %f\n\n",PI);
    return 0;
}
