#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416

int main()
{
    float areaCirculo, radio;


    printf("Calcular el area de un ciculo \n\n");
    printf("Dame el valor del radio \n\n");
    scanf("%f",&radio);

    areaCirculo=PI*(radio*radio);

    printf("Radio: %f\n", radio);
    printf("PI: %f\n", PI);
    printf("Area del ciruclo: %f\n", areaCirculo);


    return 0;
}
