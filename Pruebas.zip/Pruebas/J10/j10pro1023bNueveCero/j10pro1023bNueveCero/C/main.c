#include <stdio.h>
#include <stdlib.h>

#define PI 3.1416
int main(){
    float areaCirculo, radio;
    printf("indica radio: ");
    scanf("%f",&radio);
    areaCirculo=radio*radio*PI;
   
    printf("radio: %f",radio);
    printf("area: %f",areaCirculo);
    return 0;
}
