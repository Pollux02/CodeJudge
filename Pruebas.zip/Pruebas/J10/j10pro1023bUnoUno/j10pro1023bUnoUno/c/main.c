#include <stdio.h>
#include <stdlib.h>
#define  PI 3.1416
int main()
{
    printf("Programa creado para calcular el area de un circulo\n\n");
    float areaCirculo,radio;
    printf("Dame el radio del circulo:");
    scanf("%f",&radio);
    areaCirculo=PI*(radio*radio);
    printf("\n\n La area del circulo es : %f",areaCirculo);
    printf("\n\n");
    return 0;
}
