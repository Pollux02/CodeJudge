#include <stdio.h>
#include <stdlib.h>

#define PI 3.1416

int main()
{
    float radio, areaCirculo;

    printf("Area de un Circulo\n");
    printf("Dame el valor del radio: ");
    scanf("%f", &radio);

    areaCirculo = PI * radio * radio;

    printf("\nRadio = %f", radio);
    printf("\nPI = %f", PI);
    printf("\nArea circulo = %f", areaCirculo);
    return 0;
}
