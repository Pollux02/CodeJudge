#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416
int main()
{
    float areaCirculo,radio;
    printf("Dame la medida del radio: ");
    scanf("%f",&radio);
    areaCirculo=PI*radio*radio;
    printf("\nEl area del circulo es: %f",areaCirculo);
    return 0;
}
