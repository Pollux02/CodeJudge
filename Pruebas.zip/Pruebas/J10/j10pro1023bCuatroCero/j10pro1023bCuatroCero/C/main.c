#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416

int main() {
    float radio, areaCirculo;

    printf("Ingrese el radio del circulo: ");
    scanf("%f", &radio);

    areaCirculo = PI * radio * radio;

    printf("\nEl area del circulo con radio %.2f es %.2f\n", radio, areaCirculo);

    return 0;
}
