//sietesiete
#include <stdio.h>
#define PI 3.1416
int main()
{
    float areaCirculo, radio;
    
    printf("Ingrese el valor del radio");
    scanf("%f", &radio);
    
    areaCirculo = PI*radio*radio;
    
    printf("El area del circulo es %f", areaCirculo);
    
    return 0;
}
