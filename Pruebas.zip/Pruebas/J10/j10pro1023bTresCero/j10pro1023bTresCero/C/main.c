#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416

int main()
{
    float radio, areaCirculo;
    printf("Calculo del area de un circulo\n");
    printf("Ingrese el radio del circulo: ");
    scanf("%f",&radio);

    areaCirculo= PI*radio*radio;

    printf("\nEl area de tu circulo es: %f",areaCirculo);
    return 0;
}

