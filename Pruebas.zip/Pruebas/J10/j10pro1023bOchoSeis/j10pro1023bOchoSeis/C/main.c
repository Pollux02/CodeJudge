#include<stdio.h>
#include<math.h>

#define PI 3.1416

int main(){
	float areaCirculo, radio;

	printf("Calcular el area de un circulo.\n\n");
	printf("Ingrese el radio de un circulo: ");
	scanf("%f",&radio);

	areaCirculo = PI * (pow(radio, 2));

	printf("\nArea del circulo: %.4f\n",areaCirculo);
	printf("Radio del circulo: %.4f\n",radio);
	printf("Valor de 'pi': %.4f\n\n",PI);

	return 0;
}
