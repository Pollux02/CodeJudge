#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416

int main()
{
    float areaCirculo, radio;
    printf("Calculando el area de un circulo...\n\n");
    printf("Ingrese el valor del radio = ");
    scanf("%f", &radio);
    areaCirculo = PI*radio*radio;
    printf("\nValores de circulo: \n\n");
    printf("RADIO = %.4f\n",radio);
    printf("AREA  = %.4f\n",areaCirculo);
    printf("PI    = %.4f\n",PI);
    return 0;
}
