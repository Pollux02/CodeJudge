#include <stdio.h>
#include <stdlib.h>
#define PI 3.1416

int main()
{
    float areaCirculo, radio;

    printf("Calcular area de un circulo/n");
    printf("Digite el valor del radio del circulo: ");
    scanf("%f", &radio);

    areaCirculo = PI*(radio*radio);
    printf("El area del circulo es igual a : %f", areaCirculo);


}
