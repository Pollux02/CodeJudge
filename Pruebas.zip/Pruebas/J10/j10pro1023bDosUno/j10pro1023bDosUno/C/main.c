#include <stdio.h>
#include <stdlib.h>

#define PI 3.1416


    int main()
{
    float radio, areaCirculo;
    printf("Bienvenido al encontrar area de un circulo\n");
    printf("Dame el valor del radio: ");
    scanf("%f",&radio);
    areaCirculo= PI*radio*radio;
    printf("el radio tiene un valor de: %.2f\n", radio);
    printf("El area de tu circulo es: %.2f", areaCirculo);

    return 0;
}
