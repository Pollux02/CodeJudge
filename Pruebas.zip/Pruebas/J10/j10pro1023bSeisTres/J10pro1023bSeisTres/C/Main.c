#include <stdio.h>
#include <stdlib.h>
#define pi 3.1416

int main()
{   
    float radio, Area;
    printf("Calcular el area de un circulo:\n");
    printf("Ingrese el radio del circulo: ");
    scanf("%f", &radio);
    Area = pi * (radio * radio);
    printf("El area del circulo es: %f\n", Area);
    return 0;
}
