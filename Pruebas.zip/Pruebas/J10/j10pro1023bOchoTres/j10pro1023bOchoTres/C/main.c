#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio;
    #define PI 3.1416;
    printf("Calcular el area de un Circulo\n\n");
    printf("Ingresa el valor del radio:");
    scanf("%f",&radio);
    areaCirculo=radio*radio*PI;
    printf("El area del circulo es de:%.4f",areaCirculo);    return 0;
}
