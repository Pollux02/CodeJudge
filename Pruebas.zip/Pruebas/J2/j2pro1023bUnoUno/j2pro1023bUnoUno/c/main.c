#include <stdio.h>
#include <stdlib.h>
//Area de un triangulo 2
int main()
{
    printf("Area de un triangulo:\n\n\n");
    int areaTriangulo,base,haltura;
    base=60;
    haltura=18;
    areaTriangulo=(base*haltura)/2;
    printf("El valor del area es=%d\n\n",areaTriangulo);
    printf("El valor de la base es=%d\n\n",base);
    printf("El valor de la haltura es=%d\n\n",haltura);
    return 0;
}
