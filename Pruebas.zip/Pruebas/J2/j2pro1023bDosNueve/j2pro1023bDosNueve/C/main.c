#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,areaTriangulo;
    altura=7;
    base=6;
    printf("Calculando el area de un triangulo =)\n");
    areaTriangulo=(base*altura)*0.5;
    printf("altura=%d\n",altura);
    printf("base=%d\n",base);
    printf("areaTriangulo=%d\n",areaTriangulo);
    return 0;
}
