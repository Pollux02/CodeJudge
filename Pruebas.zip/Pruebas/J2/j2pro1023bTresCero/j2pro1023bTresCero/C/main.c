#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,areaTriangulo;
    base=34;
    altura=21;
    areaTriangulo=base*altura/2;
    printf("La base del triangulo es: %d\n",base);
    printf("La altura del triangulo es: %d\n",altura);
    printf("El area total del triangulo es: %d\n",areaTriangulo);

    return 0;
}
