/*implemente un programa que calcule el �rea de un triangulo
usando variables int nombradas "areaTriangulo", "base" y "altura".
no es necesario solicitar datos al usuario. */
#include<stdio.h>

int main(){
	int areaTriangulo, base, altura;
	base=3;
	altura=6;
	
	printf("Calcular el area de un triangulo.\n\n");
	printf("Base = %d\n",base);
	printf("Altura = %d\n",altura);
	
	areaTriangulo = (base * altura) / 2;
	
	printf("El area del triangulo es: %d\n",areaTriangulo);
	
	return 0;
}
