#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo, base, altura;
    base=35;
    altura=63;
    areaTriangulo=base*altura/2;
    printf("Datos del triangulo: \n\n");
    printf("Base = %d\n",base);
    printf("Altura = %d\n",altura);
    printf("Area = %d\n",areaTriangulo);
    return 0;
}
