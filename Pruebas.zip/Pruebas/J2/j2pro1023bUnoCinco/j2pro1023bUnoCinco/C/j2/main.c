#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,area;
    base=10;
    altura=5;
    area=base*altura/2;
    printf("Altura:%d \n",altura);
    printf("Base:%d \n",base);
    printf("El area es :%d \n",area);
    return 0;
}
