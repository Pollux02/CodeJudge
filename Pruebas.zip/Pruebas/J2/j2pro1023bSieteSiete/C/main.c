//David Leonardo Flores Moreno
#include<stdio.h>


int main(){
	int areaTriangulo,base,altura;
    base=10;
    altura=15;
    areaTriangulo =(base*altura)/2;
	printf("base %i\n",base);
    printf("altura %i\n", altura);
    printf("area %i\n", areaTriangulo);
	return 0;
}