#include <stdio.h>
#include <stdlib.h>


int main()
{
    //AREA

    int areaTriangulo;
    //BASE
    int base=6;
    //ALTURA
    int altura=4;
    //OPERACION
    areaTriangulo=(base*altura)/2;
    //IMPRESION
    printf("El resultado del area es: %d", areaTriangulo);
    return 0;
}
