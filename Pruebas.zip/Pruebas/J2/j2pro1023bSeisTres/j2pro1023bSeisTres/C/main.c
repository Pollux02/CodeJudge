#include <stdio.h>
#include <stdlib.h>

int main()
{
 int  Base,Altura,areaTriangulo;
      Base=10;
      Altura=42;
      areaTriangulo=(Base*Altura)/2;
      printf("El area del triangulo es %d\n",areaTriangulo);
      return 0;
}
