#include <stdio.h>
#include <stdlib.h>

int main()
{
    //DECLARACION DE VAARIABLES
    int areaTriangulo,base,altura;
    base = 15;
    altura = 30;
    areaTriangulo= (base*altura)/2;
    //DATOS A IMPRIMIR EN PANTALLA
    printf ("La area del triangulo es : %i  \n", areaTriangulo);
    printf ("Base = %i cm \n", base);
    printf ("Altura = %i cm \n", altura);
    return 0;
}
