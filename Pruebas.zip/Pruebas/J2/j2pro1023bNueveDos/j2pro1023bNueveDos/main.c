#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base;
    int altura;
    int areaTriangulo;
    base = 16;
    altura = 12;
    areaTriangulo = base * altura / 2;
    printf("Area de Triangulo\n");
    printf("Base = %d\n", base);
    printf("Altura = %d\n", altura);
    printf("Area triangulo: %d * %d / 2 = %d\n", base, altura, areaTriangulo);
    return 0;
}
