#include<stdio.h>
int main() {
    int areaTriangulo,base,altura;
    altura=10;
    base=13;

    areaTriangulo=(base*altura)/2;

    printf("EL area del triangulo es:%d\n",areaTriangulo);

    return 0;
}