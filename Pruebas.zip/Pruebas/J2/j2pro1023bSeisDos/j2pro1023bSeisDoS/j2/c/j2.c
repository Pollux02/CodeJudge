#include <stdio.h>
#include <stdlib.h>

int main()
{
printf("Area del triangulo con valores definidos:D\n\n");
    printf("***************************************************************************************\n\n");

    int base = 5;
    int altura = 8;
    int areaTriangulo = (base * altura)/2;

        printf("Valor de base: %d\n", base);
        printf("Valor de altura: %d\n\n", altura);
        printf("Area del triangulo:\n");
        printf("Valor de areaTriangulo: %d\n\n", areaTriangulo);

    printf("***************************************************************************************\n\n");
return 0;
}
