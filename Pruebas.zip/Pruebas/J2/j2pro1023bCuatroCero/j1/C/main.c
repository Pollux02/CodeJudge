#include <stdio.h>
#include <stdlib.h>

int main(){
    int a;
    int b;
    int h;

    b = 5;
    h = 8;
    a = b*h/2;

    printf("Base: %d\n", b);
    printf("Altura: %d\n\n", h);
    printf("Área del triángulo: %d\n", a);

    return 0;
 }
