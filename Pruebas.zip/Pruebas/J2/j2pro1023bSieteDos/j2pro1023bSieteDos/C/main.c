#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo, base, altura;

    base = 5;
    altura = 3;

    areaTriangulo = (base*altura)/2;



    printf("El area del triangulo es: %d", areaTriangulo);
    return 0;
}
