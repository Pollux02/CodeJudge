#include <stdio.h>
#include <stdlib.h>

int main()
{

   int base,altura,AreaTriangulo;
   base=8;
   altura=14;
   AreaTriangulo=base*altura/2;
   printf("Base de triangulo: %d\n",base);
   printf("Altura de triangulo: %d\n\n",altura);
   printf("Area de triangulo: %d\n",AreaTriangulo);
   return 0;
}
