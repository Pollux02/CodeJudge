#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,areaTriangulo;
    base=16;
    altura=20;
    areaTriangulo=(base*altura)/2;
    printf("El area de un triangulo es  : %d\n", areaTriangulo);
    printf("La base de un triangulo es  : %d\n", base);
    printf("La altura de un triangulo es: %d\n", altura);
    printf("\n\nPresiona entrar para continuar...\n\n");
    return 0;
}
