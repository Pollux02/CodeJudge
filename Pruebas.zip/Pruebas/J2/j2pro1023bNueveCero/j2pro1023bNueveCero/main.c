#include <stdio.h>
#include <stdlib.h>
int main(){
    int areaTriangulo,base,altura;
    base=5;
    altura=10;
    areaTriangulo=base*altura/2;
    printf("areaTriangulo: %d",areaTriangulo);
}
