#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo,base,altura;
    base=15;
    altura=5;
    areaTriangulo= base*altura/2;
    printf("base: %d\n",base);
    printf("altura: %d\n",altura);
    printf("El area del triangulo es: %d\n",areaTriangulo);
    return 0;
}
