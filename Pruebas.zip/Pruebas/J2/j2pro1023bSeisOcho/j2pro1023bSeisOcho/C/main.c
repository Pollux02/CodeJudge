#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo, base, altura;
    base = 56;
    altura = 38;
    areaTriangulo = base*altura/2;
    printf("El area del triangulo con base de %dcm y %dcm de altura es: %dcm", base, altura,areaTriangulo);
    return 0;
}
