#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,areaTriangulo;
    base=50;
    altura=3;
    areaTriangulo= (base*altura)/2;
    printf("base del triangulo: %d\n",base);
    printf("altura del triangulo: %d\n\n",altura);
    printf("Area del triangulo: %d",areaTriangulo);
    return 0;
}
