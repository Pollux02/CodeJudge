#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo,base,altura;
    base= 12;
    altura= 15;
    areaTriangulo= base*altura/2;

    printf("la base de nuestro triangulo es de: %d\n",base);
    printf("la altura de nuestro triangulo es de: %d\n",altura);
    printf("el area de nuestro triangulo es de: %d\n",areaTriangulo);
    return 0;
}
