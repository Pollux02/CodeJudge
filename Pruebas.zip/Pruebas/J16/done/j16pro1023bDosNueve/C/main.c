//DosNueve
//Ejercicio 16
//"Tiempo=00:26"
#include <stdio.h>
#include <stdlib.h>

#define TAMANIO 50

typedef struct{
    char nombre[TAMANIO];
    int edad;
    float estatura;
    int idCarrera;
}Alumno;
typedef struct{
    int idCarrera;
    char nombre[TAMANIO];
}Carrera;

int main()
{
    Alumno alumno;
    Carrera carrera;

    printf("DATOS DE UNA CARRERA\n\n");
    printf("Datos de la carrera\n");
    printf("Dame la id de la carrera: ");
    scanf("%d",&carrera.idCarrera);
    getchar();
    printf("Dame el nombre de la carrera: ");
    fgets(carrera.nombre,TAMANIO,stdin);

    printf("\nDatos de un estudiante\n");
    printf("Dame el nombre del alumno: ");
    fgets(alumno.nombre,TAMANIO,stdin);
    printf("Dame la edad del alumno: ");
    scanf("%d",&alumno.edad);
    getchar();
    printf("Dame estatura del alumno: ");
    scanf("%f",&alumno.estatura);
    printf("La idCarrera del estudiante es: %d \n",carrera.idCarrera);
    alumno.idCarrera = carrera.idCarrera;

    printf("\n\n\nLos datos de la carrera son: \n");
    printf("La id de la carrera es: %d\n",carrera.idCarrera);
    printf("El nombre de la carrera es: %s",carrera.nombre);

    printf("\n\nLos datos del alumno son: \n");
    printf("El nombre del alumno es: %s ",alumno.nombre);
    printf("La edad del alumno es: %d\n",alumno.edad);
    printf("La idCarrera del estudiante es: %d\n",alumno.idCarrera);
    printf("La estatura del alumno es: %.2f\n\n",alumno.estatura);

    return 0;
}

