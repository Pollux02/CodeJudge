#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
    radio=8.30;
    pi= 3.14;
    areaCirculo= pi*radio*radio;
    printf("el radio del circulo es %.2f\n",radio);
    printf("el pi equivale a: %.2f\n",pi);
    printf("el area del ciculo es: %.2f",areaCirculo);
    return 0;
}
