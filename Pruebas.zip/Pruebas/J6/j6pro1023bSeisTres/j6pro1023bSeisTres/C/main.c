#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
    radio=10;
    pi=3.1416;
    areaCirculo=(pi*radio*radio);
    printf("El radio del circulo es: %f\n",radio);
    printf("pi es: %f \n",pi);
    printf("El area del circulo es: %f\n",areaCirculo);
    return 0;
}
