//SieteSiete

#include <stdio.h>


int main()
{
    float a, r, pi;
    radio=10;
    pi = 3.1416;
    areaCirculo= pi*r*r;
    
    printf("El valor del area es %.2f\n",areaCirculo);
    printf("El valor del radio es %.2f\n", radio);
    printf("El valor de pi es %.2f\n", pi);
    
    
    return 0;
}
