#include <stdio.h>
#include <stdlib.h>

int main(){
    float areaCirculo, radio, pi;
    radio = 8;
    pi = 3.1416;
    areaCirculo = pi * (radio*2);
    printf("Area del circulo: %.2f\n", areaCirculo);
    printf("Radio del circulo: %.2f\n", radio);
    printf("Pi: %.4f\n", pi);
}
