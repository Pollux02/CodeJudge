#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
    printf("Calculo del area de un Circulo\n\n");

    radio=4;
    pi=3.1416;
    areaCirculo=pi*radio;

    printf("El area del circulo es: %f\n",areaCirculo);
    printf("El radio equivale a %f\n", radio);
    radio=radio*radio;
    printf("Pi equivale a: %f\n",pi);

    return 0;
}

