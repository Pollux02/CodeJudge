#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("-Calcular el area de un circulo-\n\n");
    float areaCirculo,radio,pi;
    radio=9.4;
    pi=3.1416;
    areaCirculo=radio*radio*pi;
    printf("El area total del circulo es: %.4f\n",areaCirculo);
    printf("El radio del circulo es: %.1f\n",radio);
    printf("El valor de pi es: %.4f",pi);
}
