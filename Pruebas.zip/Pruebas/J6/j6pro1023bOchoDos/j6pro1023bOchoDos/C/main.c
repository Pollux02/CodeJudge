#include<stdio.h>
#include<math.h>
int main(){
    float areaCirculo,radio,pi;
    pi=3.1416;
    radio=5;
    areaCirculo=pi*sqrt(radio);
    printf("EL area del circulo es:%f\n",areaCirculo);
    printf("r=%f\n",radio);
    printf("pi=%f\n",pi);




    return 0;
}