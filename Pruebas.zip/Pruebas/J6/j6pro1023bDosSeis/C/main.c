#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
    printf("Ingrese el valor del radio: ");
    scanf("%f",&radio);
    pi=3.1416;
    areaCirculo=pi*radio*radio;
    printf("\n\nEl area de tu circulo es de: %f\n",areaCirculo);
    printf("El valor del radio es de: %f\n", radio);
    printf("El valor de pi es de: %f\n\n",pi);
    return 0;
}
