#include <stdio.h>
#include <stdlib.h>

int main()
{
printf("Area del ciruclo con datos definidos :D\n\n");
    printf("***************************************************************************************\n\n");

    float radio= 10;
    float pi= 3.1416;
    float areaCirulo= pi*(radio*radio);

        printf("Valor de radio: %f\n", radio);
        printf("Valor de pi: %f\n\n", pi);
        printf("Area del circulo:\n");
        printf("Valor de areaCirculo: %f\n\n", areaCirulo);

    printf("***************************************************************************************\n\n");
return 0;
}
