#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
    radio=10;
    pi=3.14;
    areaCirculo=pi*radio*radio;
    printf("Pi= %f\n",pi);
    printf("radio= %f\n",radio);
    printf("areaCirculo= %f\n",areaCirculo);
    return 0;
}
