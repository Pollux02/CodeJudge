#include <stdio.h>
#include <stdlib.h>

int main()
{
    //DECLARACION DE VARIABLES
    float areaCirculo,radio,pi;
    //ASIGNACION DE VALOR PARA LAS VARIABLES
    radio=10;
    pi=3.1416;
    areaCirculo=pi*radio*radio;

    printf("El area del circulo es : %.2f\n",areaCirculo);
    printf ("Radio = 10\n");
    printf ("pi = %.2f\n",pi);

    return 0;
}
