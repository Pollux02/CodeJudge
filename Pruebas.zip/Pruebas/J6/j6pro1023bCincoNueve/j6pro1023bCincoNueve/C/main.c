#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo, radio, pi;
    radio= 57.64;
    pi= 3.1416;
    areaCirculo= pi*radio*radio;
    printf("Datos del circulo: \n\n");
    printf("AREA  = %.4f\n",areaCirculo);
    printf("RADIO = %.4f\n",radio);
    printf("PI    = %.4f\n",pi);
    return 0;
}
