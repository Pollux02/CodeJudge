#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
    radio=16.2231;
    pi=3.1416;
    areaCirculo=pi*radio*radio;
    printf("El area del circulo es:%.4f\n\n",areaCirculo);
    printf("El valor del radio es:%.4f\n",radio);
    printf("El valor de pi es:%.4f\n",pi);
    return 0;
}
