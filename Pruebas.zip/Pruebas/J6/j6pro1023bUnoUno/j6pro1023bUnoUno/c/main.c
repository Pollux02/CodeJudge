#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Area de un circulo\n\n");
    float areaCirculo,radio,pi;
    radio=64;
    pi=3.1416;
    areaCirculo=pi*radio;
    printf("El area del circulo es:\na=%f\n\n",areaCirculo);
    printf("r=%f\n\n",radio);
    printf("pi=%f\n\n",pi);
    return 0;
}
