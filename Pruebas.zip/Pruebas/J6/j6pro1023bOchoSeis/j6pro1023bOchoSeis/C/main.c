/* Implemente un programa que calcule el �rea de un c�rculo usando
variables float nombradas "areaCirculo", "radio" y "pi".
Imprimir los valores de cada variable en el orden descrito.
No es necesario solicitar datos al usuario. */

#include<stdio.h>
#include<math.h>

int main(){
	float areaCirculo, radio, pi;

	printf("Calcular el area de un circulo.\n\n");

	radio = 5;
	pi = 3.1416;
	areaCirculo = pi * (pow(radio, 2));

	printf("Area del circulo: %f\n",areaCirculo);
	printf("Radio del circulo: %f\n",radio);
	printf("Valor de 'pi': %f\n\n",pi);

	return 0;
}
