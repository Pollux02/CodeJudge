#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo, radio, pi;
    printf("Calcula el area de un Circulo. \n");
    pi = 3.14159;
    printf("Dame un valor para el Radio: ");
    scanf("%f", &radio);

    areaCirculo = pi * radio * radio;
    printf("\nArea del Circulo: %f\n", areaCirculo);
    printf("Radio: %f\n", radio);
    printf("Pi: %f\n", pi);

    return 0;
}
