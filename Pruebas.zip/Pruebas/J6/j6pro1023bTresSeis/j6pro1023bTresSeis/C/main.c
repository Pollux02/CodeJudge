#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;

    radio=25;
    pi=3.1416;
    areaCirculo=pi*(radio*radio);
    printf("area del circulo: %f\n",areaCirculo);
    printf("Radio: %f\n",radio);
    printf("pi: %f\n",pi);

    return 0;
}
