#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
   radio=3;
   pi=3.1416;
   areaCirculo= pi*radio*radio;
   printf("el valor de la area es:%f\n",areaCirculo);
   return 0;
}
