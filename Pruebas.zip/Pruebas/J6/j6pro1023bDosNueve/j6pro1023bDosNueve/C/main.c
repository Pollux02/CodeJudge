#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
    radio=5.0;
    pi=3.1416;
    printf("Calculando el area de un ciculo =)\n");
    areaCirculo=pi*radio*radio;
    printf("El valor de 'pi' es: %.4f\n", pi);
    printf("El valor del radio 'r' es: %.1f\n", radio);
    printf("El �rea del c�rculo 'a' es: %.5f\n", areaCirculo);

    return 0;
}
