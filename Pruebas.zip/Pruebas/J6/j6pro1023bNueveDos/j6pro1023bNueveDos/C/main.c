#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("******Area de un circulo******\n\n");
    float areaCirculo;
    float radio;
    float pi;
    radio = 12.5;
    pi = 3.1416;
    areaCirculo = pi * radio * radio;
    printf("areaCirculo = %f * %f ** 2 = %f\n\n", pi, radio, areaCirculo);
    printf("radio = %f\n\n", radio);
    printf("pi = %f\n", pi);
    return 0;
}
