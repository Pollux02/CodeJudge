#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo, radio, pi;

    radio = 10;
    pi = 3.1415;
    areaCirculo = (radio*radio)*pi;


    printf("El area del circulo es igual a : %f\n", areaCirculo);
    printf("El radio del circulo es igual a : %f\n", radio);
    printf("El valor de pi: %f\n", pi);


    return 0;
}
