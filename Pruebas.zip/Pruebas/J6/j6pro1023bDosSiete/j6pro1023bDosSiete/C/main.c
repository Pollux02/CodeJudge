#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio,pi;
    radio= 3.20;
    pi= 3.1416;
    areaCirculo= pi*radio*radio;
    printf("El area del circulo es: %.2f\n",areaCirculo);
    printf("El radio es: %f\n",radio);
    printf("Valor de pi: %f\n",pi);
    return 0;
}
