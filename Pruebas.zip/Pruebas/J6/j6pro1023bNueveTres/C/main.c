#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo, radio=2, pi=3.1416;
    areaCirculo=(radio*radio)*pi;
    printf("Los datos recaudados son:\nareaCirculo: %f\nradio: %f\npi: %f", areaCirculo, radio, pi);
    return 0;
}
