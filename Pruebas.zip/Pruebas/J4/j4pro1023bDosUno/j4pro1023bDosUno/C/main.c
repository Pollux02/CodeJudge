#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    printf("ingresa un valor entero para a: ");
    scanf("%d",&a);
    printf("ingresa un valor entero para b: ");
    scanf("%d",&b);

    printf("el valor de a= %d\n",a);
    printf("el valor de b= %d\n",b);

    int suma,resta,resta2,multi,div1,div2,mod,mod1;
    suma=a+b;
    resta=a-b;
    resta2=b-a;
    multi=a*b;
    div1=a/b;
    div2=b/a;
    mod=a%b;
    mod1=b%a;

    printf("a+b= %d\n",suma);
    printf("a-b= %d\n",resta);
    printf("b-a= %d\n",resta2);
    printf("a*b= %d\n",multi);
    printf("a/b= %d\n",div1);
    printf("b/a= %d\n",div2);
    printf("a%%b= %d\n",mod);
    printf("b%%a= %d\n",mod1);

    return 0;
}
