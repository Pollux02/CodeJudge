#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c1,c2,c3,c4,c5,c6,c7,c8;
    printf("Ingresa el valor de la variable a: ");
    scanf("%d",&a);
    printf("Ingresa el valor de la variable b: ");
    scanf("%d",&b);
    c1=a+b;
    c2=a-b;
    c3=b-a;
    c4=a*b;
    c5=a/b;
    c6=b/a;
    c7=a%b;
    c8=b%a;
    printf("El valor de a es: %d\n",a);
    printf("El valor de b es: %d\n",b);
    printf("a+b = %d\n",c1);
    printf("a-b = %d\n",c2);
    printf("b-a = %d\n",c3);
    printf("a*b = %d\n",c4);
    printf("a/b = %d\n",c5);
    printf("b/a = %d\n",c6);
    printf("a%b = %d\n",c7);
    printf("b%a = %d\n",c8);

    return 0;
}
