#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Digite un valor para a: ");
    scanf("%d", &a);

    printf("Digite un valor para b: ");
    scanf("%d",&b);

    printf("a + b = %d\n", (a+b));
    printf("a - b = %d\n", (a-b));
    printf("b - a = %d\n", (b-a));
    printf("a * b = %d\n", (a*b));

    printf("a / b = %d\n", (a/b));
    printf("b / a = %d\n", (b/a));
    printf("a %% b = %d\n", (a%b));
    printf("b %% a = %d\n", (b%a));


    return 0;
}
