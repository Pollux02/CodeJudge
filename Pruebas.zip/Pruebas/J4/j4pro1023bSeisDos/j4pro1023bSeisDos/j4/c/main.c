#include <stdio.h>
#include <stdlib.h>

int main()
{
printf("Operaciones basicas con dos numeros enteros :D\n\n");
    printf("***************************************************************************************\n\n");

    int a;
    int b;
    int suma;
    int resta;
    int resta2;
    int multi;
    int division;
    int division2;
    int residuo;
    int residuo2;


        printf("Favor de escribir cualquier numero entero:");
        scanf ("%d", &a);
        printf("Favor de escribir otro numero entero:");
        scanf ("%d", &b);
        printf("\nEl valor de a es : %d\n", a);
        printf("El valor de a es : %d\n\n", b);

    suma=a+b;
    resta=a-b;
    resta2=b-a;
    multi=a*b;
    division=a/b;
    division2=b/a;
    residuo=a%b;
    residuo2=b%a;

        printf("a + b = %d\n",suma);
        printf("a - b = %d\n",resta);
        printf("b - a = %d\n",resta2);
        printf("a * b = %d\n",multi);
        printf("a / b = %d\n",division);
        printf("b / a = %d\n",division2);
        printf("a %% b = %d\n",residuo);
        printf("b %% a = %d\n",residuo2);



    printf("***************************************************************************************\n\n");
return 0;
}
