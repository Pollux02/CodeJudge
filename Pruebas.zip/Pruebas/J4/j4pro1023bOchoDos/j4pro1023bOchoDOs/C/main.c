#include<stdio.h>

int main(){
    int a,b;
    printf("Dame el valor de a:");
    scanf("%d",&a);

    printf("Dame el valor de b:");
    scanf("%d",&b);
    
    printf("el valor de a es:%d\n",a);
    printf("el valor de a es:%d\n",b);

    printf("%d + %d = %d\n",a,b,a+b);
    printf("%d - %d = %d\n",a,b,a-b);
    printf("%d - %d = %d\n",b,a,b-a);
    printf("%d * %d = %d\n",a,b,a*b);
    printf("%d / %d = %d\n",a,b,a/b);
    printf("%d / %d = %d\n",b,a,b/a);
    printf("%d %% %d = %d\n",a,b,a%b);
    printf("%d %% %d = %d\n",b,a,b%a);

    return 0; 
}
