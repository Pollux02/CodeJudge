#include <stdio.h>
#include <stdlib.h>

int main()
{
     int a,b,suma,res,restainversa,mul,div,divinv,c,c1;
    printf("ingresa un valor para a: ");
    scanf("%d",&a);
    printf("ingresa un valor para b: ");
    scanf("%d",&b);
    suma = a+b;
    res = a-b;
    restainversa = b-a;
    mul = a * b;
    div = a/b;
    divinv =b/a;
    c= a%b;
    c1 = b%a;
    printf("a+b= %d\n",suma);
    printf("a-b= %d\n",res);
    printf("b-a= %d\n",restainversa);
    printf("a*b= %d\n",mul);
    printf("a/b= %d\n",div);
    printf("b/a= %d\n",divinv);
    printf("a%%b= %d\n",c);
    printf("b%%a= %d\n",c1);;
    return 0;
}
