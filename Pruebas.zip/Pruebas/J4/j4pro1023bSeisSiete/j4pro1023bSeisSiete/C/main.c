#include <stdio.h>
#include <stdlib.h>
//EJERCICIO 4 PROGRAMACION ESTRUCTURADA.
int main()
{
    //DECLARACION DE VARIABLES
    int a,b,c;
    //SOLICITAR VALORES Y LEER LOS VALORES
    printf("Ingrese un valor numerico entero para a: \n");
    scanf ("%i", &a);
    printf ("Ingrese un valor numerico entero para b: \n");
    scanf ("%i",&b);
    printf ("El valor de a es: %i\n",a);
    printf ("El valor de b es: %i\n",b);
    c=a+b;
    printf ("a+b=%i\n",c);
    c=a-b;
    printf ("a-b=%i\n",c);
    c=b-a;
    printf ("b-a=%i\n",c);
    c=a*b;
    printf ("a*b=%i\n",c);
    c=a/b;
    printf ("a/b=%i\n",c);
    c=b/a;
    printf ("b/a=%i",c);
    c=a%b;
    printf ("a%b=%i\n",c);
    c=b%a;
    printf ("b%a=%i\n",c);
    return 0;
}
