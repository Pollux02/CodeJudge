#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;
    printf("Ingresa un valor para a: ");
    scanf("%d", &a);

    printf("Ingresa un valor para b: ");
    scanf("%d", &b);

    printf("\n\nEl valor de a es: %d\n", a);
    printf("El valor de b es: %d\n", b);
    printf("a + b = %d\n", a+b);
    printf("a - b = %d\n", a-b);
    printf("b - a = %d\n", b-a);
    printf("a * b = %d\n", a*b);
    printf("a / b = %d\n", a/b);
    printf("b / a = %d\n", b/a);
    printf("a %% b = %d\n", a%b);
    printf("b %% a = %d\n", b%a);
    return 0;
}
