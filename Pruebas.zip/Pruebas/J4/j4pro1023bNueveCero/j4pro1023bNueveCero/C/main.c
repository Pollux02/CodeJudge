#include <stdio.h>
#include <stdlib.h>
int main (){
    int a,b,c;
    printf("valor de a: ");
    scanf("%d",&a);
    printf("valor de b: ");
    scanf("%d",&b);
    c=a+b;
    printf("%d + %d = %d \n",a,b,c);
    c=a-b;
    printf("%d - %d = %d \n",a,b,c);
    c=b-a;
    printf("%d - %d = %d \n",b,a,c);
    c=a*b;
    printf("%d * %d = %d \n",a,b,c);
    c=a/b;
    printf("%d / %d = %d \n",a,b,c);
    c=b/a;
    printf("%d / %d = %d \n",b,a,c);
    c=a%b;
    printf("%d %% %d = %d \n",a,b,c);
    c=b%a;
    printf("%d %% %d = %d \n",b,a,c);

    return 0;
}
