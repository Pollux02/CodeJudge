#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,d,e,f,g,h,i,j;
    printf("Dame el valor de la variable a: ");
    scanf("%d", &a);
    printf("Dame el valor de la variable b: ");
    scanf("%d", &b);
    c=a+b;
    d=a-b;
    e=b-a;
    f=a*b;
    g=a/b;
    h=b/a;
    i=a%b;
    j=b%a;
    printf("a+b=%d\n",c);
    printf("a-b=%d\n",d);
    printf("b-a=%d\n",e);
    printf("a*b=%d\n",f);
    printf("a/b=%d\n",g);
    printf("b/a=%d\n",h);
    printf("a%%b=%d\n",i);
    printf("b%%a=%d\n",j);
    return 0;
}
