#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, a1,a2,a3,a4,a5,a6,a7,a8;
    printf("Programa de operaciones\n\n");
    printf("Cual es tu primer valor?  ");
    scanf("%d", &a);
    printf("\nCual es tu segundo valor?  ");
    scanf("%d", &b);
    a1=a + b;
    a2=a - b;
    a3=b - a;
    a4=a * b;
    a5=a / b;
    a6=b / a;
    a7=a % b;
    a8=b % a;
    printf("\n\nEl resultado de las operaciones son:\n\n");
    printf("%d + %d= %d\n", a, b, a1);
    printf("%d - %d= %d\n", a, b, a2);
    printf("%d - %d= %d\n", b, a, a3);
    printf("%d * %d= %d\n", a, b, a4);
    printf("%d / %d= %d\n", a, b, a5);
    printf("%d / %d= %d\n", b, a, a6);
    printf("%d % % %d= %d\n", a, b, a7);
    printf("%d % % %d= %d\n", b, a, a8);

    return 0;
}
