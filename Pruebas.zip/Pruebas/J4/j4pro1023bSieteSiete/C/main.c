//David Leonardo Flores Moreno
#include <stdio.h>

#define CERO 0
int main()
{
    int a=CERO,b=CERO;
    printf("Escribe un numero: ");
    scanf("%i",&a);
    printf("Escribe otro numero: ");
    scanf("%i",&b);
    printf("El valor de a es %i\n", a);
    printf("El valor de b es %i\n", a);
    printf("a+b= %i\n",a+b );
    printf("a-b= %i\n",a-b);
    printf("b-a= %i\n",b-a);
    printf("a*b= %i\n",a*b);
    printf("a/b= %i\n",a/b);
    printf("b/a= %i\n",b/a);
    printf("a%%b= %i\n",a%b);
    printf("b%%a= %i\n",b%a);
    
    return 0;
}
