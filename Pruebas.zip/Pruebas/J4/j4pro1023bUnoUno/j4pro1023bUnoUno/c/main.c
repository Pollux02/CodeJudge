#include <stdio.h>
#include <stdlib.h>
//Operaciones basicas
int main()
{
    printf("Operaciones basicas\n\n");
    int a,b,c;
    printf("Dame el valor de a:");
    scanf("%d",&a);
    printf("Dame el valor de b:");
    scanf("%d",&b);
    printf("\n\n");
    printf("El valor de a es:%d\n",a);
    printf("El valor de b es:%d\n\n",b);
    c=a+b;
    printf("a + b=%d\n",c);
    c=0;
    c=a-b;
    printf("a - b=%d\n",c);
    c=0;
    c=b-a;
    printf("b - a=%d\n",c);
    c=0;
    c=a*b;
    printf("a * b=%d\n",c);
    c=0;
    c=a/b;
    printf("a / b=%d\n",c);
    c=0;
    c=b/a;
    printf("b / a=%d\n",c);
    c=0;
    c=a%b;
    printf("a %% b=%d\n",c);
    c=0;
    c=b%a;
    printf("b %% a=%d\n",c);
    return 0;
}
