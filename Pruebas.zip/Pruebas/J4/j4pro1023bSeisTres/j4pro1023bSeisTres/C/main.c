#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    printf("Ingresa el valor de a:");
    scanf("%d",&a);
    printf("Ingresa el valor de b:");
    scanf("%d",&b);
    printf("El valor de a es: %d \n",a);
    printf("El valor de a es: %d \n",b);
    printf("a + b= %d\n",a+b);
    printf("a - b= %d\n",a-b);
    printf("b - a= %d\n",b-a);
    printf("a * b= %d\n",a*b);
    printf("a / b= %d\n",a/b);
    printf("b / a= %d\n",b/a);
    printf("a %% b= %d\n",a%b);
    printf("b %% a= %d\n",b%a);

    return 0;

}
