#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    printf("Ingrese un valor para a: ");
    scanf("%d",&a);
    printf("Ingrese un valor para b: ");
    scanf("%d",&b);
    printf("\nEl valor de a es: %d\n",a);
    printf("El valor de b es: %d\n",b);
    printf("a + b = %d\n",a+b);
    printf("a - b = %d\n",a-b);
    printf("b - a = %d\n",b-a);
    printf("a * b = %d\n",a*b);
    printf("a / b = %d\n",a/b);
    printf("b / a = %d\n",b/a);
    printf("a %% b = %d\n",a%b);
    printf("b %% a = %d\n",b%a);
    return 0;
}
