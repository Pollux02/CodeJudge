#include<stdio.h>

int main(){
	int a, b, suma, resta, resta2, multi, div, div2, mod, mod2;
	
	printf("Ingresa un valor para 'a': "); scanf("%d",&a);
	printf("Ingresa un valor para 'b': "); scanf("%d",&b);
	
	printf("El valor de a es: %d\n",a);
	printf("El valor de b es: %d\n\n",b);
	
	suma = a + b;
	resta = a - b;
	resta2 = b - a;
	multi = a * b;
	div = a / b;
	div2 = b / a;
	mod = a % b;
	mod2 = b % a;
	
	printf("a + b = %d\n",suma);
	printf("a - b = %d\n",resta);
	printf("b - a = %d\n",resta2);
	printf("a * b = %d\n",multi);
	printf("a / b = %d\n",div);
	printf("b / a = %d\n",div2);
	printf("a %% b = %d\n",mod);
	printf("b %% a = %d\n",mod2);
	
	return 0;
}
