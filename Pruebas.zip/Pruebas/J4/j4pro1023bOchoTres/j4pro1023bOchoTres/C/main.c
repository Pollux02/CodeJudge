#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,s,r1,r2,m,d1,d2,t1,t2;
    printf("Ingresa un valor entero para a:");
    scanf("%d",&a);
    printf("Ingresa un valor entero para b:");
    scanf("%d",&b);
    printf("\nEl valor de a es:%d\n",a);
    printf("El valor de b es:%d\n\n",b);
    s=a+b;
    r1=a-b;
    r2=b-a;
    m=a*b;
    d1=a/b;
    d2=b/a;
    t1=a%b;
    t2=b%a;
    printf("a+b=%d\n",s);
    printf("a-b=%d\n",r1);
    printf("b-a=%d\n",r2);
    printf("a*b=%d\n",m);
    printf("a/b=%d\n",d1);
    printf("b/a=%d\n",d2);
    printf("a%%b=%d\n",t1);
    printf("b%%a=%d\n",t2);
    return 0;
}
