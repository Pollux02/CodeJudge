#include <stdio.h>
#include <stdlib.h>

int main(){
    int a , b;
    printf("Ingrese el numero 'a': ");
    scanf("%d",&a);
    printf("Ingrese el numero 'b': ");
    scanf("%d",&b);

    printf("El valor de 'a' es: %d\n", a);
    printf("El valor de 'b' es: %d\n", b);

    printf("a + b = %d\n", a+b);
    printf("a - b = %d\n", a-b);
    printf("b - a = %d\n", b-a);
    printf("a * b = %d\n", a*b);
    printf("a / b = %d\n", a/b);
    printf("b / a = %d\n", b/a);
    printf("a \%% b = %d\n", a%b);
    printf("b \%% a = %d\n", b%a);
}
