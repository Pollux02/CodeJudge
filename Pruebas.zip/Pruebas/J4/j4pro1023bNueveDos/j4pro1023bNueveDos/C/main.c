#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;
    printf("Ingrese el valor de a: ");
    scanf("%d", &a);
    printf("Ingrese el valor de b: ");
    scanf("%d", &b);
    printf("\nEl valor de a es: %d\n", a);
    printf("El valor de b es: %d\n", b);
    printf("a + b = %d\n", a + b);
    printf("a - b = %d\n", a - b);
    printf("b - a = %d\n", b - a);
    printf("a * b = %d\n", a * b);
    printf("a / b = %d\n", a / b);
    printf("b / a = %d\n", b / a);
    printf("a %% b = %d\n", a % b);
    printf("b %% a = %d\n", b % a);
    return 0;
}
