// SeisSiete EJERCICIO 19 Tiempo=00:30

#include <iostream>
#define SALARIO_MINIMO 18000
#define SALARIO_INTERMEDIO 30000
#define SALARIO_MAXIMO 50000
#define PORCENTAJE_INCREMENTO_MAX_SALARIO 12
#define PORCENTAJE_INCREMENTO_INTER_SALARIO 8
#define PORCENTAJE_INCREMENTO_MIN_SALARIO 7
#define CONST_100 100

using namespace std;

int main()
{
    float salarioProfesor;
    cout << "Calculo de incremento de salario" << endl;
    cout << "Dame el valor de tu salario actual" << endl;
    cin >> salarioProfesor;
    if (salarioProfesor<SALARIO_MINIMO){
        salarioProfesor+=(salarioProfesor*PORCENTAJE_INCREMENTO_MAX_SALARIO/CONST_100);
    }
    else if (salarioProfesor>=SALARIO_MINIMO&&salarioProfesor<=SALARIO_INTERMEDIO){
        salarioProfesor+=(salarioProfesor*PORCENTAJE_INCREMENTO_INTER_SALARIO/CONST_100);
    }
    else if (salarioProfesor>SALARIO_INTERMEDIO&&salarioProfesor<=SALARIO_MAXIMO){
        salarioProfesor+=(salarioProfesor*PORCENTAJE_INCREMENTO_MIN_SALARIO/CONST_100);
    }
    cout << endl << "Tu salario es de = $" << salarioProfesor << endl;
    return 0;
}
