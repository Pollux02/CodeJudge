#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo, base, altura;
    printf("Datos del triangulo:\n\n");
    printf("Ingrese un valor para la base : ");
    scanf("%d", &base);
    printf("Ingrese un valor para la altura : ");
    scanf("%d", &altura);
    areaTriangulo=base*altura/2;
    printf("La area es = %d\n ",areaTriangulo);
    return 0;
}
