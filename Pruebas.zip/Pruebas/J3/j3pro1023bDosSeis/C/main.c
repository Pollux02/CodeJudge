#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,areaTriangulo;
    printf("Dame el valor de base: ");
    scanf("%d",&base);
    printf("Dame el valor de altura: ");
    scanf("%d",&altura);
    areaTriangulo=(base*altura/2);
    printf("Tu area es  : %d\n", areaTriangulo);
    printf("Tu base es  : %d\n", base);
    printf("Tu altura es: %d\n\n", altura);
    return 0;
}
