#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base, altura, areaTriangulo;
    printf("Ingrese el valor de la base: ");
    scanf("%d", &base);
    printf("Ingrese el valor de la altura: ");
    scanf("%d", &altura);
    areaTriangulo = base * altura / 2;
    printf("Area de Triangulo\n");
    printf("Base = %d\n", base);
    printf("Altura = %d\n", altura);
    printf("Area triangulo: %d * %d / 2 = %d\n", base, altura, areaTriangulo);
    return 0;
}
