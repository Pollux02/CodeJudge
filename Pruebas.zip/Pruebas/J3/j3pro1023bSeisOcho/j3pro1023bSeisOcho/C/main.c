#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo, base, altura;
    printf("Ingrese la base del triangulo: ");
    scanf("%d", &base);
    printf("\nIngrese la altura del triangulo: ");
    scanf("%d", &altura);
    areaTriangulo = base*altura/2;
    printf("\nEl area del triangulo con base de %dcm y %dcm de altura es: %dcm", base, altura,areaTriangulo);
    return 0;
}
