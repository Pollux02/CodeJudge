#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo,base,altura;
    printf("Dime el valor de la variable a: ");
    scanf("%d",&base);
    printf("Dime el valor de la variable b: ");
    scanf("%d",&altura);
    areaTriangulo=base*altura/2;
    printf("Area del triangulo: %d\n",areaTriangulo);
    return 0;
}
