#include<stdio.h>
int main() {
    int areaTriangulo,base,altura;
    printf("Dame la base del triangulo\n");
    scanf("%d",&base);
    printf("Dame la altura del triangulo\n");
    scanf("%d",&altura);
    areaTriangulo=(base*altura)/2;


    printf("EL area del triangulo es:%d\n",areaTriangulo);

    return 0;
}