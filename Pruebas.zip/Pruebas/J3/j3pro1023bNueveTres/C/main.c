#include <stdio.h>
#include <stdlib.h>

int main()
{
    //AREA

    int areaTriangulo;
    //BASE
    int base;
        printf("Cual es la base del triangulo?  ");
        scanf("%d", &base);
    //ALTURA
    int altura;
        printf("\nCual es la altura del triangulo?  ");
        scanf("%d", &altura);
    //OPERACION
    areaTriangulo=(base*altura)/2;
    //IMPRESION
    printf("\nEl resultado del area es: %d", areaTriangulo);
    return 0;
    }
