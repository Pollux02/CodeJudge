#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,areaTriangulo;
    printf("Ingrese la base del Triangulo:");
    scanf("%d",&base);

    printf("Ingrese la altura del Triangulo:");
    scanf("%d",&altura);

    areaTriangulo= (base*altura)/2;

    printf("\nbase del triangulo: %d\n",base);
    printf("altura del triangulo: %d\n\n",altura);
    printf("Area del triangulo: %d",areaTriangulo);
    return 0;
}
