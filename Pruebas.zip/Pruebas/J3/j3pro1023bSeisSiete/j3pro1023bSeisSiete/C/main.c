#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo,base,altura;

        printf ("PROGRAMA PARA CALCULAR EL AREA DE UN TRIANGULO \n");
        printf ("Este  programa solo permite valores enteros\n\n");
        printf("Ingrese la medida de la base del triangulo :");
        scanf ("%i", &base);
        printf ("Ingrese la medida de la altura del triangulo :");
        scanf ("%i", &altura);

        areaTriangulo = (base*altura)/2;

        printf ("\nEl area del triangulo es de :%i \n",areaTriangulo);
        printf ("Base = %i\n", base);
        printf ("Altura = %i\n", altura);
    return 0;
}
