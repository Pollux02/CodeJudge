#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo,base,altura;
    printf("valor de la base: ");
    scanf("%d", & base);
    printf("valor de la altura: ");
    scanf("%d", & altura);
    areaTriangulo=base * altura / 2;
    printf("area del triangulo: %d", areaTriangulo);

    return 0;
}
