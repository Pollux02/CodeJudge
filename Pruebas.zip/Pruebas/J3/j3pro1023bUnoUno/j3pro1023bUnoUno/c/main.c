#include <stdio.h>
#include <stdlib.h>
//Area de un triangulo 3
int main()
{
    printf("Area de un triangulo:\n\n");
    int areaTriangulo,base,haltura;
    printf("Dame la base del triangulo:");
    scanf("%d",&base);
    printf("Dame la altura del triangulo:");
    scanf("%d",&haltura);
    areaTriangulo=(base*haltura)/2;
    printf("\n\n");
    printf("El valor del area del triangulo es=%d\n\n",areaTriangulo);
    printf("El valor de la base del triangulo es=%d\n\n",base);
    printf("El valor de la haltura del triangulo es=%d\n\n",haltura);
    return 0;
}
