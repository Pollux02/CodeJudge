/* Implemente un programa que, usando  scanf() para base y
altura, calcule el �rea de un tri�ngulo usando variables
int nombradas "areaTriangulo", "base" y "altura". */
#include<stdio.h>

int main(){
	int areaTriangulo, base, altura;
	
	printf("Calcular el area de un triangulo.\n");
	printf("ingrese la base: ");
	scanf("%d",&base);
	printf("ingrese la altura: ");
	scanf("%d",&altura);
	
	areaTriangulo = (base * altura) / 2;
	
	printf("El area del triangulo es: %d\n",areaTriangulo);
	
	return 0;
}
