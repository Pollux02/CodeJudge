#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo, base, altura;

    printf("Digite el valor de la base: ");
    scanf("%d", &base);
    printf("Digite el valor de la altura: ");
    scanf("%d", &altura);
    areaTriangulo = (base*altura)/2;
    printf("El area del triangulo es igual a : %d", areaTriangulo);



    return 0;
}
