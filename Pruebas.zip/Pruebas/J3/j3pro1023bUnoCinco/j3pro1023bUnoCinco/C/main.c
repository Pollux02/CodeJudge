#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Area de un triangulo\n\n");
    int altura;
    int base;
    int area;
    printf("Introduzca altura\n");
    scanf("%d",&altura);
    printf("Introduzca base\n");
    scanf("%d",&base);
    area=base*altura/2;
    printf("El area es: %d",area);
    return 0;
}
