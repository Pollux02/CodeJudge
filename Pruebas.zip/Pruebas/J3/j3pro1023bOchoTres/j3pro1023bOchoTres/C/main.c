#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,areaTriangulo;
    printf("Calcula el area de un triangulo\n\n");
    printf("Ingresa la medida de la base:");
    scanf("%d",&base);
    printf("Ingresa la medida de la altura:");
    scanf("%d",&altura);
    areaTriangulo=base*altura/2;
    printf("\nEl area del triangulo es:%d\n",areaTriangulo);
    return 0;
}
