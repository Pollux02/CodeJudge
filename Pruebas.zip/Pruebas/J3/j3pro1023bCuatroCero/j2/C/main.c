#include <stdio.h>
#include <stdlib.h>

int main(){
    int base, altura, areaTriangulo;

    base = 10;
    altura = 6;
    areaTriangulo = base*altura/2;

    printf("Base: %d\n", base);
    printf("Altura: %d\n\n", altura);
    printf("El Area es: %d\n", areaTriangulo);
    return 0;

 }
