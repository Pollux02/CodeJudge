#include <stdio.h>
#include <stdlib.h>

int main()
{

   int base,altura,AreaTriangulo;
   printf("Ingrese la base del triangulo: ");
   scanf("%d",&base);
   printf("Ingrese la altura del triangulo: ");
   scanf("%d",&altura);
   AreaTriangulo=base*altura/2;
   printf("Base de triangulo: %d\n",base);
   printf("Altura de triangulo: %d\n\n",altura);
   printf("Area de triangulo: %d\n",AreaTriangulo);
    return 0;
}
