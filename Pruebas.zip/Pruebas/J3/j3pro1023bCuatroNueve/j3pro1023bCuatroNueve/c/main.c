#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo,base,altura;
    printf("escribe el valor de la base: ");
    scanf("%d",&base);
    printf("escribe el valor de la altura: ");
    scanf("%d",&altura);
    areaTriangulo = (base*altura)/2;
    printf("El area del triangulo es: %d",areaTriangulo);
    return 0;
}
