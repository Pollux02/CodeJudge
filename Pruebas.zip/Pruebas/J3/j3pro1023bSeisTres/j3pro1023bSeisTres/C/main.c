#include <stdio.h>
#include <stdlib.h>

int main()
{
   int  Base,Altura,areaTriangulo;
        printf("Introduce la base del triangulo \n",Base);
        scanf("%d",&Base);
        printf("Introduce la altura del triangulo \n",Altura);
        scanf("%d",&Altura);
        areaTriangulo=(Base*Altura)/2;
        printf("El area del triangulo es %d\n",areaTriangulo);
    return 0;
}
