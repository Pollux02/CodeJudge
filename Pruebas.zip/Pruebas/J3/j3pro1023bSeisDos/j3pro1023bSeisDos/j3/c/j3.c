#include <stdio.h>
#include <stdlib.h>

int main()
{
printf("Area del triangulo con valores pedidos por el usuario:D\n\n");
    printf("***************************************************************************************\n\n");

    int base;
    int altura;

        printf("Favor de poner la base:");
        scanf ("%d", &base);
        printf("Favor de poner la altura:");
        scanf ("%d", &altura);

    int areaTriangulo = (base * altura)/2;

        printf("\nArea del triangulo\n");
        printf("Valor de areaTriangulo: %d\n\n", areaTriangulo);

    printf("***************************************************************************************\n\n");
return 0;
}
