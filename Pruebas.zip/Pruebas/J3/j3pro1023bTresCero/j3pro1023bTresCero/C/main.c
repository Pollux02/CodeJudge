#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base,altura,areaTriangulo;
    printf("Ingrese un valor para la base del triangulo: ");
    scanf("%d",&base);
    printf("\nIngrese un valor para la altura del triangulo: ");
    scanf("%d",&altura);
    areaTriangulo=base*altura/2;
    printf("\nEl area de tu triangulo es: %d",areaTriangulo);
    return 0;
}
