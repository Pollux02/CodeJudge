#include <stdio.h>
#include <stdlib.h>

int main()
{
    int areaTriangulo,base,altura;
    printf("Dame el valor de la base de tu triangulo: ");
    scanf("%d",&base);
    printf("Dame el valor de la altura de tu triangulo: ");
    scanf("%d",&altura);
    areaTriangulo= base*altura/2;

    printf("el area de nuestro triangulo es de: %d\n",areaTriangulo);
    return 0;
}
