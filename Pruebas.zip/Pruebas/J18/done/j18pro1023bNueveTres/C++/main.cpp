//nickname=NueveTres
//No.practica=j18
//Tiempo=00:25

#define CANTIDAD_VALORES 3

#include <iostream>

using namespace std;

int main()
{   int valores[CANTIDAD_VALORES];

    cout << "Ingrese 3 valores diferentes: " << endl;
    cin  >>valores[0];
    cin  >>valores[1];
    cin  >>valores[2];

    if (valores[0]<valores[1] && valores[1]<valores[2]){
        cout <<endl<<"estan en orden creciente"<<endl;
    } else{
        cout <<"no estan en orden creciente"<<endl;
    }


    return 0;
}
