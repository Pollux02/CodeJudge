#include <stdio.h>
#include <stdlib.h>
#define porciento 100
#define asistenciasMaximas 34

//DosSeis
//Ejercicio 12
//Tiempo = 00:27

int main()
{   int asistenciasUsuario, porcentajeAsistencias;
    printf("Escriba el total de veces que asistio: ");
    scanf("%d", &asistenciasUsuario);
    porcentajeAsistencias=asistenciasUsuario*porciento/asistenciasMaximas;
    printf("\n\nSu porcentaje de asistencias es de: %d%% \n\n", porcentajeAsistencias);
    return 0;
}
