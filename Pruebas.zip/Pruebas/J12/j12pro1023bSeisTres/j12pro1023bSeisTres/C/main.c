#include <stdio.h>
const int MAXIMO_ASISTENCIAS = 34;
int main() {
  	printf("Ingrese la cantidad de faltas del alumno: ");
    int faltas;
    scanf("%d", &faltas);
    float porcentaje = ((float)(MAXIMO_ASISTENCIAS - faltas) / MAXIMO_ASISTENCIAS) * 100;
    printf("El porcentaje de asistencias del alumno es: %.2f%%\n", porcentaje);
    return 0;
}
