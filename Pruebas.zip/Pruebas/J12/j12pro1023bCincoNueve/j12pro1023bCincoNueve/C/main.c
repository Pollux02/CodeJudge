/* CincoNueve, j12pro1023b, Tiempo = 01:45 */

#include <stdio.h>
#include <stdlib.h>

const int MAXIMO_ASISTENCIAS     = 34;
const int PORCENTAJE_ASISTENCIAS = 100;


int main()
{
    int numeroFaltas, numeroAsistencias ;
    float porcentaje;
    printf(" *** CALCULADORA DE ASISTENCIAS ***\n\n");
    printf("Ingrese su numero de faltas: ");
    scanf("%d", &numeroFaltas);
    numeroAsistencias = MAXIMO_ASISTENCIAS - numeroFaltas;
    porcentaje = (float) (numeroAsistencias) / MAXIMO_ASISTENCIAS * PORCENTAJE_ASISTENCIAS;
    printf("\n\n *** Datos de las asistencias *** \n\n");
    printf("Maximo de asistencias    :   %d\n", MAXIMO_ASISTENCIAS);
    printf("Numero de faltas         :   %d\n", numeroFaltas);
    printf("Numero de asistencias    :   %d\n", numeroAsistencias);
    printf("Porcetaje de asistencias :   %.2f%%\n", porcentaje);
    return 0;
}
