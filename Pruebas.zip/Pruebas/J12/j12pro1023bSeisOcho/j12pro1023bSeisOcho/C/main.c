/*Autor: SeisOcho
Ejercicio 12: Calculadora de porcentaje de asistencias
Tiempo de elaboraci�n = 00:18
*/
#include <stdio.h>
#include <stdlib.h>
#define MAXIMO_ASISTENCIAS 34
#define TOTAL 100
int main(){
    int faltas;
    float porcentaje;
    printf("---Calculadora de porcentaje de asistencias---\n\n");
    printf("Ingrese la cantidad de faltas: ");
    scanf("%d", &faltas);

    if(faltas < 0 || faltas > MAXIMO_ASISTENCIAS){
        printf("\nCantidad invalida. Intente de nuevo.\n");
    }else{
        porcentaje =  (float)(MAXIMO_ASISTENCIAS - faltas) * TOTAL/MAXIMO_ASISTENCIAS;
        printf("\nTeniendo %d faltas en %d asitencias\n", faltas, MAXIMO_ASISTENCIAS);
        printf("Su porcentaje de asistencias fue de: %.2f\%%\n",porcentaje);
    }

    return 0;
}
