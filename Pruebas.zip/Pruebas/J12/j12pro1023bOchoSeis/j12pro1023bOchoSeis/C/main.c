// OchoSeis Ejercicio 12; "Tiempo=00:34"

#include<stdio.h>

int main(){
	const int ASISTENCIA = 34, PORCENTAJE = 100;
	int faltas;
	float porcentajeAsistencia;
	
	printf("\t---Bienvenido---\n");
	printf("El numero de faltas debe estar entre '0' y '34'\n");
	
	printf("Ingrese sus faltas para calcular el porcentaje de su asistencia: ");
	scanf("%d",&faltas);
	
	if(faltas >= 0 && faltas <= 34){
		faltas = ASISTENCIA - faltas;
		porcentajeAsistencia = (faltas / (float)ASISTENCIA) * PORCENTAJE;
	
		printf("\nEl porcentajes de sus asistencias es: %.2f%%\n", porcentajeAsistencia);
	}
	else{
		printf("\nDato invalido\n");
	}
	return 0;
}
