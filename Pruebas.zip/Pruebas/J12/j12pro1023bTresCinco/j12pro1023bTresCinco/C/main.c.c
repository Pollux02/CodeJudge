#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int MAXIMO_ASISTENCIAS = 34 , Max_Porcentaje = 100;
    int faltas;
    float porcentaje;

    printf("===============================================\n");
    printf("\nCalculador de porcentaje de asistencias\n\n");
    printf("===============================================\n");
    printf("\nIngresa tu numero de faltas: ");
    scanf("%d",&faltas);

    porcentaje=(float)(faltas*Max_Porcentaje)/MAXIMO_ASISTENCIAS;

    printf("\nPorcentaje de faltas:%f\n",porcentaje);


    return 0;
}
