/*  nickname : SeisSiete
    ejercicio 12
*/
#include <stdio.h>
#include <stdlib.h>
#define MAXIMO_ASISTENCIAS 34
const int C_100 = 100;

int main()
{
    int faltasClase;
    float asistenciasClase;

    printf("Cuantas veces has faltado a clases? ");
    scanf ("%d", &faltasClase);

    asistenciasClase = (float)(MAXIMO_ASISTENCIAS - faltasClase)*C_100/MAXIMO_ASISTENCIAS;
    printf ("\n El porcentaje de tus asistencias es de: %% %.2f \n",asistenciasClase);

    return 0;
}
