// SeisDos // j12pro2023b //Time= 2:00

#include <stdio.h>

const int MAXIMO_ASISTENCIAS = 34;
const int VALOR_ASISTENCIAS = 100;

int main()
{
    int faltas;
    int asistencias;
    float porcentaje;

    printf("***CALCULADORA DE ASISTENCIAS*** ");
    printf("\nIngrese la cantidad de faltas: ");
    scanf("%d", &faltas);
    asistencias = MAXIMO_ASISTENCIAS - faltas;
    porcentaje = (float)asistencias / MAXIMO_ASISTENCIAS * VALOR_ASISTENCIAS;

    printf("\n\n***DATOS***");
    printf("\nNumero de faltas:                   %d\n", faltas);
    printf("Numero de asistencias:              %d\n", asistencias);
    printf("Porcentaje de asistencias:          %.2f\n", porcentaje);

    return 0;
}
