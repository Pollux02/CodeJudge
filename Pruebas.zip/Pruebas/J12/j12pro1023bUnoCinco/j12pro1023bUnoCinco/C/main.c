#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int ASISTENCIAS_MAX = 34;
    float porcentaje_de_asistencia;
    printf("Teclea cuantas veces faltaste en el semestre: \n");
    scanf("%f",&porcentaje_de_asistencia);
    porcentaje_de_asistencia=((ASISTENCIAS_MAX-porcentaje_de_asistencia)/ASISTENCIAS_MAX*100);
    printf("Tus asistencias en el semestre son: %.2f%% ",porcentaje_de_asistencia);

    return 0;
}
