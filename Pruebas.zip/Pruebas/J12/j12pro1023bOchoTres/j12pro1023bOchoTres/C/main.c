#include <stdio.h>
#include <stdlib.h>
#define MAXIMO_ASISTENCIAS 34
#define PORCENTAJE_MAXIMO 100

//OchoTres
//j12pro1023b
//Time=3:57000




 main()
{
    int numeroFaltas;
    float porcentaje;
    printf("Calcule el porcentaje de asistencias\n\n");
    printf("Ingresa el numero de faltas:");
    scanf("%d",&numeroFaltas);
    porcentaje=(float)(MAXIMO_ASISTENCIAS-numeroFaltas)*PORCENTAJE_MAXIMO/MAXIMO_ASISTENCIAS;
    printf("El porcentaje de asistencia es de: %.2f %%",porcentaje);
    return 0;
}
