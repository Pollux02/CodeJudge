#include <stdio.h>
#include <stdlib.h>
//UnoUno
//tiempo 00/25
int main()
{
    printf("Calculo de faltas a clase:\n\n\n");
    const int  MAXIMO_ASISTENCIAS = 34,Puntaje_Maximo=100;
    int Total_Fal;
    float Porsentaje_Asi;
    printf("Dame el total de faltas:");
    scanf("%d",&Total_Fal);
    printf("\n\n");

    Total_Fal=MAXIMO_ASISTENCIAS-Total_Fal;
    Porsentaje_Asi=(float)(Total_Fal*Puntaje_Maximo)/MAXIMO_ASISTENCIAS;

    printf("Tu porsentaje de asistencias es : %.3f\n\n",Porsentaje_Asi);
    return 0;
}
