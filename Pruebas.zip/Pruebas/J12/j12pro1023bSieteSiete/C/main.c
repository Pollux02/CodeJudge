//SieteSiete EjercicioJ12 8 minutos

#include<stdio.h>
#define MAXIMO_ASISTENCIAS 34
#define CERO 0

int main() {
    int cantidadFaltas = CERO;
    float porcentajeAsistencias;
    
    printf("Ingrese la cantidad de asistencias: ");
    scanf("%i", &cantidadFaltas);
    
    porcentajeAsistencias = ((float)(MAXIMO_ASISTENCIAS - cantidadFaltas) / MAXIMO_ASISTENCIAS) * 100.0;
    
    printf("El porcentaje de asistencias es de %.2f%%\n", porcentajeAsistencias);

    return 0;
}



