//DosUno, j12pro1023b, Tiempo=15:00


#include <stdio.h>
#include <stdlib.h>

#define MAXIMO_ASISTENCIAS 34
#define PORCENTAJE_MAXIMO 100


int main()
{
    int faltas;
    float calculoPorcentaje;
    printf("CALCULO DE ASISTENCIAS");
    printf("�Cuantas faltas a tenido? ");
    scanf("%d",&faltas);
    calculoPorcentaje=(float)(MAXIMO_ASISTENCIAS-faltas)*PORCENTAJE_MAXIMO/MAXIMO_ASISTENCIAS;
    printf("Su porcentaje de faltas es: %.2f %%", calculoPorcentaje);
    return 0;
}
