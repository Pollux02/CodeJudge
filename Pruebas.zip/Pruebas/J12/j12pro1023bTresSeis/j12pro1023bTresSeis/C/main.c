#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int MAXIMO_ASISTENCIAS=34;
    int ASISTENCIAS;
    float PORCENTAJE;

    printf("ASISTENCIAS\n\n");
    printf("Ingrese cuantas asistencias tiene: ");
    scanf("%d",&ASISTENCIAS);

    PORCENTAJE= (100*ASISTENCIAS)/MAXIMO_ASISTENCIAS;

    printf("Maximo de asistencias: %d\n",MAXIMO_ASISTENCIAS);
    printf("Tus asistencias: %d\n",ASISTENCIAS);
    printf("Porcentaje de tus asistencias: %f\n",PORCENTAJE);


    return 0;
}
