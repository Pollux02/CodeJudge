#include<stdio.h>
#include<stdlib.h>
#define MAXIMO_ASISTENCIAS 34
#define CIEN 100
int main(){
    int faltas;
    float asistencias;
    printf("cantidad de faltas: ");
    scanf("%d",&faltas);
    asistencias=(float)faltas*CIEN/MAXIMO_ASISTENCIAS;
    printf("tiene el %.3f %% de asistencias",asistencias);
    return 0;
}
