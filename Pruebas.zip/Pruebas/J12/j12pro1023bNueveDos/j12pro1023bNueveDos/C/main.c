#include <stdio.h>
#include <stdlib.h>

const int MAXIMO_ASISTENCIAS = 34;

int main()
{
    int faltas;
    float porcentaje_asistencias;

    printf("***Porcentaje de asistencias***\n");
    printf("\nIngrese cantidad de faltas = ");
    scanf("%d", &faltas);

    porcentaje_asistencias = 100 * faltas / MAXIMO_ASISTENCIAS;

    printf("\nPorcentaje de asistencias del alumno = %.2f%%\n", porcentaje_asistencias);

    return 0;
}
