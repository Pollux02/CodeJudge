/* CuatroNueve,j12pro1023b,Tempo=01:00*/
#include <stdio.h>
#include <stdlib.h>
#define MAXIMO_ASISTENCIAS 34
int main()
{
    int faltas,asistencia;
    float promedioAsistencia;
    printf("Escriba la cantidad de faltas del alumno: ");
    scanf("%d",&faltas);
    asistencia=MAXIMO_ASISTENCIAS-faltas;
    promedioAsistencia=(float)(asistencia)/MAXIMO_ASISTENCIAS*100;
    printf("\nEl promedio de la asistencia es: %f\n",promedioAsistencia);

    return 0;
}
