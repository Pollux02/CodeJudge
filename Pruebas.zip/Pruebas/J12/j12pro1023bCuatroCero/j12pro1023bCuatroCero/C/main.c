/*
NickName=CuatroCero
Practica=j12
Tiempo=00:14
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX_ASISTENCIAS 34
#define C_100 100

int main() {
    int faltas;
    float porcentajeAsistencias;

    printf("Ingrese la cantidad de faltas: ");
    scanf("%d", &faltas);

    porcentajeAsistencias = ((float)(MAX_ASISTENCIAS - faltas) / MAX_ASISTENCIAS) * C_100;

    printf("Porcentaje de asistencias: %.2f%%\n", porcentajeAsistencias);

    return 0;
}
