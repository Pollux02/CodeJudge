//TresCero
//j12 EJERCICIOS PRO
//Tiempo = 00:35
#include <stdio.h>
#include <stdlib.h>
#define CLEAR cls
#define MAXIMO_ASISTENCIAS 34
#define C_100 100

int main()
{
    int faltas;
    float porcentajeAsistencias;
    printf("---Porcentaje de asistencias---\n\n");
    printf("Ingresa el numero de faltas que tuviste: ");
    scanf("%d",&faltas);

    porcentajeAsistencias = (float)faltas*C_100/MAXIMO_ASISTENCIAS;
    system("cls");

    printf("---Porcentaje de asistencias---\n\n");
    printf("Tu porcentaje de asistencias es %f %%",porcentajeAsistencias);
    return 0;
}
