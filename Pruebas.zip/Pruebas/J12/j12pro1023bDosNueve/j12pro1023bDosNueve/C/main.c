#include <stdio.h>
#include <stdlib.h>



int main() {
    const int MAXIMO_ASISTENCIAS = 34;
    int faltas;

    printf("Calculando las faltas de un alumno i/rresponsable =)\n\n");
    printf("Ingrese la cantidad de faltas: ");
    scanf("%d", &faltas);

    double porcentaje = ((double)(MAXIMO_ASISTENCIAS - faltas) / MAXIMO_ASISTENCIAS) * 100.0;

    printf("El porcentaje de asistencias es: %.2lf%%\n\n", porcentaje);
    printf("No faltes y ve a tus clases!\n");

    return 0;
}
