#include<stdio.h>

int main(){
    const int MAXIMO_ASISTENCIAS=34;
    int asistencias;
    float porcentaje_asistencia;
    printf("Ingresa las asistencias:");scanf("%d",&asistencias);
    porcentaje_asistencia=(100*asistencias)/MAXIMO_ASISTENCIAS;
    printf("\nEL porcentaje de las asitecias es :%.2f%%\n",porcentaje_asistencia);
    return 0;
}