//Nickname: NueveTres
//Titulo: Calcular porcentaje de faltas
//Tiempo: Tiempo=00:40
#include <stdio.h>
#include <stdlib.h>
#define MAXIMO_ASISTENCIA 34
#define N_100 100

int main()
{
    int falta;
    float Porcentaje_Falta, Porcentaje_Asistencia;
    printf("*****Programa para calcular faltas*****\n\n");
    printf("Cuantas veces faltaste? ");
    scanf("%d", &falta);

    Porcentaje_Falta=(float)falta*N_100/MAXIMO_ASISTENCIA;
    Porcentaje_Asistencia=N_100-Porcentaje_Falta;

    printf("\n\nEl porcentaje de asistencias es:    %f", Porcentaje_Asistencia);
    printf("\nEl porcentaje de faltas es:         %f\n\n\n\n\n", Porcentaje_Falta);
    return 0;
}
