#include <stdio.h>
#include <stdlib.h>

int main(){
    float areaCirculo, radio;
    const float PI = 3.1416;
    printf("Area de un circulo\n\n");
    printf("Por favor, ingrese el radio: ");
    scanf("%f", &radio);
    areaCirculo = PI * (radio*radio);
    printf("Area del circulo: %.2f\n", areaCirculo);
    return 0;
}
