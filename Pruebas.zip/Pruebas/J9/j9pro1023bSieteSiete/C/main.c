//sietesiete
#include <stdio.h>

int main()
{
    float areaCirculo, radio;
    const float PI = 3.1416;
    printf("Ingrese el valor del radio");
    scanf("%f", &radio);
    
    areaCirculo = PI*radio*radio;
    
    printf("El area del circulo es %f", areaCirculo);
    
    return 0;
}
