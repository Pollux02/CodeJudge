#include <stdio.h>
#include <stdlib.h>

int main()
{
    const float PI=3.14;
    float areaCirculo, radio;
    printf("Ingrese el radio del circulo: ");
    scanf("%f",&radio);

    areaCirculo= PI*radio*radio;
    printf("\nEl area del circulo es: %f",areaCirculo);

    return 0;
}
