#include <stdio.h>
#include <stdlib.h>

int main()
{
printf("Area del ciruclo con datos definidos :D\n\n");
    printf("***************************************************************************************\n\n");

    float radio;
    const float pi= 3.1416;


        printf("Valor de radio:");
        scanf("%f", &radio);
        printf("Valor de pi: %f\n\n", pi);

        float areaCirulo= pi*(radio*radio);

        printf("Area del circulo:\n");
        printf("Valor de areaCirculo: %f\n\n", areaCirulo);

    printf("***************************************************************************************\n\n");
return 0;
}
