#include <stdio.h>
#include <stdlib.h>

const float PI = 3.1416;

int main()
{
    float areaCirculo, radio;

    printf("Calculo de area de cirulos mediante valores flotantes o numeros reales\n");
    printf ("*************************************************************************\n\n");
    //ENTRADA Y SALIDA DE INFORMACION
    printf ("Dame el valor de radio: ");
    scanf ("%f", &radio);
    //COMPUTOS
    areaCirculo= PI * radio * radio;
    // SALIDA DE DATOS
    printf ("\n\n El valor del area del ciculo es : %.2f \n", areaCirculo);
    printf ("Radio = %.2f \n", radio);
    printf ("PI = %.4f \n", PI);

    return 0;
}
