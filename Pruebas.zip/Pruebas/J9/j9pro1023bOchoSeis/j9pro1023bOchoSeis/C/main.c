#include<stdio.h>
#include<math.h>

int main(){
	float areaCirculo, radio, pi;

	printf("Calcular el area de un circulo.\n\n");
	printf("Ingrese el radio de un circulo: ");
	scanf("%f",&radio);

	pi = 3.1416;
	areaCirculo = pi * (pow(radio, 2));

	printf("\nArea del circulo: %f\n",areaCirculo);
	printf("Radio del circulo: %f\n",radio);
	printf("Valor de 'pi': %f\n\n",pi);

	return 0;
}
