#include <stdio.h>
#include <stdlib.h>
const float PI = 3.1416;
int main(){
	float areaCirculo, radio;
	printf("radio del curculo: ");
	scanf("%f",&radio);
	areaCirculo=radio*radio*PI;
	printf("radio: %f\n",radio);
	printf("area del circulo: %f",areaCirculo);
}
