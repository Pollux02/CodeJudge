#include <stdio.h>
#include <stdlib.h>

int main()
{
    const float PI=3.1416;
    float areaCirculo,radio;
    printf("Calculo de area de circulo\n");
    printf("Dame el radio\n");
    scanf("%f",&radio);
    areaCirculo=PI*radio*radio;
    printf("El resultado del circulo es: \n");
    printf("area=%f\n",areaCirculo);

    return 0;
}
