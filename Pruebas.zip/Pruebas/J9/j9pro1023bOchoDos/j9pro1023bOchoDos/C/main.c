#include<stdio.h>
#include<math.h>



int main(){
    const float Pi =3.1416;
    
    int areaCiculo,radio;
    printf("Ingrese el radio del circulo: ");
    scanf("%d",&radio);

    areaCiculo=Pi*sqrt(radio);
    printf("El area del circulo es : %d\n",areaCiculo);

    return 0;
}