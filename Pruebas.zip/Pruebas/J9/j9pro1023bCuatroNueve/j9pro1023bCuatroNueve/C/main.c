#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areaCirculo,radio;
    const float PI=3.1416;
    printf("Dame la medida del radio: ");
    scanf("%f",&radio);
    areaCirculo=PI*radio*radio;
    printf("\nEl area del circulo es: %f",areaCirculo);
    return 0;
}
