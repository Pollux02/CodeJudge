#include <stdio.h>
#include <stdlib.h>

int main()
{
    const float pi=3.1416;
    float areaCirculo,radio;

    printf("Calculo del area de un circulo\n\n");
    printf("Dame el valor de tu radio: ");
    scanf("%f",&radio);

    areaCirculo=pi*(radio*radio);

    printf("\nEl valor de pi tomado en cuenta es:%f\n",pi);
    printf("Su area es=:%f\n",areaCirculo);
    return 0;
}
