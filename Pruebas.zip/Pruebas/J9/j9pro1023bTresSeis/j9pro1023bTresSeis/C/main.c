#include <stdio.h>
#include <stdlib.h>

int main()
{
    float areacirculo, radio;
    const float PI=3.1416;

    printf("Calcular el area de un ciculo \n\n");
    printf("Dame el valor del radio \n");
    scanf("%f",&radio);

    areacirculo=PI*(radio*radio);

    printf("Radio: %f\n", radio);
    printf("PI: %f\n", PI);
    printf("Area del ciruclo: %f\n", areacirculo);


    return 0;
}
