#include <stdio.h>
#include <stdlib.h>
const float pi = 3.1416;

int main()
{   
    float radio,Area;
    printf("Calcular el area de un circulo:\n");
    printf("Ingrese el radio del circulo: ");
    scanf("%f",&radio);
    Area= pi*(radio*radio);
    printf("El radio del circulo es: %.2f\n",radio);
    printf("El area del circulo es: %.2f\n",Area);
    return 0;
}
