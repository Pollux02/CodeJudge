#include <stdio.h>
#include <stdlib.h>

int main()
{
    float radio, areaCirculo;
    const float PI = 3.1416;

    printf("Ingrese el radio del circulo: ");
    scanf("%f", &radio);

    areaCirculo = PI * radio * radio;

    printf("\nEl area del circulo con radio %.2f es %.2f\n", radio, areaCirculo);

    return 0;
}
