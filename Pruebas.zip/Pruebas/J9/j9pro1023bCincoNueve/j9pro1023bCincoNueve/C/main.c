#include <stdio.h>
#include <stdlib.h>

int main()
{
    const float PI = 3.1416;
    float areaCirculo, radio;
    printf("Calculando el area de un circulo\n\n");
    printf("Ingrese el valor para el radio: ");
    scanf("%f", &radio);
    areaCirculo = PI*radio*radio;
    printf("\n\nValores del circulo:\n\n");
    printf("RADIO = %.4f\n",radio);
    printf("PI    = %.4f\n",PI);
    printf("AREA  = %.4f\n",areaCirculo);
    return 0;
}
