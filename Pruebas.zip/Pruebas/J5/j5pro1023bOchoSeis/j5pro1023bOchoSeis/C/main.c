/* Implemente un programa que calcule el �rea de un c�rculo usando
variables float nombradas "a", "r" y "pi".
Imprimir los valores de cada variable en el orden descrito.
No es necesario solicitar datos al usuario. */

#include<stdio.h>
#include<math.h>

int main(){
	float a, r, pi;
	
	printf("Calcular el area de un circulo.\n");
	
	r = 5;
	pi = 3.1416;
	a = pi * (pow(r, 2));
	
	printf("Area del circulo: %f\n",a);
	printf("Radio del circulo: %f\n",r);
	printf("Valor de 'pi': %f\n\n",pi);
	
	return 0;
}
