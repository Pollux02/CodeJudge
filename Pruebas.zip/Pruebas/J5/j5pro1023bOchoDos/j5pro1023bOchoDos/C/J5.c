#include<stdio.h>
#include<math.h>
int main(){
    float a,r,pi;
    pi=3.1416;
    r=5;
    a=pi*sqrt(r);
    printf("EL area del el circulo es:%f\n",a);
    printf("r=%f\n",r);
    printf("pi=%f\n",pi);




    return 0;
}