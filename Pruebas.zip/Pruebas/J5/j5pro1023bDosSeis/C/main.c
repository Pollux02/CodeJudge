#include <stdio.h>
#include <stdlib.h>

int main()
{
    float r,a,pi;
    printf("Ingrese el valor del radio: ");
    scanf("%f",&r);
    pi=3.1416;
    a=pi*r*r;
    printf("\n\nEl area de tu circulo es de: %f\n\n",a);
    return 0;
}
