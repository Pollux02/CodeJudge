#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,r,pi;

    r=5;
    pi=3.1416;
    a=pi*(r*r);
    printf("area del circulo: %f\n",a);
    printf("Radio: %f\n",r);
    printf("pi: %f\n",pi);

    return 0;
}
