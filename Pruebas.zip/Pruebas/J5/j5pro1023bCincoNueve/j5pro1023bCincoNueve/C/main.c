#include <stdio.h>
#include <stdlib.h>


int main()
{
    float a,r,pi;
    r=34;
    pi=3.1416;
    a=pi*r*r;
    printf("Datos del circulo:\n\n");
    printf("AREA  = %3.4f\n",a);
    printf("RADIO = %3.4f\n",r);
    printf("PI    = %3.4f\n",pi);
    return 0;
}
