#include <stdio.h>
#include <stdlib.h>

int main()
{
    float r,pi,a;
    printf("Calcular el area de un circulo \n\n");

    r=8;
    pi=3.1416;
    a=pi*(r*r);

    printf("El radio del circulo es: %f\n",r);
    printf("Pi equivale a: %f\n\n",pi);
    printf("El area es: %f",a);
    return 0;
}
