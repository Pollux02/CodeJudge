#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("Calcular el area de un circulo.\n");
    float a, r, pi;
    r = 25.45;
    pi = 3.14159;
    a = pi * (r * r);

    printf("Radio: %.2f\n\n", r);

    printf("Área: %.4f\n", a);

    return 0;
}
