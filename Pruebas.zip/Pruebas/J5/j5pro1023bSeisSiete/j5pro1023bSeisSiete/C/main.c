#include <stdio.h>
#include <stdlib.h>

int main()
{
    //DECLARACION DE VARIABLES
    float a,r,pi;
    r=5.5;
    pi=3.1416;
    a= pi*r*r;
    printf("PROGRAMA PARA CALCULAR EL AREA DE UN CIRCULO\n\n");
    printf ("El area del circulo es: %.2f\n\n",a);
    //MOSTRAR LAS VALORES UTILIZADOS PARA CADA VARIABLE
    printf ("r=%.2f \n",r);
    printf ("pi=%.2f \n",pi);

    return 0;
}
