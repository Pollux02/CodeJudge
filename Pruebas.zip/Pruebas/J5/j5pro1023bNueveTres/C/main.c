#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a, r=3, pi=3.1416;
    a=(r*r)*pi;
    printf("Los datos recaudados son:\n(a)AREA: %f\n(r)RADIO: %f\n(pi)PI: %f", a, r, pi);
    return 0;
}
