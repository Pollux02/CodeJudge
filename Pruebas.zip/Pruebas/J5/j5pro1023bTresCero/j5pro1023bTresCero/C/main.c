#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("-Calcular el area de un circulo-\n\n");
    float a,r,pi;
    r=5.5;
    pi=3.1416;
    a=r*r*pi;
    printf("El area total del circulo es: %.4f\n",a);
    printf("El radio del circulo es: %.1f\n",r);
    printf("El valor de pi es: %.4f",pi);

    return 0;
}
