#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Area de un circulo\n\n");
    float a,r,pi;
    r=25;
    pi=3.1416;
    a=pi*r;
    printf("El area del circulo es:\na=%f\n\n",a);
    printf("r=%f\n\n",r);
    printf("pi=%f\n\n",pi);
    return 0;
}
