#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,r,pi;
    r=10;
    pi=3.14;
    a=pi*r*r;
    printf("Pi= %f\n",pi);
    printf("r= %f\n",r);
    printf("a= %f\n",a);

    return 0;
}
