#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,r,pi;
    r=12.99;
    pi=3.1416;
    a=pi*r*r;
    printf("El valor de a es:%.4f\n\n",a);
    printf("El valor de r es:%.2f\n",r);
    printf("El valor de pi es:%.4f\n",pi);
    return 0;
}
