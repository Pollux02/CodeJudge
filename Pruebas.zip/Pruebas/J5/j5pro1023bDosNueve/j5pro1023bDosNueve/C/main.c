#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,r,pi;
    r=5.0;
    pi=3.1416;
    printf("Calculando el area de un ciculo =)\n");
    a=pi*r*r;
    printf("El valor de 'pi' es: %.4f\n", pi);
    printf("El valor del radio 'r' es: %.1f\n", r);
    printf("El �rea del c�rculo 'a' es: %.6f\n", a);

    return 0;
}
