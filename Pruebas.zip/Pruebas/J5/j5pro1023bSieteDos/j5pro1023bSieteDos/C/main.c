#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a, r, pi;

    r = 42;
    pi = 3.1415;

    a = (r*r)*pi;

    printf("El area es : %f \n", a);
    printf("El valor del radio es : %f \n", r);
    printf("El valor de pi es igual a : %f \n", pi);

    return 0;
}
