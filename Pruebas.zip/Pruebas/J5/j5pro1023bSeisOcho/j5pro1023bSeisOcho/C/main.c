#include <stdio.h>
#include <stdlib.h>

int main(){
    float a, r, pi;
    r = 8;
    pi = 3.1416;
    a = pi * (r*2);
    printf("Area del circulo: %.2f\n", a);
    printf("Radio del circulo: %.2f\n", r);
    printf("Pi: %.4f\n", pi);
}
