#include <stdio.h>
#include <stdlib.h>

int main()
{
   float a,r,pi;
   r=5;
   pi=3.1416;
   a= pi*r*r;
   printf("el valor de la area es:%f\n",a);
    return 0;
}
