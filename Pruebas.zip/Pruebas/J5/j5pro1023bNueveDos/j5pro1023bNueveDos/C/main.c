#include <stdio.h>
#include <stdlib.h>

int main()
{
    float r, pi, a;
    r = 14;
    pi = 3.1416;
    a = pi * r * r;
    printf("Area de un circulo\n");
    printf("a = %f * %f ** 2 = %f\n", pi, r, a);
    printf("pi = %f\n", pi);
    printf("r = %f", r);
    return 0;
}
