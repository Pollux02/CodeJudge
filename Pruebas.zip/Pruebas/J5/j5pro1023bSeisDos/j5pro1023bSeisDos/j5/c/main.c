#include <stdio.h>
#include <stdlib.h>

int main()
{
printf("Area del ciruclo con datos definidos :D\n\n");
    printf("***************************************************************************************\n\n");

    float r= 10;
    float pi= 3.1416;
    float a= pi*(r*r);

        printf("Valor de r: %f\n", r);
        printf("Valor de pi: %f\n\n", pi);
        printf("Area del circulo:\n");
        printf("Valor de a: %f\n\n", a);

    printf("***************************************************************************************\n\n");
return 0;
}
