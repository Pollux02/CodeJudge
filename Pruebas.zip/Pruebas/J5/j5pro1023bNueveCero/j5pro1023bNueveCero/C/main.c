#include <stdio.h>
#include <stdlib.h>
int main(){
    float a,r,pi;
    pi=3.1416;
    r=5;
    a=r*r*pi;
    printf("pi: %f\n",pi);
    printf("r: %f\n",r);
    printf("a: %f\n",a);
    return 0;
}
