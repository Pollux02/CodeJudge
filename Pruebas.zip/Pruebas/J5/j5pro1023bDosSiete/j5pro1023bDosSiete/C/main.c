#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,r,pi;
    r= 2.8;
    pi= 3.1416;
    a= pi*r*r;
    printf("El area del circulo es: %.2f\n",a);
    printf("El radio es: %f\n",r);
    printf("Valor de pi: %f\n",pi);
    return 0;
}
