#include<iostream>

using namespace std;

int main(){
    float f,celsius1,celsius2,paso1,paso2,comparasion;
    
    cout<<"Dame le valor de grados en Fahrenheit: ";cin>>f;
    paso1=(f-32)/2;
    paso2=paso1/10;
    
    celsius1=paso1+paso2;

    celsius2=(5*(f-32))/9;

    comparasion=celsius1-celsius2;

    cout<<"Fahrenheit:"<<f<<"\n";
    cout<<"Metodo1:"<<celsius1<<"\n";
    cout<<"Metodo2:"<<celsius2<<"\n";
    cout<<"Diferencia:"<<comparasion<<"\n";

    return 0;
}