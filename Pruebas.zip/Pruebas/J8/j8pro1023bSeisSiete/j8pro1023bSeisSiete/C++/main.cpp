#include <iostream>

using namespace std;

const int C_32 = 32;
const int C_M1_2 = 2;
const int C_M1_10 = 10;
const float C_M2_1punto8 = 1.8;


int main()
{
    float fahrenheit, celsiusM1, celsiusM1_2,celsiusM2, diferencia;
    //DATOS A MOSTRAR EN PANTALLA Y DATOS DE ENTREDA A SOLICITAR
    cout << "CONVERSIONES DE GRADOS FAHRENHEIT A CELSIUS MEDIANTE DOS METODOS" << endl;
    cout << "Primer metodo." << endl;
    cout << "Dame el valor numerico de los grados fahrenheit a convertir:" << endl;
    //COMPUTOS
    cin >> fahrenheit;
    celsiusM1 = (fahrenheit-C_32)/C_M1_2;
    celsiusM1_2=celsiusM1;
    celsiusM1 = celsiusM1_2/C_M1_10;
    celsiusM1_2= celsiusM1_2+celsiusM1;
    //SALIDA DE DATOS
    cout << "El valor en celsius de "<< fahrenheit <<" F por metodo 1 es:" << celsiusM1_2 <<" C"<< endl;
    cout << "Segundo metodo." << endl;
    celsiusM2=(fahrenheit-C_32)/C_M2_1punto8;
    diferencia = celsiusM1_2-celsiusM2;
    cout << "El valor en celsius de " << fahrenheit << "F por metodo 2 es:" << celsiusM2 << " C"<< endl;
    cout << "La diferencia de resultado entre el primer metodo y el segundo es de " << diferencia<< endl;


    return 0;
}
