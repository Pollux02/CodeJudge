//David Leonardo Flores Moreno

#include<iostream>

using namespace std;

int main(){
    float Fahrenheit, CelsiusAprox,CelsiusExacto,entreDies;
    cout<<"Escribe una cantidad de grados Fahrenheit"<<endl;
    cin>>Fahrenheit;
    cout<<"El valor a convertir es "<<Fahrenheit<<endl;
    CelsiusAprox = Fahrenheit-32;
    CelsiusAprox = CelsiusAprox/2;
    entreDies = CelsiusAprox/10;
    CelsiusAprox += entreDies;
    CelsiusExacto = (5.0/9.0)*(Fahrenheit-32);
    cout<<"La conversion con el metodo aproximado es "<< CelsiusAprox<<endl;
    cout<<"La conversion exacta es de "<< CelsiusExacto;
    
    
    
    
}