#include <iostream>

using namespace std;

int main()
{
    float f,c;
    cout << "Metodo 1" << endl ;
    cout << "Conversion de Fahrenheit a Celcius" << endl;
    cout << "Ingrese los grados Fahrenheit: ";
    cin >> f;
    c = f-32;
    c = c/2;
    c = c+c/10;

    cout << endl << "Grados  Fahrenheit a convertir: " <<f <<endl;
    cout << "Grados Celcius convertidos: " <<c <<endl << endl;
    cout <<"================================================" <<endl << endl ;

    cout << "Metodo 2" ;
    cout << endl << "Conversion de Fahrenheit a Celcius" << endl;
    cout << "Ingrese los grados Fahrenheit: ";
    cin >> f;
    c = (f-32)/1.8;
    cout << endl << "Grados  Fahrenheit a convertir: " <<f <<endl;
    cout << "Grados Celcius convertidos: " <<c << endl << endl;
    cout <<"================================================" ;
    return 0;
}
