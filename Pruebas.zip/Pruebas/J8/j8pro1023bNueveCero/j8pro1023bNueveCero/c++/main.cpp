#include<iostream>
using namespace std;
int main(){
    float Fahrenheit,celcius,dif,celcius2;
    cout<<"Fahrenheit: ";
    cin>>Fahrenheit;
    celcius=(Fahrenheit-32)/2;
    celcius=celcius+celcius/10;
    celcius2=(Fahrenheit-32)/1.8;
    dif=celcius-celcius2;
    cout<<"Fahrenheit: "<<Fahrenheit<<endl;
    cout<<celcius<<" - "<<celcius2<<" = "<<dif<<endl;
    return 0;
}
