#include <iostream>

using namespace std;

int main()
{
    cout << "Programa creado para la combercion de grados de dos formas diferentes" << endl<<endl<<endl;
    float gradosFahrenheit,gradosCelsius,variable1,variable2,diferencia;
    cout <<"Dame los grados Fahrenheit:";
    cin >>gradosFahrenheit;
    variable1=(gradosFahrenheit-32);
    variable1=variable1/2;
    variable2=variable1/10;
    gradosCelsius=variable2+variable1;
    gradosFahrenheit=(gradosFahrenheit-32)/1.8;
    diferencia=gradosCelsius-gradosFahrenheit;
    cout <<endl<<endl<<"De la primera forma el resultado es: "<<gradosCelsius;
    cout <<endl<<"De la segunda forma el resultado es: "<<gradosFahrenheit;
    cout <<endl<<endl<<"la diferencia de un metodo a otro es: "<<diferencia;
    cout <<endl<<endl;
    return 0;
}
