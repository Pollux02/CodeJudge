#include <iostream>

using namespace std;

int main()
{
    cout <<"Conversion de grados Celsius a Fahrenheit :D\n"<< endl;
    cout <<"***************************************************************************************\n"
    << endl;

    int F;

        cout <<"Ingrese los Fahrenheit que desea convertir a Celsius: ";
        cin >> F;

    float Caprox;
    float division;
    float division2;
    float resultado;
        Caprox= F-32;
        division= Caprox/2;
        division2= division/10;
        resultado= division+division2;

    float Cexacto;
    float multi;
    float resultado2;
        Cexacto= F-32;
        multi= 5*Cexacto;
        resultado2= multi/9;

    float resultadoExacto;
        resultadoExacto= resultado-resultado2;

        cout <<"\nEl valor que ingreso fue "<< F <<" Fahrenheit \n"<< endl;
        cout <<"\nEl valor aproximado de "<< F <<" Fahrenheit a Celsius es: "<<resultado<<"\n"<<endl;
        cout <<"\nEl valor exacto de "<< F <<" Fahrenheit a Celsius es: "<<resultado2<<"\n"<<endl;
        cout <<"\nLa diferencia de ambos resultados es de: "<<resultadoExacto<<"\n"<<endl;



    cout <<"***************************************************************************************\n\n"
    <<endl;
return 0;
}
