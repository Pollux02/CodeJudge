#include <iostream>

using namespace std;

int main()
{
    float gradosFahrenheit,gradosCelsius,restar,dividir,fraccion,C,resta2;
    cout << "Escribe la cantidad de grados Fharenheit a convertir: ";
    cin >> gradosFahrenheit;
    restar = gradosFahrenheit-32;
    dividir = restar/2;
    fraccion = dividir/10;
    gradosCelsius = dividir+fraccion;
    cout << "    " << endl;
    cout << "La convercion a grados Celsius es:" << gradosCelsius << endl << endl;
    cout << "Segunda opcion para convercion de grados, usando la misma cantidad de grados" << endl;
    C= (gradosFahrenheit-32)/1.8;
    cout << "La convercion a grados Celsius es:"<< C << endl << endl;
    cout << "El valor aproximados es:" << gradosCelsius << endl;
    cout << "El valor exacto es:" << C << endl;
    resta2= gradosCelsius-C;
    cout << "La diferncia entre valores es:" << resta2;



    return 0;
}
