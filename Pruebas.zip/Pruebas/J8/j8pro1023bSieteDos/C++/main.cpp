#include <iostream>
#define C_FARENHEIT 32

using namespace std;

int main()
{
    float gradosFarenheit,totalMetodoA,totalMetodoB;

    cout << "--Convertidor de Farenheit a Celsius --" << endl;
    cout << "Ingrese la cantidad de grados Farenheit: " << endl;
    cin  >> gradosFarenheit;

    //Primer metodo

    totalMetodoA = ((gradosFarenheit-C_FARENHEIT)/2);
    totalMetodoA = (totalMetodoA) + totalMetodoA/10;
    cout << "Valor ingresado : " << gradosFarenheit << endl;
    cout << "El resultado del metodo A es igual a " << totalMetodoA << endl;

    //Segundo metodo

    totalMetodoB = ((gradosFarenheit-C_FARENHEIT)*5)/9;
    cout << "Valor ingresado : " << gradosFarenheit << endl;
    cout << "El resultado del metodo B es igual a " << totalMetodoB << endl;
    cout << "La diferencia de (metodoA - MetodoB) es igual a "
         << (totalMetodoA - totalMetodoB) << endl;



    return 0;
}
