#include <iostream>

using namespace std;

int main()
{
    float formula1,celcius1,celcius2, fahrenheit;
    cout << "Conversion de grados Fahrenheit a Celsius" << endl;

    cout << "Ingrese el valor de Fahrenheit: ";
    cin >> fahrenheit;
    cout<<endl;
    formula1= ((fahrenheit-32)/2)/10;
    celcius1=((fahrenheit-32)/2)+formula1;
    celcius2= 5*(fahrenheit-32)/9;


    cout << "Fahrenheit: " << fahrenheit << endl;
    cout << "Celcius con la primer formula: " << celcius1 << " grados celcius" << endl;
    cout << "Celcius con la segunda formula: " << celcius2 << " grados celcius" << endl;
    return 0;
}
