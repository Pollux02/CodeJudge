#include <iostream>

using namespace std;

int main()
{
    float F, C;
    cout << "Inserte los grados Farenheit: ";
    scanf("%f", &F);
    C=(F-32)/1.8;
    cout << endl << "Tus grados Farenheit son: " << F << endl;
    cout << "Tu conversion de Farenheit a Celcius son igual a: " << C << endl;


    return 0;
}
