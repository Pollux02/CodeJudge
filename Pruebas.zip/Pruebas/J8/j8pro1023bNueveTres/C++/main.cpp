#include <iostream>

using namespace std;


int main()
{
    float fahrenheit;
    float celcius, celcius1=0;
    cout<<"Convertor grados Fahrenheit a Celsius"<<endl<<endl;

    //Metodo 1

    cout << "Metodo 1" << endl;
    cout<<"Cual es el valor en grados Fahrenheit: ";
    cin>>fahrenheit;
    celcius=((fahrenheit-32)/2);
    celcius=(celcius/10)+celcius;
    cout<<endl<<"El Valor de grados Fahrenheit es: "<<fahrenheit<<endl;
    cout<<"El valor convertido de Fahrenheit a Celcius es: "<<celcius<<endl;
    celcius1=celcius;


    //Metodo 2

    cout <<endl<< "Metodo 2" << endl;
    //cout<<"Cual es el valor en grados Fahrenheit: ";
    //cin>>fahrenheit;
    celcius=((fahrenheit-32)/1.8);
    cout<<endl<<"El Valor de grados Fahrenheit es: "<<fahrenheit<<endl;
    cout<<"El valor convertido de Fahrenheit a Celcius es: "<<celcius<<endl;

    //Diferencia

    float celciustotal;
    cout<<endl<<"La diferencia entre El metodo 1 y el metodo 2 es:"<<endl;
    celciustotal=celcius1-celcius;
    cout<<celcius1<<" - "<<celcius<<" = "<<celciustotal;
    return 0;
}
