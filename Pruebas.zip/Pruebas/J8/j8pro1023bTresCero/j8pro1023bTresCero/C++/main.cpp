#include <iostream>

using namespace std;

int main()
{
    float farenheit, celsius_f, celsius_10, celsius1, celsius2;
    cout << "Diferencia de conversiones" << endl << endl;
    cout << "Ingrese el valor que desea convertir: ";
    cin >> farenheit;
    cout << endl;

    celsius_f = farenheit-32;
    celsius_f = celsius_f/2;
    celsius_10 = celsius_f/10;
    celsius1 = celsius_f+celsius_10;

    celsius2 = 5*(farenheit-32)/9;

    cout << "Conversion metodo 1" << endl;
    cout << "El resultado con el metodo 1 es: " << celsius1 << endl << endl;

    cout << "Conversion metodo 2" << endl;
    cout << "El resultado con el metodo 2 es: " << celsius2 << endl << endl;
    cout << "La diferencia del metodo 1 menos el metodo 2 es: " << celsius1 ;
    cout << " - " << celsius2 << " = " << celsius1-celsius2;


    return 0;
}
