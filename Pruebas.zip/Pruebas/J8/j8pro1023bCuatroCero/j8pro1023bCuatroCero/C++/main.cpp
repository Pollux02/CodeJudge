#include <iostream>

using namespace std;

int main() {
    double fahrenheit;
    double celsius_aproximado, celsius_exacto, diferencia;

    cout << "Ingrese la temperatura en grados Fahrenheit: ";
    cin >> fahrenheit;


    celsius_aproximado = ((fahrenheit - 32) / 2 + (fahrenheit - 32) / 10);


    celsius_exacto = (5 * (fahrenheit - 32)) / 9;


    diferencia = celsius_aproximado - celsius_exacto;


    cout << "\nTemperatura en grados Fahrenheit: " << fahrenheit << endl;
    cout << "Método aproximado: " << celsius_aproximado << " grados Celsius" << endl;
    cout << "Método exacto: " << celsius_exacto << " grados Celsius" << endl;
    cout << "Diferencia entre métodos: " << diferencia << " grados Celsius" << endl;

    return 0;
}





