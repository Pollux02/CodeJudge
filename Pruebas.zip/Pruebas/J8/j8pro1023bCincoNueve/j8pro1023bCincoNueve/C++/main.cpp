#include <iostream>

using namespace std;

int main()
{
    cout << "Conversion de grados Fahrenheit a Celsius" << endl << endl ;
    float  fahrenheit,celsiusAprox,celsiusExact,celsiusAprox1,celsiusAprox2,celsiusAprox3,diff ;
    cout << "Ingrese la temperatura en grados Fahrenheit: ";
    cin >> fahrenheit ;
    // Metodo 1: Calculo aproximado
    celsiusAprox1  = fahrenheit - 32;
    celsiusAprox2  = celsiusAprox1 / 2;
    celsiusAprox3  = celsiusAprox2 / 10;
    celsiusAprox   = celsiusAprox2 + celsiusAprox3;
    // Metodo 2: Conversion exacta
    celsiusExact   = 5 * (fahrenheit - 32) / 9;
    // Diferencia de ambos metodos
    diff           = celsiusAprox - celsiusExact;
    cout << endl << "Temperatura en Fahrenheit = " << fahrenheit << endl;
    cout << "Temperatura en Celsius con el metodo aproximado = " << celsiusAprox << endl;
    cout << "Temperatura en Celsius con el metodo exacto = " << celsiusExact << endl;
    cout << "Diferencia entre ambos metodos = " << diff << endl;

    return 0;
}
