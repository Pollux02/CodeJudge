#include <iostream>
using namespace std;

int main() {
    float fahrenheit, celsiusAproximado, celsiusExacto, diferencia;

    cout << "Ingrese la temperatura en grados Fahrenheit: ";
    cin >> fahrenheit;

    celsiusAproximado = (fahrenheit - 32) / 2.0;
    celsiusAproximado += celsiusAproximado / 10.0;

    celsiusExacto = 5.0 / 9.0 * (fahrenheit - 32);

    diferencia = celsiusAproximado - celsiusExacto;

    cout << "Valor le�do (Fahrenheit): " << fahrenheit << " �F" << endl;
    cout << "M�todo Aproximado (Celsius): " << celsiusAproximado << " �C" << endl;
    cout << "M�todo Exacto (Celsius): " << celsiusExacto << " �C" << endl;
    cout << "Diferencia entre Metodos: " << diferencia << " �C" << endl;

    return 0;
}
