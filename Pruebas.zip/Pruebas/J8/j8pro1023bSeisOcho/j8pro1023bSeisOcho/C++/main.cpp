#include <iostream>

using namespace std;

int main()
{
    float far, celA, cel;

    cout<< "Conversion de grados Fahrenheit a Celsius"<< endl<< endl;
    cout << "Por favor, ingrese los grados a convertir:";
    cin >> far;
    cout << endl;

    celA = (far - 32)/2;
    celA = celA*.1 + celA;
    cout << far << " grados Fahrenheit = a aproximadamente " << celA << " grados Celsius"<<endl;

    cel = (far-32)/1.8;
    cout << far << " grados Fahrenheit = " << cel << " grados Celsius"<<endl;

    cout<<"Entre los resultados; hay una diferencia de "<< celA-cel <<" grados."<<endl<<endl;
    return 0;
}
