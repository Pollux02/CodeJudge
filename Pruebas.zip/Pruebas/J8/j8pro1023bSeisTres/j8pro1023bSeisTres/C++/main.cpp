#include <iostream>
using namespace std;

int main() {
    float fahrenheit, CelsiusAprox, CelsiusExact,diferencia,resta,division,fraccion;
    
    cout << "Ingrese la temperatura en grados Fahrenheit: ";
    cin >> fahrenheit;
    
   
 	resta = (fahrenheit-32);
    division = resta/2;
    fraccion = division/10;
	CelsiusAprox = division+fraccion;

CelsiusExact = 5 * (fahrenheit - 32) / 9;
    
  
diferencia = CelsiusAprox - CelsiusExact;
    
    
    
    cout << "Temperatura en grados Fahrenheit: " << fahrenheit << endl;
    cout << "Metodo aproximado - Temperatura en grados Celsius: " << CelsiusAprox << endl;
    cout << "Metodo exacto - Temperatura en grados Celsius: " << CelsiusExact << endl;
    cout << "Diferencia entre m�todos: " << diferencia << endl;
    
    return 0;
}

