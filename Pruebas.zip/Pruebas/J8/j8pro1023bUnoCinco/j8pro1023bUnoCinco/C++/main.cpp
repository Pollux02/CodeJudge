#include <iostream>

using namespace std;

int main()
{

    float f,c1,c2;
    cout << "De fahrenheit a celcius" << endl<< endl;
    cout<<"Dame los grados a cambiar"<<endl;
    cin>>f;
    c1=f-32/1.8;
    c2=f-32*5/9;
    cout<<"Con la opcion uno serian:"<<c1<<" Tomando los grados F= "<<f<<endl;
    cout<<"Con la opcion dos serian:"<<c2<<" Tomando los grados F= "<<f<<endl;
    cout<<"Comparando la opcion 1 con la dos quedaria una diferencia de "<<c1-c2<<" grados"<<endl;
    cout<<"Comparando la opcion 2 con la uno quedaria una diferencia de "<<c2-c1<<" grados"<<endl;
    return 0;
}
