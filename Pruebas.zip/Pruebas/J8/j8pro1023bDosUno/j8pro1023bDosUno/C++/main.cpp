#include <iostream>

using namespace std;

int main()
{
    float Fahrenheit, resta, dividir, decimo, divysum, formula;
    float resform, divform, divysumform;
    cout << "Bienvenido a conversor de grados Fahrenheit a Grados celsius"<< endl;
    cout << "Ingrese los grados Fahrenheit que desea convertir:";
    cin >> Fahrenheit;
    cout <<"el primer calculo aproximado es el de resta, a los grados F se les resta 32, entonces: ";
    resta= Fahrenheit-32;
    cout <<Fahrenheit<< "-32 es igual a " <<resta<< endl;
    cout <<"el segundo calculo aproximado es el de division, a los grados F se le divide entre 2, ";
    dividir= Fahrenheit/2;
    cout << "entonces " <<Fahrenheit<<"/2 es igual a " <<dividir<< endl ;
    cout <<"para el tercer calculo aproximado usamos el resultado de division entre 2 y ";
    decimo= Fahrenheit/10;
    cout <<" se le suma 1/10 de los grados Fahrenheit, entonces F/10 es igual a: " <<decimo<< endl;
    divysum= dividir+decimo;
    cout << "ahora para obtener el resultado hacemos la division de F/2 y sumarle el resultado de";
    cout << " F/10 eso es igual a=" <<divysum<< endl;
    cout << "para el ultimo calculo utilizaremos una formula para asi obtener la conversion exacta";
    formula= (Fahrenheit-32)/1.8;
    cout << " ,nuestra formula sera, F-32/1.8, entonces nuestro resultado es: " <<formula<< endl;
    cout << "ahora haremos comparaciones sobre los resultados de los calculos aproximados y";
    cout << " el resultado exacto"<<  endl;
    resform= resta-formula;
    cout << "la diferencia entre el calculo resta y formula es: " <<resform<< endl;
    divform= dividir-formula;
    cout << "la diferencia entre el calculo division y formula es: " <<divform<< endl;
    divysumform= divysum-formula;
    cout << "la diferencia entre el calculo de division y suma y formula es: " <<divysumform<< endl;

    return 0;
}
