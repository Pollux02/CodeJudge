#include <iostream>

using namespace std;

int main()
{
    float F, R, D, DD, S, M2;
    cout << "Farenheit a Celsius\n" << endl;
    cout << "Dame los grados Farenheit a convertir: ";
    cin >> F;
    R = F - 32;
    D = R / 2;
    DD = D / 10;
    S = D + DD;
    M2 = R * 5 / 9;
    cout << "\nMetodo 1\n";
    cout << F << " - 32 = " << R << endl;
    cout << R << " / 2 = " << D << endl;
    cout << D << " / 10 = " << DD << endl;
    cout << D << " + " << DD << " = " << S << "C" << endl;

    cout << "\nMetodo 2\n";
    cout << "5 (" << F << " - 32) / 9 = " << M2 << "C" << endl;

    cout << ("\nCompracaion de ambos metodos: ") << endl;
    cout << S << " - " << M2 << " = "<< S - M2 << endl;
    return 0;
}
